/*
 * pogls_38_steal.h — POGLS38  Voronoi Steal + Sleep Wire
 * ══════════════════════════════════════════════════════════════════════
 *
 * แก้ปัญหา work clustering: งานกระจุกอยู่ที่ head เดียว
 *
 * VORONOI STEAL (geometric work distribution):
 *   แต่ละ head เป็น "centroid" ใน 17n cell space (289 cells)
 *   cell → ของ head ที่ centroid ใกล้ที่สุด (Voronoi region)
 *   steal: ถ้า head idle → ดึงงานจาก head ที่ region ใกล้ที่สุด
 *   ผล: งานไม่กระจุก เพราะ region ถูก partition ทาง geometry
 *
 * เปรียบเทียบ:
 *   ปัจจุบัน = งานไปที่ head ตาม bit mask → random กระจุกได้
 *   Voronoi  = 289 cells แบ่งเป็น 16 zone ตามระยะ centroid
 *              เหมือน postal district — แต่ละ zone มี 1 head รับผิดชอบ
 *
 * DELAUNAY CHECK (neighbor validation):
 *   Voronoi dual = Delaunay triangulation
 *   ใช้ตรวจว่า cell อยู่ใน "right region" หรือไม่
 *   ถ้า cell อยู่ใกล้ boundary → eligible for steal จาก neighbor
 *
 * SLEEP WIRE (face hibernation in wiring pipeline):
 *   ถ้า head ว่างนาน + cell มี warp_open=1 → hibernate face
 *   warp bridge คงค้างไว้ (data accessible แต่ cpu ไม่จ่ายเวลา)
 *   wake: งานเข้า Voronoi region ของ head นั้น → wake ทันที
 *
 * ══════════════════════════════════════════════════════════════════════
 */

#ifndef POGLS_38_STEAL_H
#define POGLS_38_STEAL_H

#include <stdint.h>
#include <string.h>
#include "pogls_38_hydra.h"
#include "pogls_38_wiring.h"    /* L38WarpDetach */

/* ══════════════════════════════════════════════════════════════════════
 * VORONOI CENTROIDS
 *
 * 16 centroids บน 17×17 cell grid (289 cells)
 * วางแบบ hexagonal-like ใน 4×4 arrangement:
 *   col 0..3 × row 0..3 = 16 points
 *   spacing ≈ 17/4 = 4.25 → floor = 4
 *
 * เปรียบเทียบ: เหมือนแบ่งห้าง 17×17 ห้อง เป็น 16 zone
 *   แต่ละ zone มี 1 เคาน์เตอร์บริการ (centroid)
 *   ลูกค้า (cell) ไปเคาน์เตอร์ที่ใกล้ที่สุด
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint8_t  cx;    /* centroid x (lane: cell_id % 17)    0..16  */
    uint8_t  cy;    /* centroid y (group: cell_id / 17)   0..16  */
    uint8_t  head;  /* which Hydra head owns this region          */
    uint8_t  _pad;
} L38VoronoiCentroid;

#define L38_VOR_NCENT  L38_HS_HEADS  /* 16 centroids = 16 heads */

/* precomputed region assignment: cell_id → head_id
 * built once at init */
typedef struct {
    uint8_t  cell_to_head[L38_BB_NODES];     /* 289B                   */
    uint8_t  head_cell_count[L38_HS_HEADS];  /* cells per head         */
    L38VoronoiCentroid centroids[L38_VOR_NCENT];
} L38VoronoiMap;

/* squared distance on 17×17 torus (wraps at 17) */
static inline uint32_t _vor_dist2(uint8_t ax, uint8_t ay,
                                    uint8_t bx, uint8_t by)
{
    int dx = (int)ax - (int)bx;
    int dy = (int)ay - (int)by;
    /* torus wrap */
    if (dx >  8) dx -= 17;
    if (dx < -8) dx += 17;
    if (dy >  8) dy -= 17;
    if (dy < -8) dy += 17;
    return (uint32_t)(dx*dx + dy*dy);
}

/* build Voronoi map — call once at init */
static inline void l38_voronoi_init(L38VoronoiMap *vm)
{
    memset(vm, 0, sizeof(*vm));

    /* place 16 centroids in 4×4 grid on 17×17 torus
     * offset by 2 so boundaries fall between cells */
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 4; c++) {
            int h = r * 4 + c;
            vm->centroids[h].cx   = (uint8_t)(c * 4 + 2);
            vm->centroids[h].cy   = (uint8_t)(r * 4 + 2);
            vm->centroids[h].head = (uint8_t)h;
        }
    }

    /* assign each cell to nearest centroid (Voronoi tessellation) */
    for (uint16_t cid = 0; cid < L38_BB_NODES; cid++) {
        uint8_t  cx = (uint8_t)(cid % L17_BRIDGE);   /* lane  0..16 */
        uint8_t  cy = (uint8_t)(cid / L17_BRIDGE);   /* group 0..16 */

        uint32_t best_d2 = UINT32_MAX;
        uint8_t  best_h  = 0;
        for (int h = 0; h < L38_VOR_NCENT; h++) {
            uint32_t d2 = _vor_dist2(cx, cy,
                                      vm->centroids[h].cx,
                                      vm->centroids[h].cy);
            if (d2 < best_d2) { best_d2 = d2; best_h = (uint8_t)h; }
        }
        vm->cell_to_head[cid] = best_h;
        vm->head_cell_count[best_h]++;
    }
}

/* route cell → head via Voronoi region */
static inline uint32_t l38_voronoi_route(const L38VoronoiMap *vm,
                                           uint16_t cell_id)
{
    if (cell_id >= L38_BB_NODES) return 0;
    return vm->cell_to_head[cell_id];
}

/* ══════════════════════════════════════════════════════════════════════
 * DELAUNAY NEIGHBOR CHECK
 *
 * Voronoi dual = Delaunay: สอง region เป็น neighbor ถ้า centroid pair
 * ไม่มี centroid อื่นอยู่ใน circumcircle ของ triangle ที่เกิดจาก
 * 2 centroid + cell นั้น
 *
 * สำหรับ POGLS38: simplify เป็น "near-boundary" check
 *   cell อยู่ใกล้ boundary ถ้า distance ไป centroid ตัวเอง
 *   ≤ 1.5× distance ไป centroid ที่ใกล้ที่สุด ตัวอื่น
 *
 * ถ้า near-boundary → eligible for steal จาก neighbor region
 * ════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint8_t  near_boundary;       /* 1 = cell อยู่ใกล้ region boundary */
    uint8_t  neighbor_head;       /* head ที่ใกล้ที่สุด (Delaunay nbr) */
    uint16_t cell_id;
} L38DelaunayCell;

static inline L38DelaunayCell l38_delaunay_check(const L38VoronoiMap *vm,
                                                    uint16_t cell_id)
{
    L38DelaunayCell dc = {0, 0, cell_id};
    if (cell_id >= L38_BB_NODES) return dc;

    uint8_t cx = (uint8_t)(cell_id % L17_BRIDGE);
    uint8_t cy = (uint8_t)(cell_id / L17_BRIDGE);
    uint8_t own_h = vm->cell_to_head[cell_id];

    uint32_t own_d2  = _vor_dist2(cx, cy,
                                   vm->centroids[own_h].cx,
                                   vm->centroids[own_h].cy);
    uint32_t best2_d2 = UINT32_MAX;
    uint8_t  best2_h  = own_h;

    for (int h = 0; h < L38_VOR_NCENT; h++) {
        if ((uint8_t)h == own_h) continue;
        uint32_t d2 = _vor_dist2(cx, cy,
                                  vm->centroids[h].cx,
                                  vm->centroids[h].cy);
        if (d2 < best2_d2) { best2_d2 = d2; best2_h = (uint8_t)h; }
    }

    /* near-boundary: own_d2 × 4 >= best2_d2 × 6  (ratio 1.5) */
    dc.near_boundary  = (own_d2 * 6u >= best2_d2 * 5u) ? 1u : 0u;
    dc.neighbor_head  = best2_h;
    return dc;
}

/* ══════════════════════════════════════════════════════════════════════
 * VORONOI STEAL
 *
 * แทนที่ greedy steal (busiest head):
 *   1. ถ้า idle head มี near-boundary cells → steal จาก neighbor region
 *   2. ถ้าไม่มี boundary → steal จาก head ที่ centroid ใกล้ที่สุด
 *   3. fallback: greedy (เหมือนเดิม)
 *
 * ผล: งานถูก pull จาก region ที่ "ใกล้ชิดทาง geometry"
 *     ไม่ข้ามไปอีกฝั่งของ lattice
 * ══════════════════════════════════════════════════════════════════════ */

static inline int l38_voronoi_steal(L38Hydra          *h,
                                      const L38VoronoiMap *vm,
                                      uint32_t            my_head,
                                      L38HydraTask       *out)
{
    /* Step 1: find nearest neighbor head by centroid distance */
    uint8_t  mcx = vm->centroids[my_head].cx;
    uint8_t  mcy = vm->centroids[my_head].cy;

    uint32_t best_d2   = UINT32_MAX;
    uint32_t best_nbr  = L38_HS_HEADS;  /* sentinel */

    for (uint32_t v = 0; v < L38_VOR_NCENT; v++) {
        if (v == my_head) continue;
        /* only try heads that actually have work */
        if (l38_hs_depth(&h->queues[v]) == 0) continue;
        uint32_t d2 = _vor_dist2(mcx, mcy,
                                   vm->centroids[v].cx,
                                   vm->centroids[v].cy);
        if (d2 < best_d2) { best_d2 = d2; best_nbr = v; }
    }

    if (best_nbr == L38_HS_HEADS) return 0;  /* no work anywhere */

    /* Step 2: CAS steal from nearest neighbor */
    L38HydraQueue *vq   = &h->queues[best_nbr];
    uint32_t       head = atomic_load_explicit(&vq->head,
                                                memory_order_relaxed);
    uint32_t       tail = atomic_load_explicit(&vq->tail,
                                                memory_order_acquire);
    while (head != tail) {
        *out = vq->tasks[head & L38_HS_QUEUE_MASK];
        if (atomic_compare_exchange_weak_explicit(
                &vq->head, &head, head + 1u,
                memory_order_release, memory_order_relaxed)) {
            h->tasks_stolen[my_head]++;
            h->steals_attempted[my_head]++;
            return 1;
        }
    }

    h->steals_attempted[my_head]++;
    return 0;
}

/* steal with Delaunay boundary awareness:
 * prefer boundary cells that "belong" to both regions */
static inline int l38_delaunay_steal(L38Hydra          *h,
                                       const L38VoronoiMap *vm,
                                       uint32_t            my_head,
                                       L38HydraTask       *out)
{
    /* scan pending tasks across all heads, pick one where
     * the cell is near-boundary with my_head as neighbor */
    for (uint32_t v = 0; v < L38_HS_HEADS; v++) {
        if (v == my_head) continue;
        L38HydraQueue *vq = &h->queues[v];
        uint32_t head = atomic_load_explicit(&vq->head, memory_order_relaxed);
        uint32_t tail = atomic_load_explicit(&vq->tail, memory_order_acquire);
        if (head == tail) continue;

        /* peek at front task */
        const L38HydraTask *peek = &vq->tasks[head & L38_HS_QUEUE_MASK];
        uint16_t cid = peek->cell_id;
        if (cid < L38_BB_NODES) {
            L38DelaunayCell dc = l38_delaunay_check(vm, cid);
            /* steal if: cell is near boundary AND neighbor = my_head */
            if (dc.near_boundary && dc.neighbor_head == (uint8_t)my_head) {
                L38HydraTask stolen = *peek;
                if (atomic_compare_exchange_weak_explicit(
                        &vq->head, &head, head + 1u,
                        memory_order_release, memory_order_relaxed)) {
                    *out = stolen;
                    h->tasks_stolen[my_head]++;
                    return 1;
                }
            }
        }
    }
    /* fallback: Voronoi steal */
    return l38_voronoi_steal(h, vm, my_head, out);
}

/* ══════════════════════════════════════════════════════════════════════
 * SLEEP WIRE  (face hibernation integrated with Hydra)
 *
 * Face = head ใน POGLS38 context
 * Sleep conditions:
 *   - head ว่าง (queue empty) นาน > SLEEP_IDLE_TICKS
 *   - cell ที่ responsible ทั้งหมด มี warp_open (can hibernate)
 *
 * Wake conditions:
 *   - งานเข้า Voronoi region ของ head นั้น
 *   - Tails summon ที่ตก cell ใน region นั้น
 *   - gate_18 crossing (periodic wake all)
 *
 * ต่างจาก V3.6 face_sleep (madvise/MADV_DONTNEED):
 *   POGLS38 ไม่มี mmap — sleep = skip drain loop
 *   warp bridge = flag ใน L38WarpDetach เท่านั้น
 * ══════════════════════════════════════════════════════════════════════ */

#define L38_SLEEP_IDLE_TICKS  18u   /* gate_18 = natural sleep boundary */
#define L38_SLEEP_MAGIC       0x534C5057u  /* "SLPW"                    */

typedef enum {
    L38_FACE_AWAKE    = 0,
    L38_FACE_DROWSY   = 1,   /* idle > threshold, monitoring           */
    L38_FACE_SLEEPING = 2,   /* skip drain, warp bridge open           */
} l38_face_state_t;

typedef struct {
    uint8_t   state;          /* l38_face_state_t                       */
    uint8_t   idle_ticks;     /* consecutive empty drain cycles         */
    uint8_t   warp_count;     /* cells with warp_open in region         */
    uint8_t   _pad;
    uint32_t  head_id;
    uint64_t  sleep_since_ns;
    uint64_t  total_sleeps;
    uint64_t  total_wakes;
} L38FaceSleep;

typedef struct {
    uint32_t      magic;
    L38FaceSleep  faces[L38_HS_HEADS];
} L38SleepWire;

static inline void l38_sleep_wire_init(L38SleepWire *sw)
{
    memset(sw, 0, sizeof(*sw));
    sw->magic = L38_SLEEP_MAGIC;
    for (uint32_t i = 0; i < L38_HS_HEADS; i++)
        sw->faces[i].head_id = i;
}

/* tick: called after drain attempt — update sleep state */
static inline void l38_sleep_tick(L38SleepWire  *sw,
                                    L38Hydra      *h,
                                    uint32_t       head_id)
{
    L38FaceSleep *f = &sw->faces[head_id];
    uint32_t depth  = l38_hs_depth(&h->queues[head_id]);

    if (depth == 0) {
        if (f->idle_ticks < 255u) f->idle_ticks++;
        if (f->idle_ticks >= L38_SLEEP_IDLE_TICKS &&
            f->state == L38_FACE_AWAKE) {
            f->state = L38_FACE_DROWSY;
        }
        if (f->idle_ticks >= L38_SLEEP_IDLE_TICKS * 2u &&
            f->state == L38_FACE_DROWSY) {
            f->state         = L38_FACE_SLEEPING;
            f->sleep_since_ns = 0;   /* caller fills if needed */
            f->total_sleeps++;
        }
    } else {
        /* work arrived → wake immediately */
        if (f->state != L38_FACE_AWAKE) {
            f->state     = L38_FACE_AWAKE;
            f->idle_ticks = 0;
            f->total_wakes++;
        } else {
            f->idle_ticks = 0;
        }
    }
}

/* wake: called when work enters region (Voronoi route hit) */
static inline void l38_sleep_wake(L38SleepWire *sw, uint32_t head_id)
{
    L38FaceSleep *f = &sw->faces[head_id];
    if (f->state != L38_FACE_AWAKE) {
        f->state      = L38_FACE_AWAKE;
        f->idle_ticks = 0;
        f->total_wakes++;
    }
}

/* gate_18 wake all sleeping faces */
static inline void l38_sleep_gate18_wake(L38SleepWire *sw)
{
    for (uint32_t i = 0; i < L38_HS_HEADS; i++) {
        if (sw->faces[i].state == L38_FACE_SLEEPING)
            l38_sleep_wake(sw, i);
    }
}

/* should drain: 1=yes (awake/drowsy), 0=skip (sleeping) */
static inline int l38_sleep_should_drain(const L38SleepWire *sw,
                                           uint32_t head_id)
{
    return sw->faces[head_id].state != L38_FACE_SLEEPING;
}

/* ══════════════════════════════════════════════════════════════════════
 * FULL STEAL PIPELINE  (Voronoi + Delaunay + Sleep Wire combined)
 * ══════════════════════════════════════════════════════════════════════ */

static inline int l38_steal_pipeline(L38Hydra          *h,
                                       const L38VoronoiMap *vm,
                                       L38SleepWire       *sw,
                                       uint32_t            my_head,
                                       L38HydraTask       *out)
{
    /* sleeping head should not be stealing — saves CPU */
    if (!l38_sleep_should_drain(sw, my_head)) return 0;

    /* try Delaunay-aware steal first (geometry-correct) */
    int r = l38_delaunay_steal(h, vm, my_head, out);
    if (r) {
        l38_sleep_wake(sw, my_head);   /* work found → ensure awake */
        return 1;
    }

    /* no work in geometric neighborhood — go truly idle */
    l38_sleep_tick(sw, h, my_head);
    return 0;
}

/* schedule with Voronoi routing + wake destination head */
static inline int l38_voronoi_schedule(L38Hydra          *h,
                                         const L38VoronoiMap *vm,
                                         L38SleepWire       *sw,
                                         L38HydraTask       *t)
{
    /* cell_id in task determines Voronoi region */
    uint32_t hid = (t->cell_id < L38_BB_NODES)
        ? l38_voronoi_route(vm, t->cell_id)
        : l38_hs_route_addr(t->addr);

    int r = l38_hs_push(&h->queues[hid], t);
    if (r == 0) {
        h->tasks_pushed[hid]++;
        /* wake destination head if sleeping */
        l38_sleep_wake(sw, hid);
        /* update weight */
        uint8_t w = h->weight.weight[hid];
        h->weight.weight[hid] = (uint8_t)(w + 8u > 255u ? 255u : w + 8u);
        return (int)hid;
    }

    /* region full → nearest Voronoi neighbor */
    uint8_t mcx = vm->centroids[hid].cx;
    uint8_t mcy = vm->centroids[hid].cy;
    uint32_t best_d2 = UINT32_MAX;
    uint32_t alt_hid = (hid + 1u) % L38_HS_HEADS;

    for (uint32_t v = 0; v < L38_VOR_NCENT; v++) {
        if (v == hid) continue;
        if (l38_hs_depth(&h->queues[v]) >= L38_HS_QUEUE_SIZE - 1u) continue;
        uint32_t d2 = _vor_dist2(mcx, mcy,
                                   vm->centroids[v].cx,
                                   vm->centroids[v].cy);
        if (d2 < best_d2) { best_d2 = d2; alt_hid = v; }
    }
    r = l38_hs_push(&h->queues[alt_hid], t);
    if (r == 0) {
        h->tasks_pushed[alt_hid]++;
        l38_sleep_wake(sw, alt_hid);
        return (int)alt_hid;
    }
    return -1;
}

#endif /* POGLS_38_STEAL_H */
