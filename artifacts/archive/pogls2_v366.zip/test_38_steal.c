/*
 * test_38_steal.c — POGLS38 Voronoi Steal + Sleep Wire Tests
 *
 * T01  Voronoi: 16 centroids placed in 4×4 grid
 * T02  Voronoi: all 289 cells assigned (no gaps)
 * T03  Voronoi: cells per head balanced (≈18 each)
 * T04  Voronoi: route(cell) → correct head (nearest centroid)
 * T05  Voronoi: torus wrap distance (boundary cells)
 * T06  Delaunay: near-boundary cell has neighbor head
 * T07  Delaunay: centroid cell is NOT near-boundary
 * T08  Voronoi steal: steals from nearest centroid-neighbor
 * T09  Voronoi steal: no steal when all queues empty
 * T10  Delaunay steal: prefers boundary-eligible tasks
 * T11  Sleep wire init: all faces AWAKE
 * T12  Sleep tick: idle→DROWSY after 18 ticks
 * T13  Sleep tick: DROWSY→SLEEPING after 36 ticks
 * T14  Sleep wake: SLEEPING→AWAKE on work arrival
 * T15  Sleep gate_18: all sleeping faces wake
 * T16  Sleep should_drain: sleeping=no, awake=yes
 * T17  Full pipeline: steal_pipeline respects sleep state
 * T18  Voronoi schedule: cell → correct region → head wakes
 * T19  Distribution: 289 tasks spread across ≥12 heads
 * T20  No clustering: no single head has >30% of tasks
 */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "../pogls_38_steal.h"

static int _pass=0, _fail=0;
static void check(int ok, const char *p, const char *f) {
    if (ok) { printf("    \033[32mv\033[0m %s\n", p); _pass++; }
    else    { printf("    \033[31mx FAIL\033[0m: %s\n", f); _fail++; }
}
static void section(const char *s) { printf("\n  -- %s\n", s); }

/* ══ T01 ══ */
static void t01_centroids(void) {
    section("T01  Voronoi: 16 centroids in 4×4 grid");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    /* check 4×4 placement */
    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
        int h = r*4+c;
        check(vm.centroids[h].head == h, "centroid.head correct", "wrong");
        check(vm.centroids[h].cx == c*4+2, "centroid.cx = c*4+2", "wrong");
        check(vm.centroids[h].cy == r*4+2, "centroid.cy = r*4+2", "wrong");
    }
}

/* ══ T02 ══ */
static void t02_all_assigned(void) {
    section("T02  Voronoi: all 289 cells assigned");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    int all_ok = 1;
    for (uint16_t c = 0; c < L38_BB_NODES; c++)
        if (vm.cell_to_head[c] >= L38_HS_HEADS) { all_ok = 0; break; }
    check(all_ok, "all 289 cells have valid head_id", "gap found");

    /* total assigned = 289 */
    uint32_t total = 0;
    for (int h = 0; h < L38_HS_HEADS; h++) total += vm.head_cell_count[h];
    check(total == L38_BB_NODES, "total assigned = 289", "wrong");
}

/* ══ T03 ══ */
static void t03_balanced(void) {
    section("T03  Voronoi: cells per head balanced (≈18±6)");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    uint8_t mn = 255, mx = 0;
    for (int h = 0; h < L38_HS_HEADS; h++) {
        if (vm.head_cell_count[h] < mn) mn = vm.head_cell_count[h];
        if (vm.head_cell_count[h] > mx) mx = vm.head_cell_count[h];
    }
    check(mn >= 10, "min cells/head ≥ 10", "too few");
    check(mx <= 28, "max cells/head ≤ 28", "too many");
    printf("    (min=%u max=%u ideal=18)\n", mn, mx);
}

/* ══ T04 ══ */
static void t04_route(void) {
    section("T04  Voronoi: route returns correct head");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    /* cell at centroid 0 (cx=2,cy=2) = cell_id = 2*17+2 = 36 */
    uint16_t cid0 = 2*17 + 2;
    uint32_t h = l38_voronoi_route(&vm, cid0);
    check(h == 0, "cell at centroid 0 → head 0", "wrong");
    /* cell at centroid 15 (cx=14,cy=14) */
    uint16_t cid15 = 14*17 + 14;
    uint32_t h15 = l38_voronoi_route(&vm, cid15);
    check(h15 == 15, "cell at centroid 15 → head 15", "wrong");
}

/* ══ T05 ══ */
static void t05_torus_dist(void) {
    section("T05  Torus distance wraps correctly");
    /* distance from (0,0) to (16,16) should wrap to ≈2 */
    uint32_t d2 = _vor_dist2(0,0, 16,16);
    /* (0-16 mod 17 → -1 → 16 > 8 → 16-17=-1 → |1|=1)^2 × 2 = 2 */
    check(d2 == 2, "torus dist (0,0)↔(16,16) = 2", "wrong");
    /* distance from (0,0) to (1,1) = 2 */
    uint32_t d2_near = _vor_dist2(0,0, 1,1);
    check(d2_near == 2, "dist (0,0)↔(1,1) = 2", "wrong");
}

/* ══ T06 ══ */
static void t06_delaunay_boundary(void) {
    section("T06  Delaunay: boundary cell identified");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    /* scan all cells — find at least one near-boundary */
    int found_boundary = 0;
    for (uint16_t c = 0; c < L38_BB_NODES; c++) {
        L38DelaunayCell dc = l38_delaunay_check(&vm, c);
        if (dc.near_boundary) { found_boundary = 1; break; }
    }
    check(found_boundary, "at least 1 near-boundary cell found", "none");
}

/* ══ T07 ══ */
static void t07_delaunay_centroid(void) {
    section("T07  Delaunay: centroid cell NOT near-boundary");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    /* centroid 0 at (2,2) → cell 2*17+2=36 */
    L38DelaunayCell dc = l38_delaunay_check(&vm, (uint16_t)(2*17+2));
    check(dc.near_boundary == 0, "centroid cell = not near-boundary", "wrong");
}

/* ══ T08 ══ */
static void t08_voronoi_steal(void) {
    section("T08  Voronoi steal: takes from nearest centroid");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    L38Hydra h; l38_hydra_init(&h);

    /* push 5 tasks to head 1 (centroid neighbor of head 0) */
    for (int i = 0; i < 5; i++) {
        L38HydraTask t = {.op=L38_HS_OP_WRITE, .cell_id=5, .addr=(uint64_t)i};
        l38_hs_push(&h.queues[1], &t);
    }
    L38HydraTask stolen;
    int r = l38_voronoi_steal(&h, &vm, 0, &stolen);
    check(r == 1, "voronoi steal succeeded", "failed");
    check(l38_hs_depth(&h.queues[1]) == 4, "victim lost 1", "wrong");
}

/* ══ T09 ══ */
static void t09_steal_empty(void) {
    section("T09  Voronoi steal: 0 when all empty");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    L38Hydra h; l38_hydra_init(&h);
    L38HydraTask out;
    check(l38_voronoi_steal(&h, &vm, 0, &out) == 0, "steal empty=0", "wrong");
}

/* ══ T10 ══ */
static void t10_delaunay_steal(void) {
    section("T10  Delaunay steal: prefers boundary-eligible task");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    L38Hydra h; l38_hydra_init(&h);

    /* find a boundary cell and push task there */
    uint16_t bnd_cell = L38_BB_NODES;
    uint8_t  bnd_nbr  = 0;
    for (uint16_t c = 0; c < L38_BB_NODES; c++) {
        L38DelaunayCell dc = l38_delaunay_check(&vm, c);
        if (dc.near_boundary && dc.neighbor_head != vm.cell_to_head[c]) {
            bnd_cell = c;
            bnd_nbr  = dc.neighbor_head;
            break;
        }
    }
    if (bnd_cell < L38_BB_NODES) {
        uint32_t owner = vm.cell_to_head[bnd_cell];
        L38HydraTask t = {.op=L38_HS_OP_WRITE, .cell_id=bnd_cell, .addr=bnd_cell};
        l38_hs_push(&h.queues[owner], &t);

        L38HydraTask stolen;
        int r = l38_delaunay_steal(&h, &vm, bnd_nbr, &stolen);
        check(r == 1, "boundary cell stolen by neighbor", "failed");
        check(stolen.cell_id == bnd_cell, "correct task stolen", "wrong");
    } else {
        check(1, "skip: no boundary cells found (unusual lattice)", "");
    }
}

/* ══ T11 ══ */
static void t11_sleep_init(void) {
    section("T11  Sleep wire: all faces AWAKE at init");
    L38SleepWire sw; l38_sleep_wire_init(&sw);
    check(sw.magic == L38_SLEEP_MAGIC, "magic OK", "wrong");
    int all_awake = 1;
    for (int i = 0; i < L38_HS_HEADS; i++)
        if (sw.faces[i].state != L38_FACE_AWAKE) all_awake = 0;
    check(all_awake, "all 16 faces AWAKE", "wrong");
}

/* ══ T12 ══ */
static void t12_sleep_drowsy(void) {
    section("T12  Sleep tick: AWAKE→DROWSY after 18 idle ticks");
    L38SleepWire sw; l38_sleep_wire_init(&sw);
    L38Hydra h; l38_hydra_init(&h);
    /* head 3 queue empty → tick 18 times */
    for (int i = 0; i < (int)L38_SLEEP_IDLE_TICKS; i++)
        l38_sleep_tick(&sw, &h, 3);
    check(sw.faces[3].state == L38_FACE_DROWSY,
          "after 18 empty ticks → DROWSY", "wrong");
}

/* ══ T13 ══ */
static void t13_sleep_sleeping(void) {
    section("T13  Sleep tick: DROWSY→SLEEPING after 36 ticks");
    L38SleepWire sw; l38_sleep_wire_init(&sw);
    L38Hydra h; l38_hydra_init(&h);
    for (int i = 0; i < (int)(L38_SLEEP_IDLE_TICKS * 2); i++)
        l38_sleep_tick(&sw, &h, 5);
    check(sw.faces[5].state == L38_FACE_SLEEPING,
          "after 36 empty ticks → SLEEPING", "wrong");
    check(sw.faces[5].total_sleeps == 1, "total_sleeps=1", "wrong");
}

/* ══ T14 ══ */
static void t14_sleep_wake(void) {
    section("T14  Sleep wake: SLEEPING→AWAKE on work");
    L38SleepWire sw; l38_sleep_wire_init(&sw);
    L38Hydra h; l38_hydra_init(&h);
    /* force sleep */
    for (int i = 0; i < (int)(L38_SLEEP_IDLE_TICKS * 2); i++)
        l38_sleep_tick(&sw, &h, 2);
    check(sw.faces[2].state == L38_FACE_SLEEPING, "now sleeping", "wrong");
    /* push work → tick → wake */
    L38HydraTask t = {.op=1, .addr=1};
    l38_hs_push(&h.queues[2], &t);
    l38_sleep_tick(&sw, &h, 2);
    check(sw.faces[2].state == L38_FACE_AWAKE, "wake on work", "still sleeping");
    check(sw.faces[2].total_wakes >= 1, "total_wakes≥1", "wrong");
}

/* ══ T15 ══ */
static void t15_gate18_wake(void) {
    section("T15  Gate_18: all sleeping faces wake");
    L38SleepWire sw; l38_sleep_wire_init(&sw);
    L38Hydra h; l38_hydra_init(&h);
    /* sleep heads 0, 7, 15 */
    { int _faces[]={0,7,15};
      for(int _fi=0;_fi<3;_fi++) { int face=_faces[_fi];
        for(int i=0;i<(int)(L38_SLEEP_IDLE_TICKS*2);i++) l38_sleep_tick(&sw,&h,face); }}
    l38_sleep_gate18_wake(&sw);
    check(sw.faces[0].state == L38_FACE_AWAKE,  "head 0 awake",  "sleeping");
    check(sw.faces[7].state == L38_FACE_AWAKE,  "head 7 awake",  "sleeping");
    check(sw.faces[15].state == L38_FACE_AWAKE, "head 15 awake", "sleeping");
}

/* ══ T16 ══ */
static void t16_should_drain(void) {
    section("T16  should_drain: sleeping=no, awake/drowsy=yes");
    L38SleepWire sw; l38_sleep_wire_init(&sw);
    L38Hydra h; l38_hydra_init(&h);
    check(l38_sleep_should_drain(&sw, 0) == 1, "AWAKE → drain", "wrong");
    for (int i = 0; i < (int)(L38_SLEEP_IDLE_TICKS*2); i++)
        l38_sleep_tick(&sw, &h, 4);
    check(l38_sleep_should_drain(&sw, 4) == 0, "SLEEPING → no drain", "wrong");
}

/* ══ T17 ══ */
static void t17_steal_pipeline(void) {
    section("T17  steal_pipeline: sleeping head doesn't steal");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    L38Hydra h; l38_hydra_init(&h);
    L38SleepWire sw; l38_sleep_wire_init(&sw);

    /* sleep head 0 */
    for (int i = 0; i < (int)(L38_SLEEP_IDLE_TICKS*2); i++)
        l38_sleep_tick(&sw, &h, 0);
    /* push work to head 1 */
    L38HydraTask t = {.op=1, .cell_id=5, .addr=5};
    l38_hs_push(&h.queues[1], &t);

    L38HydraTask out;
    int r = l38_steal_pipeline(&h, &vm, &sw, 0, &out);
    check(r == 0, "sleeping head 0 → no steal", "stole anyway");
    check(l38_hs_depth(&h.queues[1]) == 1, "victim queue unchanged", "stolen");
}

/* ══ T18 ══ */
static void t18_voronoi_schedule(void) {
    section("T18  Voronoi schedule: cell→region, head wakes");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    L38Hydra h; l38_hydra_init(&h);
    L38SleepWire sw; l38_sleep_wire_init(&sw);

    /* sleep all heads */
    for (int f = 0; f < L38_HS_HEADS; f++)
        for (int i = 0; i < (int)(L38_SLEEP_IDLE_TICKS*2); i++)
            l38_sleep_tick(&sw, &h, f);

    /* schedule task for cell 36 (centroid 0 region) */
    L38HydraTask t = {.op=L38_HS_OP_WRITE, .cell_id=36, .addr=36};
    int hid = l38_voronoi_schedule(&h, &vm, &sw, &t);
    check(hid >= 0, "schedule OK", "failed");
    check(sw.faces[hid].state == L38_FACE_AWAKE, "destination woke", "sleeping");
    check(l38_hydra_total_depth(&h) == 1, "1 task queued", "wrong");
}

/* ══ T19 ══ */
static void t19_distribution(void) {
    section("T19  Distribution: 289 tasks → ≥12 heads used");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    L38Hydra h; l38_hydra_init(&h);
    L38SleepWire sw; l38_sleep_wire_init(&sw);

    /* schedule 1 task per cell */
    for (uint16_t c = 0; c < L38_BB_NODES; c++) {
        L38HydraTask t = {.op=L38_HS_OP_WRITE, .cell_id=c, .addr=c};
        l38_voronoi_schedule(&h, &vm, &sw, &t);
    }
    int heads_used = 0;
    for (int i = 0; i < L38_HS_HEADS; i++)
        if (l38_hs_depth(&h.queues[i]) > 0) heads_used++;
    check(heads_used >= 12, "≥12 heads receive tasks", "too clustered");
    printf("    (heads_used=%d / %u)\n", heads_used, L38_HS_HEADS);
}

/* ══ T20 ══ */
static void t20_no_clustering(void) {
    section("T20  No clustering: no head has >30% of tasks");
    L38VoronoiMap vm; l38_voronoi_init(&vm);
    L38Hydra h; l38_hydra_init(&h);
    L38SleepWire sw; l38_sleep_wire_init(&sw);

    for (uint16_t c = 0; c < L38_BB_NODES; c++) {
        L38HydraTask t = {.op=L38_HS_OP_WRITE, .cell_id=c, .addr=c};
        l38_voronoi_schedule(&h, &vm, &sw, &t);
    }
    uint32_t max_depth = 0;
    uint32_t max_head  = 0;
    for (uint32_t i = 0; i < L38_HS_HEADS; i++) {
        uint32_t d = l38_hs_depth(&h.queues[i]);
        if (d > max_depth) { max_depth = d; max_head = i; }
    }
    /* 30% of 289 ≈ 87 */
    check(max_depth <= 87, "max tasks/head ≤ 87 (≤30%)", "clustering");
    printf("    (max_depth=%u head=%u  = %.1f%%)\n",
           max_depth, max_head,
           100.0 * max_depth / L38_BB_NODES);
}

/* ══ MAIN ══ */
int main(void) {
    printf("══════════════════════════════════════════════════\n");
    printf("  POGLS38 — Voronoi Steal + Sleep Wire Tests\n");
    printf("  geometry-aware | no clustering | face sleep\n");
    printf("══════════════════════════════════════════════════\n");

    t01_centroids();
    t02_all_assigned();
    t03_balanced();
    t04_route();
    t05_torus_dist();
    t06_delaunay_boundary();
    t07_delaunay_centroid();
    t08_voronoi_steal();
    t09_steal_empty();
    t10_delaunay_steal();
    t11_sleep_init();
    t12_sleep_drowsy();
    t13_sleep_sleeping();
    t14_sleep_wake();
    t15_gate18_wake();
    t16_should_drain();
    t17_steal_pipeline();
    t18_voronoi_schedule();
    t19_distribution();
    t20_no_clustering();

    int total = _pass + _fail;
    printf("\n══════════════════════════════════════════════════\n");
    if (_fail == 0)
        printf("  %d / %d PASS  \033[32mv ALL PASS — voronoi live 🗺\033[0m\n",
               _pass, total);
    else
        printf("  %d / %d PASS  \033[31mx %d FAILED\033[0m\n",
               _pass, total, _fail);
    printf("══════════════════════════════════════════════════\n");
    return _fail ? 1 : 0;
}
