/*
 * test_38_slice.c — POGLS38 EngineSlice Tests
 *
 * T01  Slice size=24B, init A/B/C correct
 * T02  Lane ownership: 0-17=A, 18-35=B, 36-53=C
 * T03  Ghost cross-slice: 100% cross, K3 (A↔B↔C)
 * T04  Hop guard: 0,1 ok / 2+ blocked
 * T05  Ghost tag: pack/unpack origin+hops
 * T06  slice_owns_lane / slice_owns_node
 * T07  NULL safety
 * T08  HoneycombSlot: Tails mark/read slice_id
 * T09  HoneycombSlot: slice_flags set correctly
 * T10  HoneycombSlot: engine fields untouched after Tails write
 * T11  17n cell mapping: 0-95=A, 96-191=B, 192-288=C
 * T12  slice_owns_cell: boundaries correct
 * T13  289 cells: all assigned to a slice
 * T14  SliceCtrl init: only A active
 * T15  Split: activates B, active_count=2
 * T16  Split blocked: at max (2 active)
 * T17  Split blocked: cooldown > 0
 * T18  Rejoin: deactivates B, back to 1
 * T19  Rejoin blocked: only 1 active
 * T20  gate_18 tick: split_tick increments
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "../pogls_38_slice.h"

static int _pass=0,_fail=0;
static void check(int ok,const char*p,const char*f){
    if(ok){printf("    \033[32mv\033[0m %s\n",p);_pass++;}
    else  {printf("    \033[31mx FAIL\033[0m: %s\n",f);_fail++;}
}
static void section(const char*s){printf("\n  -- %s\n",s);}

/* ══ T01-T07: port from V4 ══ */
static void t01_init(void){
    section("T01  Slice init: 24B, A/B/C correct");
    check(sizeof(L38EngineSlice)==24u,"L38EngineSlice=24B","wrong");
    L38SliceSet ss; l38_slice_set_init(&ss);
    for(int i=0;i<3;i++){
        L38EngineSlice *s=&ss.slices[i];
        check(s->engine_id==(uint8_t)i,    "engine_id ok",  "wrong");
        check(s->lane_start==(uint8_t)(i*18),"lane_start ok","wrong");
        check(s->lane_count==18,            "lane_count=18", "wrong");
        check(s->node_start==(uint8_t)(i*54),"node_start ok","wrong");
        check(s->node_count==54,            "node_count=54", "wrong");
        check(s->active==1,                 "active=1",      "wrong");
        check(s->magic==L38_SLICE_MAGIC,    "magic ok",      "wrong");
    }
}

static void t02_lane_owner(void){
    section("T02  Lane ownership");
    check(l38_slice_owner_of_lane(0)==0, "lane 0  → A","wrong");
    check(l38_slice_owner_of_lane(17)==0,"lane 17 → A","wrong");
    check(l38_slice_owner_of_lane(18)==1,"lane 18 → B","wrong");
    check(l38_slice_owner_of_lane(35)==1,"lane 35 → B","wrong");
    check(l38_slice_owner_of_lane(36)==2,"lane 36 → C","wrong");
    check(l38_slice_owner_of_lane(53)==2,"lane 53 → C","wrong");
}

static void t03_ghost_cross(void){
    section("T03  Ghost cross-slice: 100% cross, K3");
    int all_cross=1;
    for(int lane=0;lane<54;lane++){
        uint8_t src=l38_slice_owner_of_lane((uint8_t)lane);
        uint8_t dst=l38_slice_ghost_dst((uint8_t)lane);
        if(src==dst){all_cross=0;}
    }
    check(all_cross,"100% ghost lanes cross slice","some stayed");
    /* K3: A→B and A→C each get 9 lanes */
    int a_to_b=0,a_to_c=0;
    for(int lane=0;lane<18;lane++){
        uint8_t dst=l38_slice_ghost_dst((uint8_t)lane);
        if(dst==1)a_to_b++;
        if(dst==2)a_to_c++;
    }
    check(a_to_b==9,"A→B: 9 lanes","wrong");
    check(a_to_c==9,"A→C: 9 lanes","wrong");
}

static void t04_hop_guard(void){
    section("T04  Hop guard: 0,1 ok / 2+ blocked");
    L38EngineSlice s; l38_slice_init(&s,0);
    check( l38_slice_hop_ok(&s,0), "hop 0 ok",       "wrong");
    check( l38_slice_hop_ok(&s,1), "hop 1 ok",       "wrong");
    check(!l38_slice_hop_ok(&s,2), "hop 2 blocked",  "wrong");
    check(!l38_slice_hop_ok(&s,99),"hop 99 blocked", "wrong");
}

static void t05_ghost_tag(void){
    section("T05  Ghost tag: pack/unpack");
    uint16_t tag=l38_slice_ghost_tag(2,1);
    check(l38_slice_tag_origin(tag)==2,"origin=2","wrong");
    check(l38_slice_tag_hops(tag)==1,  "hops=1",  "wrong");
    tag=l38_slice_ghost_tag(0,0);
    check(l38_slice_tag_origin(tag)==0,"origin=0","wrong");
    check(l38_slice_tag_hops(tag)==0,  "hops=0",  "wrong");
}

static void t06_owns(void){
    section("T06  owns_lane / owns_node");
    L38EngineSlice s; l38_slice_init(&s,1); /* B: lanes 18-35 */
    check( l38_slice_owns_lane(&s,18),"owns lane 18","wrong");
    check( l38_slice_owns_lane(&s,35),"owns lane 35","wrong");
    check(!l38_slice_owns_lane(&s,17),"not lane 17", "wrong");
    check(!l38_slice_owns_lane(&s,36),"not lane 36", "wrong");
    check( l38_slice_owns_node(&s,54),"owns node 54","wrong");
    check(!l38_slice_owns_node(&s,53),"not node 53", "wrong");
}

static void t07_null(void){
    section("T07  NULL safety");
    l38_slice_init(NULL,0);
    l38_slice_set_init(NULL);
    check(!l38_slice_owns_lane(NULL,0),"owns_lane(NULL)=0","crash");
    check(!l38_slice_hop_ok(NULL,0),   "hop_ok(NULL)=0",   "crash");
    check(!l38_slice_owns_cell(NULL,0),"owns_cell(NULL)=0","crash");
    check(1,"null paths ok","crash");
}

/* ══ T08-T10: HoneycombSlot ══ */
static void t08_honeycomb_slice_id(void){
    section("T08  HoneycombSlot: Tails mark/read slice_id");
    L38DiamondBlock b=l38_diamond_init(1,2,100,4,L38_WORLD_A);
    /* honeycomb starts zeroed */
    check(l38_tails_read_slice_id(&b)==0,"slice_id=0 initially","wrong");
    l38_tails_mark_slice(&b, 1, L38_SFLAG_ACTIVE);
    check(l38_tails_read_slice_id(&b)==1,"slice_id=1 after mark","wrong");
    l38_tails_mark_slice(&b, 2, L38_SFLAG_SPLIT);
    check(l38_tails_read_slice_id(&b)==2,"slice_id=2 update",   "wrong");
}

static void t09_honeycomb_flags(void){
    section("T09  HoneycombSlot: slice_flags");
    L38DiamondBlock b=l38_diamond_init(0,0,0,4,L38_WORLD_A);
    l38_tails_mark_slice(&b, 0, L38_SFLAG_ACTIVE | L38_SFLAG_GHOST);
    uint8_t fl=l38_tails_read_slice_flags(&b);
    check(fl & L38_SFLAG_ACTIVE,"ACTIVE flag set","missing");
    check(fl & L38_SFLAG_GHOST, "GHOST flag set", "missing");
    check(!(fl & L38_SFLAG_SPLIT),"SPLIT not set","wrong");
}

static void t10_honeycomb_engine_untouched(void){
    section("T10  HoneycombSlot: engine fields survive Tails write");
    L38DiamondBlock b=l38_diamond_init(5,7,12345,8,L38_WORLD_B);
    uint8_t face=l38_core_face_id(b.core);
    uint8_t eng =l38_core_engine_id(b.core);
    /* Tails writes slice info */
    l38_tails_mark_slice(&b, 1, L38_SFLAG_SPLIT);
    /* engine fields in CoreSlot untouched */
    check(l38_core_face_id(b.core)==face, "face_id preserved","changed");
    check(l38_core_engine_id(b.core)==eng,"engine_id preserved","changed");
    /* mirror still valid */
    check(l38_diamond_verify(&b),"XOR guard still valid","broken");
}

/* ══ T11-T13: 17n cell mapping ══ */
static void t11_cell_mapping(void){
    section("T11  17n cell mapping: 0-95=A, 96-191=B, 192-288=C");
    check(l38_slice_of_cell(0)==0,   "cell 0   → A","wrong");
    check(l38_slice_of_cell(95)==0,  "cell 95  → A","wrong");
    check(l38_slice_of_cell(96)==1,  "cell 96  → B","wrong");
    check(l38_slice_of_cell(191)==1, "cell 191 → B","wrong");
    check(l38_slice_of_cell(192)==2, "cell 192 → C","wrong");
    check(l38_slice_of_cell(288)==2, "cell 288 → C","wrong");
}

static void t12_owns_cell(void){
    section("T12  slice_owns_cell boundaries");
    L38EngineSlice sa,sb,sc;
    l38_slice_init(&sa,0); l38_slice_init(&sb,1); l38_slice_init(&sc,2);
    check( l38_slice_owns_cell(&sa,0),   "A owns cell 0",  "wrong");
    check( l38_slice_owns_cell(&sa,95),  "A owns cell 95", "wrong");
    check(!l38_slice_owns_cell(&sa,96),  "A !owns cell 96","wrong");
    check( l38_slice_owns_cell(&sb,96),  "B owns cell 96", "wrong");
    check(!l38_slice_owns_cell(&sb,192), "B !owns 192",    "wrong");
    check( l38_slice_owns_cell(&sc,288), "C owns cell 288","wrong");
}

static void t13_all_cells_assigned(void){
    section("T13  All 289 cells assigned to exactly 1 slice");
    int counts[3]={0};
    for(uint16_t c=0;c<289;c++){
        uint8_t s=l38_slice_of_cell(c);
        check(s<3,"cell slice_id < 3","OOB");
        counts[s]++;
    }
    check(counts[0]==96, "A gets 96 cells","wrong");
    check(counts[1]==96, "B gets 96 cells","wrong");
    check(counts[2]==97, "C gets 97 cells","wrong");
    check(counts[0]+counts[1]+counts[2]==289,"total=289","wrong");
    printf("    (A=%d B=%d C=%d total=%d)\n",
           counts[0],counts[1],counts[2],counts[0]+counts[1]+counts[2]);
}

/* ══ T14-T20: SliceCtrl + Spawn ══ */
static void t14_ctrl_init(void){
    section("T14  SliceCtrl init: only A active");
    L38SliceCtrl sc; l38_slice_ctrl_init(&sc);
    check(sc.active_count==1,              "active_count=1",  "wrong");
    check(sc.active_mask==1,               "mask=0x01 (A)",   "wrong");
    check(sc.slices.slices[0].active==1,   "A active=1",      "wrong");
    check(sc.slices.slices[1].active==0,   "B active=0",      "wrong");
    check(sc.slices.slices[2].active==0,   "C active=0",      "wrong");
}

static void t15_split(void){
    section("T15  Split: activates B, active_count=2");
    L38SliceCtrl sc; l38_slice_ctrl_init(&sc);
    L38SpawnCtrl sp; l38_spawn_init(&sp, L38_SPAWN_MAX_SPLIT, 1);
    int r=l38_slice_split(&sc, &sp);
    check(r==1,                           "split returns 1",  "fail");
    check(sc.active_count==2,             "active_count=2",   "wrong");
    check(sc.active_mask==3,              "mask=0x03 (A+B)",  "wrong");
    check(sc.slices.slices[1].active==1,  "B active=1",       "wrong");
    check(sc.total_splits==1,             "total_splits=1",   "wrong");
}

static void t16_split_at_max(void){
    section("T16  Split blocked: already at max=2");
    L38SliceCtrl sc; l38_slice_ctrl_init(&sc);
    L38SpawnCtrl sp; l38_spawn_init(&sp, L38_SPAWN_MAX_SPLIT, 1);
    l38_slice_split(&sc, &sp);           /* first split: OK */
    int r=l38_slice_split(&sc, &sp);     /* second: at max */
    check(r==-2,"split at max → -2","wrong");
    check(sc.active_count==2,"still 2 (no extra)","changed");
}

static void t17_split_cooldown(void){
    section("T17  Split blocked: cooldown > 0");
    L38SliceCtrl sc; l38_slice_ctrl_init(&sc);
    L38SpawnCtrl sp; l38_spawn_init(&sp, L38_SPAWN_MAX_SPLIT, 1);
    sp.cooldown_ticks=10;
    int r=l38_slice_split(&sc, &sp);
    check(r==-3,"cooldown → -3","wrong");
    check(sc.active_count==1,"still 1 head","changed");
}

static void t18_rejoin(void){
    section("T18  Rejoin: deactivates B, back to 1");
    L38SliceCtrl sc; l38_slice_ctrl_init(&sc);
    L38SpawnCtrl sp; l38_spawn_init(&sp, L38_SPAWN_MAX_SPLIT, 1);
    l38_slice_split(&sc, &sp);           /* split first */
    sp.cooldown_ticks=0;                 /* reset cooldown */
    int r=l38_slice_rejoin(&sc, &sp);
    check(r==1,                          "rejoin returns 1",  "fail");
    check(sc.active_count==1,            "active_count=1",    "wrong");
    check(sc.slices.slices[1].active==0, "B inactive",        "wrong");
    check(sc.total_rejoins==1,           "total_rejoins=1",   "wrong");
}

static void t19_rejoin_blocked(void){
    section("T19  Rejoin blocked: only 1 active");
    L38SliceCtrl sc; l38_slice_ctrl_init(&sc);
    L38SpawnCtrl sp; l38_spawn_init(&sp, L38_SPAWN_MAX_SPLIT, 1);
    int r=l38_slice_rejoin(&sc, &sp);
    check(r==-2,"rejoin with 1 active → -2","wrong");
}

static void t20_gate18_tick(void){
    section("T20  gate_18 tick: split_tick increments");
    L38SliceCtrl sc; l38_slice_ctrl_init(&sc);
    check(sc.split_tick==0,"split_tick=0","wrong");
    l38_slice_gate18(&sc);
    l38_slice_gate18(&sc);
    l38_slice_gate18(&sc);
    check(sc.split_tick==3,"split_tick=3 after 3 ticks","wrong");
    l38_slice_stats(&sc);
    check(1,"stats printed","crash");
}

int main(void){
    printf("══════════════════════════════════════════════════\n");
    printf("  POGLS38 — EngineSlice Tests\n");
    printf("  A/B/C | Ghost K3 | Honeycomb | Split/Rejoin\n");
    printf("══════════════════════════════════════════════════\n");
    t01_init(); t02_lane_owner(); t03_ghost_cross();
    t04_hop_guard(); t05_ghost_tag(); t06_owns(); t07_null();
    t08_honeycomb_slice_id(); t09_honeycomb_flags();
    t10_honeycomb_engine_untouched();
    t11_cell_mapping(); t12_owns_cell(); t13_all_cells_assigned();
    t14_ctrl_init(); t15_split(); t16_split_at_max();
    t17_split_cooldown(); t18_rejoin(); t19_rejoin_blocked();
    t20_gate18_tick();
    int total=_pass+_fail;
    printf("\n══════════════════════════════════════════════════\n");
    if(!_fail)
        printf("  %d / %d PASS  \033[32mv ALL PASS — slice live ⚔\033[0m\n",_pass,total);
    else
        printf("  %d / %d PASS  \033[31mx %d FAILED\033[0m\n",_pass,total,_fail);
    printf("══════════════════════════════════════════════════\n");
    return _fail?1:0;
}
