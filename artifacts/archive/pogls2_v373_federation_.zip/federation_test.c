/*
 * federation_test.c — POGLS Federation Layer Tests
 * ══════════════════════════════════════════════════════════════════
 *
 * Tests cover 4 critical points:
 *   T01-T04  Pre-commit Gate       (iso / audit / ghost maturity)
 *   T05-T07  Backpressure          (HWM / LWM / hard cap)
 *   T08-T10  Early Merkle          (update / reduce / reset)
 *   T11-T13  Shadow Snapshot       (double-buffer / split commit)
 *   T14      Full round-trip        (GPU → gate → bp → em → snap)
 *
 * Compile (no V4 deps needed — stubs below):
 *   gcc -O2 -std=c11 -I.. federation_test.c -o fed_test && ./fed_test
 *
 * ══════════════════════════════════════════════════════════════════
 */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>

/* ── minimal stubs (replace with real V4 when linking full codebase) ── */

/* POGLS_GHOST_STREAK_MAX needed by fed_gate */
#ifndef POGLS_GHOST_STREAK_MAX
#  define POGLS_GHOST_STREAK_MAX 8u
#endif

/* Stub delta types so pogls_federation.h compiles standalone */
typedef struct { int dummy; } Delta_Context;
typedef struct { int dummy; } Delta_ContextB;
typedef struct { Delta_Context a; Delta_ContextB b; } Delta_ContextAB;
typedef struct { int world_a; int world_b; } Delta_DualRecovery;

static inline int  delta_commit(Delta_Context *c)       { (void)c; return 0; }
static inline int  delta_b_close(Delta_ContextB *b)     { (void)b; return 0; }
static inline int  delta_b_open(Delta_ContextB *b,
                                 const char *s)          { (void)b;(void)s; return 0; }
static inline int  delta_ab_open(Delta_ContextAB *c,
                                  const char *s)         { (void)c;(void)s; return 0; }
static inline int  delta_ab_commit(Delta_ContextAB *c)  { (void)c; return 0; }
static inline void delta_ab_close(Delta_ContextAB *c)   { (void)c; }
static inline Delta_DualRecovery delta_ab_recover(const char *s)
{ (void)s; Delta_DualRecovery r={0,0}; return r; }
static inline int  delta_append(Delta_Context *c, uint8_t l,
                                 uint64_t a, const void *d,
                                 uint32_t s)
{ (void)c;(void)l;(void)a;(void)d;(void)s; return 0; }

/* Now include the real header */
#include "pogls_federation.h"

/* ── test harness ─────────────────────────────────────────────── */
static int g_pass = 0, g_fail = 0;
#define section(s) printf("\n  -- %s\n", s)
#define check(cond, ok, fail) do { \
    if (cond) { printf("    v %s\n", ok);   g_pass++; } \
    else       { printf("    x FAIL: %s\n", fail); g_fail++; } \
} while(0)

/* helper: build packed = PACK(hilbert, lane, iso)
 * hilbert = lane * K so that (hilbert % 54) == lane */
static inline uint32_t make_packed(uint32_t lane, uint32_t iso)
{
    /* hilbert = lane + 54 * N so hilbert % 54 == lane */
    uint32_t hil = lane;   /* 0..53, satisfies audit */
    return (hil & 0xFFFFFu) | ((lane & 0x3Fu) << 20) | ((iso & 1u) << 26);
}

/* ── T01-T04: Pre-commit Gate ─────────────────────────────────── */
static void t01_gate_iso(void)
{
    section("T01  Gate — iso=1 → DROP");
    GateStats gs = {0};
    uint32_t packed = make_packed(5, 1);   /* iso=1 */
    GateResult r = fed_gate(packed, 100, &gs);
    check(r == GATE_DROP,    "iso=1 → DROP",        "wrong result");
    check(gs.dropped == 1,   "dropped counter +1",  "counter wrong");
    check(gs.passed  == 0,   "passed = 0",          "should not pass");
}

static void t02_gate_audit_fail(void)
{
    section("T02  Gate — hilbert%54 != lane → DROP");
    GateStats gs = {0};
    /* hilbert=10, lane=5 → 10%54=10 ≠ 5 → audit fail */
    uint32_t packed = (10u & 0xFFFFFu) | ((5u & 0x3Fu) << 20) | 0u;
    GateResult r = fed_gate(packed, 100, &gs);
    check(r == GATE_DROP,  "audit fail → DROP", "wrong result");
    check(gs.dropped == 1, "dropped +1",        "counter wrong");
}

static void t03_gate_ghost_warmup(void)
{
    section("T03  Gate — op_count < 8 → GHOST");
    GateStats gs = {0};
    uint32_t packed = make_packed(3, 0);   /* iso=0, audit ok */
    GateResult r = fed_gate(packed, 3, &gs);   /* op_count=3 < 8 */
    check(r == GATE_GHOST, "warm-up → GHOST", "wrong result");
    check(gs.ghosted == 1, "ghosted +1",      "counter wrong");
}

static void t04_gate_pass(void)
{
    section("T04  Gate — iso=0, audit ok, mature → PASS");
    GateStats gs = {0};
    uint32_t packed = make_packed(7, 0);   /* iso=0, audit ok */
    GateResult r = fed_gate(packed, 100, &gs);  /* op_count=100 ≥ 8 */
    check(r == GATE_PASS, "normal → PASS", "wrong result");
    check(gs.passed == 1, "passed +1",     "counter wrong");
}

/* ── T05-T07: Backpressure ────────────────────────────────────── */
static void t05_bp_normal(void)
{
    section("T05  Backpressure — below HWM → ok");
    BackpressureCtx bp; bp_init(&bp);
    for (uint32_t i = 0; i < 100; i++) bp_push(&bp);
    check(bp_check(&bp) == 0, "100 < HWM(4096) → no throttle", "wrong");
    check(bp.queue_depth == 100, "depth=100", "wrong");
}

static void t06_bp_hwm(void)
{
    section("T06  Backpressure — exceed HWM → throttle");
    BackpressureCtx bp; bp_init(&bp);
    for (uint32_t i = 0; i < FED_QUEUE_HWM + 1; i++) bp_push(&bp);
    check(bp_check(&bp) == 1, "depth > HWM → throttle", "wrong");
    check(bp.throttle_count >= 1, "throttle_count++", "wrong");
}

static void t07_bp_drain(void)
{
    section("T07  Backpressure — drain below LWM → resume");
    BackpressureCtx bp; bp_init(&bp);
    for (uint32_t i = 0; i < FED_QUEUE_HWM + 10; i++) bp_push(&bp);
    /* drain down to 100 (below LWM) */
    while (bp.queue_depth > 100) bp_pop(&bp);
    check(bp.queue_depth <= bp.lwm, "depth ≤ LWM after drain", "wrong");
    /* after drain, bp_check should be clear (not throttle) */
    check(bp_check(&bp) == 0, "below LWM → no throttle", "wrong");
}

/* ── T08-T10: Early Merkle ────────────────────────────────────── */
static void t08_em_update(void)
{
    section("T08  Early Merkle — update changes tile hash");
    EarlyMerkle em; em_init(&em);
    uint8_t before[FED_TILE_HASH_SZ];
    memcpy(before, em.tile_hash[0], FED_TILE_HASH_SZ);
    uint8_t data[8] = {1,2,3,4,5,6,7,8};
    em_update(&em, 0, data, 8);
    check(memcmp(em.tile_hash[0], before, FED_TILE_HASH_SZ) != 0,
          "hash changed after update", "unchanged — update broken");
    check(em.tile_count[0] == 1, "tile_count[0]=1", "wrong");
}

static void t09_em_reduce(void)
{
    section("T09  Early Merkle — reduce sets root_valid");
    EarlyMerkle em; em_init(&em);
    uint8_t d[8] = {0xAB,0xCD,0xEF,0,0,0,0,0};
    em_update(&em, 0, d, 8);
    uint8_t d2[8] = {0x12,0x34,0x56,0x78,0,0,0,0};
    em_update(&em, 5, d2, 8);
    em_reduce(&em);
    check(em.root_valid == 1, "root_valid=1 after reduce", "wrong");
    /* root ≠ zero when tiles have data */
    uint8_t zero[FED_TILE_HASH_SZ] = {0};
    check(memcmp(em.root, zero, FED_TILE_HASH_SZ) != 0,
          "root is non-zero", "root stayed zero — reduce broken");
}

static void t10_em_deterministic(void)
{
    section("T10  Early Merkle — same writes → same root");
    EarlyMerkle em1, em2;
    em_init(&em1); em_init(&em2);
    uint8_t d[8] = {1,2,3,4,5,6,7,8};
    for (int i = 0; i < 10; i++) {
        em_update(&em1, (uint8_t)(i % 54), d, 8);
        em_update(&em2, (uint8_t)(i % 54), d, 8);
    }
    em_reduce(&em1); em_reduce(&em2);
    check(memcmp(em1.root, em2.root, FED_TILE_HASH_SZ) == 0,
          "same input → same root (deterministic)", "non-deterministic!");
}

/* ── T11-T13: Shadow Snapshot ─────────────────────────────────── */
static void t11_ss_init(void)
{
    section("T11  Shadow Snapshot — init");
    ShadowSnapshot ss;
    int r = ss_init(&ss, "/tmp/fed_test");
    check(r == 0,          "ss_init ok",    "failed");
    check(ss.active == 0,  "active=0",      "wrong slot");
    check(ss.epoch  == 0,  "epoch=0",       "wrong epoch");
    ss_close(&ss);
}

static void t12_ss_commit_swaps(void)
{
    section("T12  Shadow Snapshot — commit swaps active slot");
    ShadowSnapshot ss; ss_init(&ss, "/tmp/fed_test");
    int before = ss.active;
    ss_commit(&ss);
    check(ss.active != before, "active slot swapped", "not swapped");
    check(ss.epoch  == 1,      "epoch=1 after commit", "wrong epoch");
    ss_close(&ss);
}

static void t13_ss_split_commit(void)
{
    section("T13  Shadow Snapshot — A commit does not block on B");
    /* With stubs, both delta_commit() and delta_b_close() return 0.
     * The important thing: ss_commit returns 0 (not -1) even if
     * we simulate B failure by checking return codes. */
    ShadowSnapshot ss; ss_init(&ss, "/tmp/fed_test");
    int r = ss_commit(&ss);
    check(r != -1,    "A commit succeeded (r != -1)", "A failed");
    check(r == 0,     "B also ok (r=0)",               "B failed");
    ss_close(&ss);
}

/* ── T14: Full round-trip ─────────────────────────────────────── */
static void t14_full_roundtrip(void)
{
    section("T14  Full round-trip: GPU → gate → bp → em → snap");
    FederationCtx f;
    int r = fed_init(&f, "/tmp/fed_test");
    check(r == 0, "fed_init ok", "init failed");

    /* simulate 20 GPU cells: mix of pass/drop/ghost */
    uint32_t pass=0, ghost=0, drop=0;
    for (uint32_t i = 0; i < 20; i++) {
        uint32_t lane = i % 54;
        /* every 5th = iso, every 3rd in warmup = ghost */
        uint32_t iso = (i % 5 == 4) ? 1u : 0u;
        uint32_t packed = make_packed(lane, iso);
        uint64_t addr   = (uint64_t)i * 12345 + 1;
        uint64_t value  = (uint64_t)i * 0xDEADBEEFull;

        f.op_count = (i < 8) ? i : 100;  /* seed mature after 8 */
        GateResult gr = fed_write(&f, packed, addr, value);
        if      (gr == GATE_PASS)  pass++;
        else if (gr == GATE_GHOST) ghost++;
        else                       drop++;
    }

    check(drop  > 0,  "some cells dropped (iso=1)",   "none dropped");
    check(ghost > 0,  "some cells ghosted (warmup)",  "none ghosted");
    check(pass  > 0,  "some cells passed",            "none passed");

    /* commit */
    r = fed_commit(&f);
    check(r != -1, "commit succeeded", "commit failed");

    /* merkle reset after commit */
    check(f.em.root_valid == 0, "em reset after commit", "not reset");

    /* epoch advanced */
    check(f.ss.epoch == 1, "epoch=1 after commit", "wrong epoch");

    fed_stats(&f);
    fed_close(&f);
}

/* ── main ─────────────────────────────────────────────────────── */
int main(void)
{
    printf("══════════════════════════════════════════════════\n");
    printf("  POGLS Federation Layer — Test Suite\n");
    printf("══════════════════════════════════════════════════\n");

    /* Gate */
    t01_gate_iso();
    t02_gate_audit_fail();
    t03_gate_ghost_warmup();
    t04_gate_pass();

    /* Backpressure */
    t05_bp_normal();
    t06_bp_hwm();
    t07_bp_drain();

    /* Early Merkle */
    t08_em_update();
    t09_em_reduce();
    t10_em_deterministic();

    /* Shadow Snapshot */
    t11_ss_init();
    t12_ss_commit_swaps();
    t13_ss_split_commit();

    /* Full round-trip */
    t14_full_roundtrip();

    printf("\n══════════════════════════════════════════════════\n");
    if (g_fail == 0)
        printf("  %d / %d PASS  v ALL PASS — Federation live\n",
               g_pass, g_pass);
    else
        printf("  %d / %d PASS  x %d FAILED\n",
               g_pass, g_pass + g_fail, g_fail);
    printf("══════════════════════════════════════════════════\n");

    return g_fail > 0 ? 1 : 0;
}
