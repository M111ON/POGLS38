/*
 * test_rewind.c — Phase B2: RewindBuffer Tests
 * ─────────────────────────────────────────────
 * T01: init + validate
 * T02: push single slot — ring state correct
 * T03: push 18 slots — auto-flush triggered at gate_18
 * T04: rewind N steps — unconfirmed rolled back correctly
 * T05: rewind cap — cannot rewind confirmed slots
 * T06: nexus checkpoint — taken at every 54 writes
 * T07: rewind_to_checkpoint — fast seek to nexus boundary
 * T08: ring wrap (epoch) — overflow evicts oldest, epoch increments
 * T09: rewind_peek — read without modify
 * T10: global_id determinism — same slot → same id
 * T11: flush_fn callback — called correctly on gate flush
 * T12: DNA integration — tails_dna_record called via rewind_push_with_dna
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* bring in POGLS38 fold types for DiamondBlock */
#include "pogls_fold.h"
#include "pogls_38_rewind.h"

/* ── harness ──────────────────────────────────────────────────────── */
static int _pass = 0, _fail = 0;
#define ASSERT(cond, msg) do { \
    if (cond) { printf("  [PASS] %s\n", msg); _pass++; } \
    else       { printf("  [FAIL] %s  (line %d)\n", msg, __LINE__); _fail++; } \
} while(0)

/* flush stub — counts calls */
static int  _flush_calls = 0;
static int  _flush_stub(void *ctx, uint8_t lane_id,
                         uint64_t addr, const void *data, uint32_t sz)
{
    (void)ctx; (void)lane_id; (void)addr; (void)data; (void)sz;
    _flush_calls++;
    return 0;
}

/* make a simple DiamondBlock for testing */
static DiamondBlock make_block(uint32_t val)
{
    DiamondBlock b;
    memset(&b, 0, sizeof(b));
    b.core.raw = (uint64_t)val;
    b.invert   = ~b.core.raw;
    return b;
}

/* ── T01: init + validate ─────────────────────────────────────────── */
static void test_01_init(void)
{
    printf("\nT01: init + validate\n");
    RewindBuffer rb;
    int r = rewind_init(&rb, NULL, NULL, NULL);
    ASSERT(r == 0,                      "rewind_init returns 0");
    ASSERT(rb.magic == REWIND_MAGIC,    "magic correct");
    ASSERT(rb.head == 0,                "head = 0");
    ASSERT(rb.confirmed == 0,           "confirmed = 0");
    ASSERT(rb.count == 0,               "count = 0");
    ASSERT(rb.epoch == 0,               "epoch = 0");
    ASSERT(rewind_validate(&rb) == REWIND_OK, "validate = REWIND_OK");
    ASSERT(rewind_depth(&rb) == 0,      "depth = 0 after init");

    /* sacred number checks */
    ASSERT(REWIND_GATE   == 18u,  "REWIND_GATE = 18 (sacred)");
    ASSERT(REWIND_NEXUS  == 54u,  "REWIND_NEXUS = 54 (sacred)");
    ASSERT(REWIND_SPHERE == 162u, "REWIND_SPHERE = 162 (sacred)");
    ASSERT(REWIND_MAX    == 972u, "REWIND_MAX = 972 (sacred)");
    ASSERT(REWIND_CKPT_COUNT == 18u, "REWIND_CKPT_COUNT = 18");
}

/* ── T02: push single slot ────────────────────────────────────────── */
static void test_02_push_single(void)
{
    printf("\nT02: push single slot\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    DiamondBlock b = make_block(0xABCD1234);
    uint32_t idx = rewind_push(&rb, &b, 0x1000, 5);

    ASSERT(idx == 0,             "first push → slot 0");
    ASSERT(rb.head == 1,         "head = 1 after push");
    ASSERT(rb.count == 1,        "count = 1");
    ASSERT(rb.confirmed == 0,    "confirmed = 0 (not flushed yet)");
    ASSERT(rewind_depth(&rb)==1, "depth = 1");

    const DiamondBlock *p = rewind_peek(&rb, 0);
    ASSERT(p != NULL,            "peek(0) not NULL");
    ASSERT(p->core.raw == 0xABCD1234, "peek returns correct block");

    /* addr + lane stored */
    ASSERT(rb.slots[0].addr    == 0x1000, "slot addr stored");
    ASSERT(rb.slots[0].lane_id == 5,      "slot lane_id stored");
}

/* ── T03: push 18 → auto flush ────────────────────────────────────── */
static void test_03_auto_flush(void)
{
    printf("\nT03: push 18 slots → auto-flush at gate_18\n");
    _flush_calls = 0;
    RewindBuffer rb;
    rewind_init(&rb, _flush_stub, NULL, NULL);

    for (uint32_t i = 0; i < REWIND_GATE; i++) {
        DiamondBlock b = make_block((uint32_t)i);
        rewind_push(&rb, &b, (uint32_t)(i * 0x100), 0);
    }

    ASSERT(rb.stats.total_writes == REWIND_GATE,
           "18 writes recorded");
    ASSERT(_flush_calls == REWIND_GATE,
           "flush_fn called 18 times (1 per confirmed slot)");
    ASSERT(rb.confirmed == REWIND_GATE,
           "confirmed = 18 after auto-flush");
    ASSERT(rb.stats.total_flushes == 1,
           "total_flushes = 1 (1 gate batch)");
}

/* ── T04: rewind N steps ──────────────────────────────────────────── */
static void test_04_rewind(void)
{
    printf("\nT04: rewind N steps\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    /* push 10 (no auto-flush without flush_fn) */
    for (int i = 0; i < 10; i++) {
        DiamondBlock b = make_block((uint32_t)i);
        rewind_push(&rb, &b, (uint32_t)i, 0);
    }
    ASSERT(rb.head == 10, "head = 10 after 10 pushes");
    ASSERT(rewind_depth(&rb) == 10, "depth = 10");

    /* rewind 3 */
    uint32_t stepped = rewind_back(&rb, 3);
    ASSERT(stepped == 3,           "rewind(3) returns 3");
    ASSERT(rb.head == 7,           "head = 7 after rewind(3)");
    ASSERT(rewind_depth(&rb) == 7, "depth = 7");
    ASSERT(rb.stats.steps_rewound == 3, "steps_rewound = 3");

    /* peek should show slot 6 (index 6, 0-based) */
    const DiamondBlock *p = rewind_peek(&rb, 0);
    ASSERT(p != NULL && p->core.raw == 6, "peek after rewind = correct last slot");
}

/* ── T05: rewind cap — cannot rewind confirmed ───────────────────── */
static void test_05_rewind_cap(void)
{
    printf("\nT05: rewind cap — confirmed slots immutable\n");
    _flush_calls = 0;
    RewindBuffer rb;
    rewind_init(&rb, _flush_stub, NULL, NULL);

    /* push 18 → auto-flushed, confirmed=18 */
    for (uint32_t i = 0; i < REWIND_GATE; i++) {
        DiamondBlock b = make_block((uint32_t)i);
        rewind_push(&rb, &b, (uint32_t)i, 0);
    }
    ASSERT(rb.confirmed == REWIND_GATE, "confirmed = 18 after gate flush");

    /* push 5 more (unconfirmed) */
    for (int i = 0; i < 5; i++) {
        DiamondBlock b = make_block(100u + (uint32_t)i);
        rewind_push(&rb, &b, (uint32_t)(i + 0xF00), 0);
    }
    ASSERT(rewind_depth(&rb) == 5, "depth = 5 (unconfirmed)");

    /* try to rewind 100 — should be capped at 5 */
    uint32_t stepped = rewind_back(&rb, 100);
    ASSERT(stepped == 5,           "rewind(100) capped at unconfirmed count (5)");
    ASSERT(rb.confirmed == REWIND_GATE, "confirmed unchanged after rewind");
    ASSERT(rewind_depth(&rb) == 0, "depth = 0 after full rewind of unconfirmed");
}

/* ── T06: nexus checkpoint every 54 writes ───────────────────────── */
static void test_06_nexus_checkpoint(void)
{
    printf("\nT06: nexus checkpoint every 54 writes\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    /* push exactly 54 */
    for (uint32_t i = 0; i < REWIND_NEXUS; i++) {
        DiamondBlock b = make_block((uint32_t)i);
        rewind_push(&rb, &b, (uint32_t)i, 0);
    }

    ASSERT(rb.stats.total_writes == REWIND_NEXUS,
           "54 writes recorded");
    /* checkpoint[0] should be set (crc32 non-zero for non-zero block) */
    ASSERT(rb.checkpoints[0].crc32 != 0,
           "checkpoint[0].crc32 set after 54 writes");
    ASSERT(rb.checkpoints[0].timestamp_ns != 0,
           "checkpoint[0].timestamp_ns set");

    /* push another 54 → checkpoint[1] */
    for (uint32_t i = 0; i < REWIND_NEXUS; i++) {
        DiamondBlock b = make_block((uint32_t)(i + 0x100));
        rewind_push(&rb, &b, (uint32_t)i, 0);
    }
    ASSERT(rb.checkpoints[1].crc32 != 0,
           "checkpoint[1].crc32 set after 108 writes");
}

/* ── T07: rewind_to_checkpoint ───────────────────────────────────── */
static void test_07_rewind_to_ckpt(void)
{
    printf("\nT07: rewind_to_checkpoint\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    /* push 60 (= 54 + 6) — checkpoint[0] at slot 53 */
    for (int i = 0; i < 60; i++) {
        DiamondBlock b = make_block((uint32_t)i + 1); /* non-zero */
        rewind_push(&rb, &b, (uint32_t)i, 0);
    }
    ASSERT(rb.head == 60, "head = 60 after 60 pushes");

    /* rewind_to_checkpoint(53) — should roll back to nexus at slot 53 */
    uint32_t ckpt_slot = rewind_to_checkpoint(&rb, 53);
    ASSERT(ckpt_slot != UINT32_MAX,   "checkpoint found");
    ASSERT(rb.head <= 60,              "head reduced after rewind_to_checkpoint");
}

/* ── T08: ring wrap + epoch ──────────────────────────────────────── */
static void test_08_ring_wrap(void)
{
    printf("\nT08: ring wrap + epoch\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    /* push exactly REWIND_MAX = 972 */
    for (uint32_t i = 0; i < REWIND_MAX; i++) {
        DiamondBlock b = make_block(i + 1);
        rewind_push(&rb, &b, i, 0);
    }
    ASSERT(rb.count == REWIND_MAX, "count = REWIND_MAX after full fill");

    /* push 1 more → ring wraps, epoch increments */
    DiamondBlock extra = make_block(0xFFFF);
    rewind_push(&rb, &extra, 0, 0);
    ASSERT(rb.epoch == 1,                     "epoch = 1 after ring wrap");
    ASSERT(rb.stats.overflow_wraps > 0,       "overflow_wraps > 0");
}

/* ── T09: peek non-destructive ───────────────────────────────────── */
static void test_09_peek(void)
{
    printf("\nT09: peek non-destructive\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    DiamondBlock b0 = make_block(100), b1 = make_block(200), b2 = make_block(300);
    rewind_push(&rb, &b0, 0, 0);
    rewind_push(&rb, &b1, 0, 0);
    rewind_push(&rb, &b2, 0, 0);

    /* peek(0) = last, peek(1) = second, peek(2) = first */
    ASSERT(rewind_peek(&rb, 0)->core.raw == 300, "peek(0) = last (300)");
    ASSERT(rewind_peek(&rb, 1)->core.raw == 200, "peek(1) = second (200)");
    ASSERT(rewind_peek(&rb, 2)->core.raw == 100, "peek(2) = first (100)");
    ASSERT(rewind_peek(&rb, 3) == NULL,           "peek(3) = NULL (out of range)");
    ASSERT(rb.head == 3,  "head unchanged after peeks");
    ASSERT(rb.count == 3, "count unchanged after peeks");
}

/* ── T10: global_id determinism ──────────────────────────────────── */
static void test_10_global_id(void)
{
    printf("\nT10: global_id determinism\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    DiamondBlock b = make_block(42);
    rewind_push(&rb, &b, 0, 0);

    uint64_t id1 = rewind_global_id(&rb, 0);
    uint64_t id2 = rewind_global_id(&rb, 0);
    ASSERT(id1 == id2,       "global_id deterministic (same offset = same id)");
    ASSERT(id1 != UINT64_MAX,"global_id valid (not UINT64_MAX)");
    /* epoch=0, slot=0 → global_id = 0 */
    ASSERT(id1 == 0,         "global_id = epoch×MAX + slot = 0×972 + 0 = 0");
}

/* ── T11: flush_fn called correctly ──────────────────────────────── */
static void test_11_flush_fn(void)
{
    printf("\nT11: flush_fn callback on manual flush\n");

    /* Part A: auto-flush verification (flush_fn set from init) */
    _flush_calls = 0;
    RewindBuffer rb;
    rewind_init(&rb, _flush_stub, NULL, NULL);

    for (uint32_t i = 0; i < REWIND_GATE; i++) {
        DiamondBlock b = make_block((uint32_t)i);
        rewind_push(&rb, &b, i, (uint8_t)(i % 54));
    }
    ASSERT(_flush_calls == REWIND_GATE, "auto-flush fired 18 times at gate_18");
    ASSERT(rb.confirmed == REWIND_GATE, "confirmed = 18 after auto-flush");

    /* Part B: manual flush — accumulate WITHOUT auto-flush (flush_fn=NULL)
     * then set fn and call manually */
    _flush_calls = 0;
    RewindBuffer rb2;
    rewind_init(&rb2, NULL, NULL, NULL);  /* no auto-flush */

    /* push exactly 18 — no auto-flush because flush_fn=NULL */
    for (uint32_t i = 0; i < REWIND_GATE; i++) {
        DiamondBlock b = make_block((uint32_t)(i + 0x100));
        rewind_push(&rb2, &b, i, 0);
    }
    ASSERT(rb2.confirmed == 0,          "confirmed = 0 (no auto-flush, fn=NULL)");
    ASSERT(rb2.stats.total_writes == REWIND_GATE, "18 writes buffered");

    /* now attach flush_fn and call manually */
    rb2.flush_fn  = _flush_stub;
    rb2.flush_ctx = NULL;
    _flush_calls  = 0;

    uint32_t f = rewind_flush_gate(&rb2);
    ASSERT(f == REWIND_GATE,             "manual flush_gate flushes 18 slots");
    ASSERT(_flush_calls == REWIND_GATE,  "flush_fn called 18 times on manual flush");
    ASSERT(rb2.confirmed == REWIND_GATE, "confirmed = 18 after manual flush");
}

/* ── T12: DNA integration ─────────────────────────────────────────── */
static void test_12_dna_integration(void)
{
    printf("\nT12: DNA integration via rewind_push_with_dna\n");
    W3RContext ring; w3r_init(&ring);
    TailsDNAContext dna; tails_dna_init(&dna);
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, &dna);

    ASSERT(rb.dna == &dna, "rb.dna linked to context");

    /* write via w3r + push with dna */
    uint64_t addr = 0x1234;
    W3RWriteResult wr = l38_w3r_write(&ring, addr);
    DiamondBlock b = make_block((uint32_t)addr);
    const uint8_t face[6] = {1,2,3,4,5,6};

    uint32_t idx = rewind_push_with_dna(&rb, &b,
                                         (uint32_t)addr, 3,
                                         &wr, face, 77);

    ASSERT(idx != UINT32_MAX,            "rewind_push_with_dna returns valid idx");
    ASSERT(rb.stats.total_writes == 1,   "total_writes = 1");
    ASSERT(dna.total_records == 1,       "dna.total_records = 1");
    ASSERT(dna.entries[wr.cell.slot].write_tick == 77,
           "dna entry write_tick = 77");
    ASSERT(dna.entries[wr.cell.slot].sig_fast != 0,
           "dna entry sig_fast set");
}

/* ══════════════════════════════════════════════════════════════════════
   MAIN
   ══════════════════════════════════════════════════════════════════════ */
int main(void)
{
    printf("=== RewindBuffer Phase B2 Tests ===\n");
    printf("Port from V4: sacred slots, flush gate, rewind, checkpoint, DNA\n");

    test_01_init();
    test_02_push_single();
    test_03_auto_flush();
    test_04_rewind();
    test_05_rewind_cap();
    test_06_nexus_checkpoint();
    test_07_rewind_to_ckpt();
    test_08_ring_wrap();
    test_09_peek();
    test_10_global_id();
    test_11_flush_fn();
    test_12_dna_integration();

    printf("\n═══════════════════════════════════\n");
    printf("RESULT: %d PASS  /  %d FAIL  /  %d TOTAL\n",
           _pass, _fail, _pass + _fail);
    printf("═══════════════════════════════════\n");
    return _fail > 0 ? 1 : 0;
}
