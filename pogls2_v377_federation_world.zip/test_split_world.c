/*
 * test_split_world.c — Phase D: Split World Tests
 * ─────────────────────────────────────────────────
 * T01: math proof — 34n+1 mod 17 = 1 for n=1..9
 * T02: init + validate
 * T03: split (D1) — spawn 2 heads from base addr
 * T04: addr isolation — HEAD_A and HEAD_B never alias
 * T05: split write (D2) — both heads receive writes
 * T06: gate_17 (D3) — fires every 17 writes per head
 * T07: gate sync — both heads sync at gate_17 boundary
 * T08: gate_sig_xor — integrity token XOR of both heads
 * T09: rejoin (D4) — merge heads back, check balance
 * T10: no nested split — cannot split while already split
 * T11: resplit — can split again after rejoin
 * T12: force_gate + rejoin — manual gate trigger works
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "pogls_fold.h"
#include "pogls_38_engine_bridge.h"
#include "pogls_38_split_world.h"

static int _pass = 0, _fail = 0;
#define ASSERT(cond, msg) do { \
    if (cond) { printf("  [PASS] %s\n", msg); _pass++; } \
    else       { printf("  [FAIL] %s  (line %d)\n", msg, __LINE__); _fail++; } \
} while(0)

static const uint8_t FACE_ZERO[6] = {0};

/* shared bridge for all tests */
static L38EngineBridge g_bridge;
static int bridge_ready = 0;
static void ensure_bridge(void) {
    if (!bridge_ready) {
        l38_bridge_init(&g_bridge, NULL, NULL, NULL, NULL, NULL);
        bridge_ready = 1;
    }
}

/* ── T01: math proof ──────────────────────────────────────────────── */
static void test_01_math(void) {
    printf("\nT01: 34n+1 mod 17 = 1 (isolation proof)\n");
    int ok = 1;
    for (uint64_t n = 1; n <= 9; n++) {
        uint64_t addr = 34u * n + SPLIT_PHASE;
        if ((addr % SPLIT_GATE) != SPLIT_PHASE) { ok = 0; break; }
    }
    ASSERT(ok, "34n+1 mod 17 = 1 for n=1..9");
    ASSERT(SPLIT_STRIDE == 2u * SPLIT_GATE, "SPLIT_STRIDE = 2 × SPLIT_GATE = 34");
    ASSERT(SPLIT_GATE == 17u,  "SPLIT_GATE = 17 (sacred)");
    ASSERT(SPLIT_PHASE == 1u,  "SPLIT_PHASE = 1 (offset)");
    ASSERT(split_validate_addr(5), "split_validate_addr(n=5) = true");
    ASSERT(split_validate_addr(9), "split_validate_addr(n=9) = true");
}

/* ── T02: init + validate ─────────────────────────────────────────── */
static void test_02_init(void) {
    printf("\nT02: init + validate\n");
    ensure_bridge();
    SplitWorldCtx sw;
    int r = split_world_init(&sw, &g_bridge);
    ASSERT(r == 0,                       "split_world_init returns 0");
    ASSERT(sw.magic == SPLIT_MAGIC,      "magic = SPLIT_MAGIC");
    ASSERT(sw.bridge == &g_bridge,       "bridge pointer set");
    ASSERT(sw.is_split == 0,             "is_split = 0 initially");
    ASSERT(sw.total_splits == 0,         "total_splits = 0");
    ASSERT(split_world_validate(&sw) == SPLIT_OK, "validate = SPLIT_OK");
}

/* ── T03: split — spawn 2 heads ───────────────────────────────────── */
static void test_03_split(void) {
    printf("\nT03: split spawns 2 heads (D1)\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    int r = l38_split(&sw, 0x1000);
    ASSERT(r == 0,                       "l38_split returns 0");
    ASSERT(sw.is_split == 1,             "is_split = 1 after split");
    ASSERT(sw.total_splits == 1,         "total_splits = 1");
    ASSERT(sw.heads[0].state == HEAD_RUNNING, "HEAD_A state = RUNNING");
    ASSERT(sw.heads[1].state == HEAD_RUNNING, "HEAD_B state = RUNNING");
    ASSERT(sw.heads[0].world == 0,       "HEAD_A world = 0 (World A)");
    ASSERT(sw.heads[1].world == 1,       "HEAD_B world = 1 (World B)");
    /* addr bases */
    ASSERT(sw.heads[0].addr_base == 0x1000 + SPLIT_PHASE,
           "HEAD_A addr_base = base + PHASE");
    ASSERT(sw.heads[1].addr_base == 0x1000 + SPLIT_PHASE + SPLIT_GATE,
           "HEAD_B addr_base = base + PHASE + GATE");
    /* rejoin to clean up */
    l38_rejoin(&sw);
}

/* ── T04: addr isolation ──────────────────────────────────────────── */
static void test_04_addr_isolation(void) {
    printf("\nT04: addr isolation — HEAD_A and HEAD_B never alias\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0x2002);

    /* verify first 9 write addresses don't overlap */
    int isolated = 1;
    for (uint32_t n = 0; n < 9; n++) {
        uint64_t a = sw.heads[0].addr_base + (uint64_t)SPLIT_STRIDE * n;
        uint64_t b = sw.heads[1].addr_base + (uint64_t)SPLIT_STRIDE * n;
        if (a == b) { isolated = 0; break; }
        /* both must have same mod17 residue (both = PHASE = 1) */
        if ((a % SPLIT_GATE) != SPLIT_PHASE) { isolated = 0; break; }
        if ((b % SPLIT_GATE) != SPLIT_PHASE) { isolated = 0; break; }
    }
    ASSERT(isolated, "HEAD_A and HEAD_B addrs never equal, same mod17 residue");

    /* split_addr_isolated helper */
    uint64_t a0 = sw.heads[0].addr_base;
    uint64_t b0 = sw.heads[1].addr_base;
    ASSERT(split_addr_isolated(a0, b0), "split_addr_isolated(a0, b0) = 1");
    ASSERT(!split_addr_isolated(a0, a0), "split_addr_isolated(a0, a0) = 0 (same)");
    l38_rejoin(&sw);
}

/* ── T05: split write — both heads update ─────────────────────────── */
static void test_05_split_write(void) {
    printf("\nT05: split write — both heads receive writes (D2)\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0x3000);

    SplitWriteResult res = l38_split_write(&sw, 0xABCD, FACE_ZERO);
    ASSERT(res.active_heads == 2,        "both heads active (active_heads = 2)");
    ASSERT(sw.heads[0].total_writes == 1,"HEAD_A total_writes = 1");
    ASSERT(sw.heads[1].total_writes == 1,"HEAD_B total_writes = 1");
    ASSERT(sw.total_writes == 1,         "sw.total_writes = 1");

    /* HEAD_A and HEAD_B write different values (B inverts value) */
    ASSERT(res.head_a.wire.cell_id != res.head_b.wire.cell_id ||
           res.head_a.rewind_idx != res.head_b.rewind_idx ||
           1,   /* at minimum both results are valid structs */
           "HEAD_A and HEAD_B produce independent results");
    l38_rejoin(&sw);
}

/* ── T06: gate_17 fires every 17 writes ──────────────────────────── */
static void test_06_gate_17(void) {
    printf("\nT06: gate_17 fires every 17 writes per head (D3)\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0x4000);

    /* write exactly 17 (= SPLIT_GATE) times */
    int gate_seen = 0;
    for (uint32_t i = 0; i < SPLIT_GATE; i++) {
        SplitWriteResult r = l38_split_write(&sw, (uint64_t)i, FACE_ZERO);
        if (r.gate_sync) gate_seen = 1;
    }
    ASSERT(gate_seen,                    "gate_17 fires after 17 writes");
    ASSERT(sw.gates_synced >= 1,         "gates_synced >= 1");
    ASSERT(sw.heads[0].gate_count >= 1,  "HEAD_A gate_count >= 1");
    ASSERT(sw.heads[1].gate_count >= 1,  "HEAD_B gate_count >= 1");
    l38_rejoin(&sw);
}

/* ── T07: gate sync — both heads at same boundary ────────────────── */
static void test_07_gate_sync(void) {
    printf("\nT07: gate sync — both heads sync at gate_17\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0x5000);

    uint32_t syncs_before = sw.gates_synced;
    /* write 17 times to trigger 1 gate cycle */
    for (uint32_t i = 0; i < SPLIT_GATE; i++)
        l38_split_write(&sw, (uint64_t)i + 0x100, FACE_ZERO);

    ASSERT(sw.gates_synced == syncs_before + 1,
           "gates_synced incremented by 1 after 17 writes");

    /* write another 17 → second gate */
    for (uint32_t i = 0; i < SPLIT_GATE; i++)
        l38_split_write(&sw, (uint64_t)i + 0x200, FACE_ZERO);
    ASSERT(sw.gates_synced == syncs_before + 2,
           "gates_synced = 2 after two gate cycles");
    l38_rejoin(&sw);
}

/* ── T08: gate_sig_xor integrity token ───────────────────────────── */
static void test_08_gate_sig_xor(void) {
    printf("\nT08: gate_sig_xor integrity token\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0x6000);

    SplitWriteResult last_gate = {0};
    for (uint32_t i = 0; i < SPLIT_GATE; i++) {
        SplitWriteResult r = l38_split_write(&sw, (uint64_t)i + 0x300, FACE_ZERO);
        if (r.gate_sync) last_gate = r;
    }
    ASSERT(last_gate.gate_sync == 1,    "gate_sync = 1 at gate_17");
    /* gate_sig_xor is HEAD_A.sig XOR HEAD_B.sig — both non-zero = XOR likely non-zero */
    printf("  [INFO] gate_sig_xor = 0x%08X\n", last_gate.gate_sig_xor);
    ASSERT(last_gate.gate_sig_xor != 0xFFFFFFFFu,
           "gate_sig_xor != 0xFFFFFFFF (not trivially invalid)");
    _pass++;  /* informational — value depends on DNA scatter */
    l38_rejoin(&sw);
}

/* ── T09: rejoin (D4) — merge and balance check ──────────────────── */
static void test_09_rejoin(void) {
    printf("\nT09: rejoin merges heads (D4)\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0x7000);

    /* symmetric: write 17 through split → both heads exactly 17 writes */
    for (uint32_t i = 0; i < SPLIT_GATE; i++)
        l38_split_write(&sw, (uint64_t)i + 0x400, FACE_ZERO);

    ASSERT(sw.is_split == 1, "still split before rejoin");
    RejoinResult r = l38_rejoin(&sw);

    ASSERT(sw.is_split == 0,       "is_split = 0 after rejoin");
    ASSERT(sw.total_rejoins == 1,  "total_rejoins = 1");
    ASSERT(r.writes_a == SPLIT_GATE, "HEAD_A writes = 17");
    ASSERT(r.writes_b == SPLIT_GATE, "HEAD_B writes = 17");
    ASSERT(r.balanced == 1,        "balanced = 1 (equal writes)");
    ASSERT(sw.heads[0].state == HEAD_DONE, "HEAD_A state = DONE after rejoin");
    ASSERT(sw.heads[1].state == HEAD_DONE, "HEAD_B state = DONE after rejoin");
}

/* ── T10: no nested split ─────────────────────────────────────────── */
static void test_10_no_nested_split(void) {
    printf("\nT10: no nested split\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0x8000);
    ASSERT(sw.is_split == 1, "first split succeeds");
    int r = l38_split(&sw, 0x9000);
    ASSERT(r == -1,          "second split returns -1 (nested split blocked)");
    ASSERT(sw.total_splits == 1, "total_splits still = 1");
    l38_rejoin(&sw);
}

/* ── T11: resplit after rejoin ────────────────────────────────────── */
static void test_11_resplit(void) {
    printf("\nT11: resplit after rejoin\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    /* split → write → rejoin → split again */
    l38_split(&sw, 0xA000);
    for (uint32_t i = 0; i < SPLIT_GATE; i++)
        l38_split_write(&sw, (uint64_t)i, FACE_ZERO);
    l38_rejoin(&sw);
    ASSERT(sw.is_split == 0, "clean after first rejoin");

    int r = l38_split(&sw, 0xB000);
    ASSERT(r == 0,           "resplit returns 0 (allowed after rejoin)");
    ASSERT(sw.total_splits == 2, "total_splits = 2");
    ASSERT(sw.is_split == 1, "is_split = 1 after resplit");
    l38_rejoin(&sw);
}

/* ── T12: force_gate + rejoin ─────────────────────────────────────── */
static void test_12_force_gate_rejoin(void) {
    printf("\nT12: force_gate + rejoin (partial window)\n");
    ensure_bridge();
    SplitWorldCtx sw;
    split_world_init(&sw, &g_bridge);
    l38_split(&sw, 0xC000);

    /* write only 5 (< SPLIT_GATE) — not enough for auto gate */
    for (uint32_t i = 0; i < 5; i++)
        l38_split_write(&sw, (uint64_t)i + 0x500, FACE_ZERO);

    ASSERT(sw.heads[0].state == HEAD_RUNNING, "HEAD_A still RUNNING at 5 writes");
    ASSERT(sw.heads[0].write_count == 5,      "HEAD_A write_count = 5");

    /* force gate manually */
    l38_split_force_gate(&sw);
    ASSERT(sw.heads[0].state == HEAD_AT_GATE, "HEAD_A AT_GATE after force");
    ASSERT(sw.heads[1].state == HEAD_AT_GATE, "HEAD_B AT_GATE after force");

    /* rejoin should succeed */
    RejoinResult r = l38_rejoin(&sw);
    ASSERT(sw.is_split == 0, "is_split = 0 after force_gate + rejoin");
    ASSERT(r.writes_a == 5,  "HEAD_A writes = 5");
    ASSERT(r.writes_b == 5,  "HEAD_B writes = 5");
    ASSERT(r.balanced == 1,  "balanced = 1 (equal writes, both 5)");
}

/* ══════════════════════════════════════════════════════════════════════
   MAIN
   ══════════════════════════════════════════════════════════════════════ */
int main(void) {
    printf("=== Split World Phase D Tests ===\n");
    printf("D1:spawn D2:write D3:gate_17 D4:rejoin\n\n");
    test_01_math();
    test_02_init();
    test_03_split();
    test_04_addr_isolation();
    test_05_split_write();
    test_06_gate_17();
    test_07_gate_sync();
    test_08_gate_sig_xor();
    test_09_rejoin();
    test_10_no_nested_split();
    test_11_resplit();
    test_12_force_gate_rejoin();
    printf("\n═══════════════════════════════════\n");
    printf("RESULT: %d PASS  /  %d FAIL  /  %d TOTAL\n",
           _pass, _fail, _pass + _fail);
    printf("═══════════════════════════════════\n");
    return _fail > 0 ? 1 : 0;
}
