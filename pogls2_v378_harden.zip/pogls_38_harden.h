/*
 * pogls_38_harden.h — POGLS38 Harden Layer (pre-Phase E)
 * ══════════════════════════════════════════════════════════════════════
 *
 * 4 hardening patches ก่อน Phase E (GPU Full Path)
 * ทุกอย่าง additive — ไม่แตะ logic เดิม
 *
 * H1: Rewind head binding
 *     rewind_slot.head_id → rewind_head(rb, head_id, n)
 *     แยก timeline per head → ไม่มี cross-corruption เมื่อ split
 *
 * H2: Atomic write group (begin/commit/abort)
 *     ห่อ bridge write ทั้งก้อน — กัน partial state 100%
 *     abort → rewind ทุก step กลับจนถึง tx start
 *
 * H3: GPU adaptive throttle
 *     แทน fixed gate_18: fill > 70% → gpu_rate *= 0.5
 *     dynamic → รับ burst จริงได้ ไม่ล้น rewind buffer
 *
 * H4: Snapshot version tag (fine-grain snap_id)
 *     fed_epoch = coarse (per commit)
 *     snap_id   = fine (per write batch = 32 writes)
 *     → rollback/replay ระดับ batch ทำได้
 *
 * เปรียบเทียบ:
 *   ก่อน harden = เครื่องบินเร็วมากแต่ไม่มี black box
 *   หลัง harden = เครื่องบินเร็วมาก + black box + ระบบดับเพลิง + GPS
 *
 * ══════════════════════════════════════════════════════════════════════
 */

#ifndef POGLS_38_HARDEN_H
#define POGLS_38_HARDEN_H

#include <stdint.h>
#include <string.h>
#include "pogls_38_rewind.h"
#include "pogls_38_engine_bridge.h"
#include "pogls_38_split_world.h"

/* ══════════════════════════════════════════════════════════════════════
 * H1 — REWIND HEAD BINDING
 *
 * ปัญหา: RewindBuffer เป็น global buffer
 *   Split → HEAD_A write slot 5, HEAD_B write slot 6
 *   rewind(3) → ย้อนทั้งสองหมด (state mismatch)
 *
 * แก้: เพิ่ม head_id ใน RewindSlot._pad (ไม่เปลี่ยน size)
 *   rewind_head(rb, head_id, n) → ย้อนเฉพาะ slots ของ head นั้น
 *
 * เปรียบเทียบ:
 *   ก่อน = เทปบันทึกเดียว ทุกคนอัดเข้ามา
 *   หลัง = เทปแยกต่อคน ย้อนได้เป็นคนๆ ไป
 * ══════════════════════════════════════════════════════════════════════ */

#define RWSLOT_HEAD_NONE  0xFFu   /* no head assigned (single-stream mode) */
#define RWSLOT_HEAD_A     0x00u
#define RWSLOT_HEAD_B     0x01u

/* Write to RewindBuffer with head_id tag.
 * head_id stored in _pad[0] of RewindSlot (doesn't change size). */
static inline uint32_t rewind_push_head(RewindBuffer       *rb,
                                         const DiamondBlock *block,
                                         uint32_t            addr,
                                         uint8_t             lane_id,
                                         uint8_t             head_id)
{
    uint32_t idx = rewind_push(rb, block, addr, lane_id);
    if (idx != UINT32_MAX)
        rb->slots[idx]._pad[0] = head_id;   /* tag slot with head */
    return idx;
}

/* Rewind only slots belonging to head_id.
 * Scans backwards from head, skips slots of other heads.
 * Returns: slots actually rewound for this head. */
static inline uint32_t rewind_head(RewindBuffer *rb,
                                    uint8_t       head_id,
                                    uint32_t      n)
{
    if (!rb || n == 0) return 0;

    uint32_t unconfirmed = (rb->head > rb->confirmed)
                         ? rb->head - rb->confirmed : 0;
    uint32_t rewound = 0;

    /* scan backwards from head, mark matching slots */
    for (uint32_t i = 0; i < unconfirmed && rewound < n; i++) {
        uint32_t si = (rb->head - 1 - i) % REWIND_MAX;
        if (rb->slots[si]._pad[0] == head_id) {
            rb->slots[si].flags |= RWSLOT_FLAG_REWOUND;
            rewound++;
        }
    }

    /* compact: remove rewound slots by moving head back past them */
    /* simple impl: count trailing rewound slots and pop */
    while (rb->head > rb->confirmed) {
        uint32_t si = (rb->head - 1) % REWIND_MAX;
        if (!(rb->slots[si].flags & RWSLOT_FLAG_REWOUND)) break;
        rb->head--;
        rb->count = rb->count > 0 ? rb->count - 1 : 0;
    }

    rb->stats.total_rewinds++;
    rb->stats.steps_rewound += rewound;
    return rewound;
}

/* ══════════════════════════════════════════════════════════════════════
 * H2 — ATOMIC WRITE GROUP (begin / commit / abort)
 *
 * ปัญหา: write → W3R → DNA → rewind → flush
 *   ถ้าพังกลางทาง = partial state (W3R อัปเดตแล้ว, DNA ไม่อัปเดต)
 *
 * แก้: ห่อทั้งก้อนด้วย tx
 *   begin_tx  → snapshot head position
 *   commit_tx → advance confirmed
 *   abort_tx  → rewind ทุกอย่างกลับถึง snapshot
 *
 * เปรียบเทียบ:
 *   begin  = กดปุ่ม "undo checkpoint"
 *   commit = ยืนยัน "save ถาวร"
 *   abort  = กด undo กลับหา checkpoint
 * ══════════════════════════════════════════════════════════════════════ */

#define TX_MAGIC  0x54584752u   /* "TXGR" */
#define TX_MAX_OPS 64u          /* max ops per tx group */

typedef enum {
    TX_IDLE    = 0,
    TX_ACTIVE  = 1,
    TX_ABORTED = 2,
} tx_state_t;

typedef struct {
    uint32_t  magic;
    uint8_t   state;          /* tx_state_t */
    uint8_t   head_id;        /* which split head (RWSLOT_HEAD_NONE = single) */
    uint8_t   _pad[2];
    uint32_t  snapshot_head;  /* rb->head at begin_tx */
    uint32_t  snapshot_dna;   /* dna->total_records at begin_tx */
    uint32_t  op_count;       /* writes inside this tx */
    uint32_t  rewind_slots;   /* slots pushed to rewind in this tx */
} WriteTx;                    /* 28B */

static inline void tx_init(WriteTx *tx)
{
    if (!tx) return;
    memset(tx, 0, sizeof(*tx));
    tx->magic   = TX_MAGIC;
    tx->head_id = RWSLOT_HEAD_NONE;
}

static inline int tx_begin(WriteTx *tx, const RewindBuffer *rb,
                             const TailsDNAContext *dna, uint8_t head_id)
{
    if (!tx || !rb || tx->state == TX_ACTIVE) return -1;
    tx->magic          = TX_MAGIC;
    tx->state          = TX_ACTIVE;
    tx->head_id        = head_id;
    tx->snapshot_head  = rb->head;
    tx->snapshot_dna   = dna ? dna->total_records : 0;
    tx->op_count       = 0;
    tx->rewind_slots   = 0;
    return 0;
}

static inline int tx_commit(WriteTx *tx)
{
    if (!tx || tx->state != TX_ACTIVE) return -1;
    tx->state = TX_IDLE;
    return 0;
}

/* abort: rewind all slots written in this tx */
static inline int tx_abort(WriteTx *tx, RewindBuffer *rb)
{
    if (!tx || !rb || tx->state != TX_ACTIVE) return -1;

    /* rewind slots pushed since begin_tx */
    uint32_t overshoot = rb->head > tx->snapshot_head
                       ? rb->head - tx->snapshot_head : 0;
    if (overshoot > 0) {
        /* force head back to snapshot — all unconfirmed slots discarded */
        uint32_t confirmed_floor = rb->confirmed;
        if (tx->snapshot_head >= confirmed_floor) {
            rb->head  = tx->snapshot_head;
            rb->count = rb->head > rb->confirmed
                      ? rb->head - rb->confirmed : 0;
            rb->stats.total_rewinds++;
            rb->stats.steps_rewound += overshoot;
        }
    }

    tx->state = TX_ABORTED;
    return 0;
}

/* ── Atomic bridge write (H2 + H1 combined) ─────────────────────────
 * Wraps l38_bridge_write() with tx semantics.
 * On any failure (future extension point): caller calls tx_abort().
 */
static inline L38BridgeResult l38_bridge_write_tx(L38EngineBridge *b,
                                                    uint64_t          addr,
                                                    uint64_t          value,
                                                    const uint8_t     rubik[6],
                                                    uint8_t           lane_id,
                                                    WriteTx          *tx)
{
    L38BridgeResult res = l38_bridge_write(b, addr, value, rubik, lane_id);
    if (tx && tx->state == TX_ACTIVE) {
        tx->op_count++;
        /* tag the slot just pushed with head_id */
        if (res.rewind_idx != UINT32_MAX)
            b->rewind.slots[res.rewind_idx % REWIND_MAX]._pad[0] = tx->head_id;
        tx->rewind_slots++;
    }
    return res;
}

/* ══════════════════════════════════════════════════════════════════════
 * H3 — GPU ADAPTIVE THROTTLE
 *
 * ปัญหา: GPU burst สามารถ overflow rewind buffer
 *   gate_18 fixed → ไม่รู้ fill level จริง
 *
 * แก้: dynamic rate โดย monitor rewind fill %
 *   fill < 50%  → rate = 1.0   (full speed)
 *   fill 50-70% → rate = 0.75  (slow down)
 *   fill > 70%  → rate = 0.5   (half speed)
 *   fill > 90%  → rate = 0.25  (emergency brake)
 *
 * เปรียบเทียบ:
 *   ก่อน = ก๊อกน้ำเปิดเต็ม ไม่รู้ว่าอ่างจะล้น
 *   หลัง = ระบบ float valve — ระดับน้ำสูง ก๊อกหรี่เอง
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    float    rate;             /* current rate multiplier (0.25 - 1.0)    */
    uint32_t fill_pct;         /* last measured fill % (0-100)            */
    uint32_t throttle_events;  /* times rate was reduced                  */
    uint32_t resume_events;    /* times rate recovered to 1.0             */
} GPUThrottle;

static inline void gpu_throttle_init(GPUThrottle *t)
{
    if (!t) return;
    t->rate            = 1.0f;
    t->fill_pct        = 0;
    t->throttle_events = 0;
    t->resume_events   = 0;
}

/* Update throttle based on rewind fill level.
 * Call before every GPU batch submission.
 * Returns: rate multiplier (caller scales batch size by this). */
static inline float gpu_throttle_update(GPUThrottle *t, const RewindBuffer *rb)
{
    if (!t || !rb) return 1.0f;

    /* fill % = count / MAX * 100 */
    uint32_t fill = (rb->count * 100u) / REWIND_MAX;
    t->fill_pct   = fill;

    float new_rate;
    if (fill < 50u)      new_rate = 1.00f;
    else if (fill < 70u) new_rate = 0.75f;
    else if (fill < 90u) new_rate = 0.50f;
    else                 new_rate = 0.25f;

    if (new_rate < t->rate) t->throttle_events++;
    if (new_rate > t->rate && t->rate < 1.0f) t->resume_events++;

    t->rate = new_rate;
    return new_rate;
}

/* Scale a batch size by throttle rate.
 * batch_max = maximum GPU batch capacity.
 * Returns: actual batch size to submit this cycle. */
static inline uint32_t gpu_throttle_batch(const GPUThrottle *t, uint32_t batch_max)
{
    if (!t || batch_max == 0) return 0;
    uint32_t scaled = (uint32_t)((float)batch_max * t->rate);
    return scaled > 0 ? scaled : 1u;  /* always allow at least 1 */
}

/* ══════════════════════════════════════════════════════════════════════
 * H4 — SNAPSHOT VERSION TAG (fine-grain snap_id)
 *
 * ปัญหา: fed_epoch เป็น coarse (per commit) เท่านั้น
 *   debug/rollback/replay ต้องการ fine-grain level
 *
 * แก้: snap_id = fine-grain per write batch
 *   fed_epoch = coarse  (increments per 12-step commit)
 *   snap_id   = fine    (increments per SNAP_BATCH_SIZE writes)
 *   global_id = epoch × 2²⁰ + snap_id   (unique, monotonic)
 *
 * เปรียบเทียบ:
 *   fed_epoch  = หน้าหนังสือ (coarse — ทุก 1,000 คำ)
 *   snap_id    = บรรทัด (fine — ทุก 32 คำ)
 *   global_id  = (หน้า, บรรทัด) = หาตำแหน่งได้ทันที
 * ══════════════════════════════════════════════════════════════════════ */

#define SNAP_BATCH_SIZE  32u          /* writes per snap_id increment       */
#define SNAP_ID_MAX      (1u << 20)   /* snap_id wraps at 2²⁰ = 1,048,576  */
#define SNAP_MAGIC       0x534E4150u  /* "SNAP"                             */

typedef struct {
    uint32_t  magic;
    uint32_t  snap_id;         /* fine-grain: increments per SNAP_BATCH_SIZE */
    uint32_t  fed_epoch;       /* coarse: mirrors fed_epoch from bridge      */
    uint32_t  batch_writes;    /* writes in current batch (0..31)           */
    uint64_t  global_id;       /* epoch × 2²⁰ + snap_id (unique, monotonic) */
    uint64_t  total_writes;    /* total writes through this versioner        */
} SnapVersioner;               /* 36B */

static inline void snap_init(SnapVersioner *sv)
{
    if (!sv) return;
    memset(sv, 0, sizeof(*sv));
    sv->magic = SNAP_MAGIC;
}

/* Call after every write.
 * Returns global_id for this write (unique across all epochs). */
static inline uint64_t snap_record(SnapVersioner *sv, uint32_t fed_epoch)
{
    if (!sv) return UINT64_MAX;

    sv->fed_epoch = fed_epoch;
    sv->batch_writes++;
    sv->total_writes++;

    /* advance snap_id every SNAP_BATCH_SIZE writes */
    if (sv->batch_writes >= SNAP_BATCH_SIZE) {
        sv->batch_writes = 0;
        sv->snap_id = (sv->snap_id + 1) % SNAP_ID_MAX;
    }

    /* global_id: epoch in high bits, snap_id in low 20 bits */
    sv->global_id = ((uint64_t)sv->fed_epoch << 20) | sv->snap_id;
    return sv->global_id;
}

/* Rollback target: find global_id for (epoch, snap_id) */
static inline uint64_t snap_target(uint32_t epoch, uint32_t snap_id)
{
    return ((uint64_t)epoch << 20) | (snap_id & (SNAP_ID_MAX - 1));
}

/* Compare: is global_id A before B? */
static inline int snap_before(uint64_t a, uint64_t b) { return a < b; }

/* ══════════════════════════════════════════════════════════════════════
 * COMBINED HARDEN CONTEXT
 *
 * ห่อ H1-H4 ทั้งหมดเข้าด้วยกัน — ใช้คู่กับ SplitWorldCtx
 * ══════════════════════════════════════════════════════════════════════ */

#define HARDEN_MAGIC  0x48524454u   /* "HRDT" */

typedef struct {
    uint32_t      magic;
    WriteTx       tx;           /* H2: active transaction group            */
    GPUThrottle   throttle;     /* H3: adaptive GPU rate                   */
    SnapVersioner versioner;    /* H4: fine-grain snap_id                  */
    /* H1 is inline (rewind_push_head + rewind_head functions above) */
    uint32_t      abort_count;  /* times tx_abort() called                 */
    uint32_t      _pad;
} HardenCtx;

static inline int harden_init(HardenCtx *h)
{
    if (!h) return -1;
    memset(h, 0, sizeof(*h));
    h->magic = HARDEN_MAGIC;
    tx_init(&h->tx);
    gpu_throttle_init(&h->throttle);
    snap_init(&h->versioner);
    return 0;
}

/* ── Hardened split write ────────────────────────────────────────────
 * Combines H1+H2+H3+H4 into a single call:
 *   1. throttle check (H3)
 *   2. begin tx if not active (H2)
 *   3. split_write with head-tagged rewind (H1)
 *   4. snap_record (H4)
 *   5. tx auto-commit per SNAP_BATCH_SIZE writes
 * Returns SplitWriteResult.
 */
static inline SplitWriteResult harden_split_write(HardenCtx      *h,
                                                    SplitWorldCtx  *sw,
                                                    uint64_t        value,
                                                    const uint8_t   rubik[6])
{
    SplitWriteResult res = {0};
    if (!h || !sw || h->magic != HARDEN_MAGIC) return res;

    /* H3: check throttle — caller should scale GPU batch before calling,
     * but we update throttle state here for the bridge's rewind */
    L38EngineBridge *b = sw->bridge;
    if (b) gpu_throttle_update(&h->throttle, &b->rewind);

    /* H2: auto begin tx if idle */
    if (h->tx.state != TX_ACTIVE) {
        uint8_t hid = sw->is_split
                    ? (sw->heads[0].state == HEAD_RUNNING
                       ? RWSLOT_HEAD_A : RWSLOT_HEAD_B)
                    : RWSLOT_HEAD_NONE;
        TailsDNAContext *dna = b ? &b->dna : NULL;
        RewindBuffer    *rb  = b ? &b->rewind : NULL;
        if (rb) tx_begin(&h->tx, rb, dna, hid);
    }

    /* H1: split write (heads tag their own rewind slots internally) */
    res = l38_split_write(sw, value, rubik);

    /* H4: snap record */
    uint32_t epoch = b ? (uint32_t)(b->total_writes / SNAP_BATCH_SIZE) : 0;
    snap_record(&h->versioner, epoch);

    /* H2: auto commit every SNAP_BATCH_SIZE ops */
    if (h->tx.op_count >= SNAP_BATCH_SIZE)
        tx_commit(&h->tx);

    return res;
}

/* Emergency abort: rollback current tx */
static inline int harden_abort(HardenCtx *h, L38EngineBridge *b)
{
    if (!h || !b) return -1;
    int r = tx_abort(&h->tx, &b->rewind);
    if (r == 0) h->abort_count++;
    return r;
}

/* ══════════════════════════════════════════════════════════════════════
 * VALIDATE
 * ══════════════════════════════════════════════════════════════════════ */

#define HARDEN_OK           0
#define HARDEN_ERR_NULL    -1
#define HARDEN_ERR_MAGIC   -2

static inline int harden_validate(const HardenCtx *h)
{
    if (!h)                       return HARDEN_ERR_NULL;
    if (h->magic != HARDEN_MAGIC) return HARDEN_ERR_MAGIC;
    return HARDEN_OK;
}

/* ══════════════════════════════════════════════════════════════════════
 * STATS PRINT
 * ══════════════════════════════════════════════════════════════════════ */

#include <stdio.h>

static inline void harden_stats_print(const HardenCtx *h)
{
    if (!h) return;
    printf("\n╔══════════════════════════════════════════╗\n");
    printf("║  Harden Layer Stats                      ║\n");
    printf("╠══════════════════════════════════════════╣\n");
    printf("║ H1 Rewind head tagging: enabled          ║\n");
    printf("║ H2 TX state:      %s                  ║\n",
           h->tx.state == TX_ACTIVE ? "ACTIVE " :
           h->tx.state == TX_IDLE   ? "IDLE   " : "ABORTED");
    printf("║    Aborts:        %10u               ║\n", h->abort_count);
    printf("║ H3 Throttle rate: %10.2f               ║\n", h->throttle.rate);
    printf("║    Fill %%:        %10u               ║\n", h->throttle.fill_pct);
    printf("║    Throttle events:%9u               ║\n", h->throttle.throttle_events);
    printf("║ H4 snap_id:       %10u               ║\n", h->versioner.snap_id);
    printf("║    global_id:     %10llu              ║\n",
           (unsigned long long)h->versioner.global_id);
    printf("║    total_writes:  %10llu              ║\n",
           (unsigned long long)h->versioner.total_writes);
    printf("╚══════════════════════════════════════════╝\n\n");
}

#endif /* POGLS_38_HARDEN_H */
