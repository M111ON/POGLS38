/*
 * test_harden.c — Harden Layer Tests (H1-H4)
 *
 * H1: Rewind head binding — rewind_head(rb, HEAD_A, n) != rewind_head(HEAD_B)
 * H2: Atomic tx group — begin/commit/abort round-trip
 * H3: GPU adaptive throttle — rate drops at fill > 50/70/90%
 * H4: Snapshot versioner — snap_id advances every 32 writes, global_id unique
 * H5: HardenCtx combined — harden_split_write() integrates H1-H4
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <limits.h>
#include "pogls_fold.h"
#include "pogls_38_harden.h"

static int _pass = 0, _fail = 0;
#define ASSERT(cond, msg) do { \
    if (cond) { printf("  [PASS] %s\n", msg); _pass++; } \
    else       { printf("  [FAIL] %s  (line %d)\n", msg, __LINE__); _fail++; } \
} while(0)

static L38EngineBridge g_bridge;
static SplitWorldCtx   g_sw;
static int g_ready = 0;
static void ensure_ctx(void) {
    if (!g_ready) {
        l38_bridge_init(&g_bridge, NULL, NULL, NULL, NULL, NULL);
        split_world_init(&g_sw, &g_bridge);
        g_ready = 1;
    }
}

static DiamondBlock make_block(uint64_t v) {
    DiamondBlock b; memset(&b,0,sizeof(b));
    b.core.raw = v; b.invert = ~v;
    return b;
}

/* ── H1: Rewind head binding ──────────────────────────────────────── */
static void test_h1_head_binding(void) {
    printf("\nH1: Rewind head binding\n");
    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);

    DiamondBlock b = make_block(0xAAAA);

    /* Push 3 slots HEAD_A, 3 slots HEAD_B, interleaved */
    rewind_push_head(&rb, &b, 0x100, 0, RWSLOT_HEAD_A);
    rewind_push_head(&rb, &b, 0x200, 1, RWSLOT_HEAD_B);
    rewind_push_head(&rb, &b, 0x300, 0, RWSLOT_HEAD_A);
    rewind_push_head(&rb, &b, 0x400, 1, RWSLOT_HEAD_B);
    rewind_push_head(&rb, &b, 0x500, 0, RWSLOT_HEAD_A);
    rewind_push_head(&rb, &b, 0x600, 1, RWSLOT_HEAD_B);

    ASSERT(rb.head == 6, "6 slots pushed");

    /* verify head tags */
    ASSERT(rb.slots[0]._pad[0] == RWSLOT_HEAD_A, "slot[0] = HEAD_A");
    ASSERT(rb.slots[1]._pad[0] == RWSLOT_HEAD_B, "slot[1] = HEAD_B");
    ASSERT(rb.slots[2]._pad[0] == RWSLOT_HEAD_A, "slot[2] = HEAD_A");
    ASSERT(rb.slots[3]._pad[0] == RWSLOT_HEAD_B, "slot[3] = HEAD_B");

    /* rewind_head HEAD_A only — should rewind 2 (slots 4 and 2 from top)
     * Note: head_binding rewinds from top, picks HEAD_A slots */
    uint32_t stepped = rewind_head(&rb, RWSLOT_HEAD_A, 2);
    ASSERT(stepped == 2, "rewind_head(HEAD_A, 2) = 2");
    ASSERT(rb.head <= 6, "head reduced after head rewind");

    /* HEAD_B slots should survive — check last B slot still accessible */
    int b_slot_found = 0;
    for (uint32_t i = 0; i < rb.head; i++)
        if (rb.slots[i]._pad[0] == RWSLOT_HEAD_B) b_slot_found = 1;
    ASSERT(b_slot_found, "HEAD_B slots survive HEAD_A rewind");
}

/* ── H2: Atomic tx group ──────────────────────────────────────────── */
static void test_h2_atomic_tx(void) {
    printf("\nH2: Atomic write group\n");
    ensure_ctx();

    WriteTx tx;
    tx_init(&tx);
    ASSERT(tx.state == TX_IDLE, "tx starts IDLE");

    /* begin */
    int r = tx_begin(&tx, &g_bridge.rewind, &g_bridge.dna, RWSLOT_HEAD_NONE);
    ASSERT(r == 0,               "tx_begin returns 0");
    ASSERT(tx.state == TX_ACTIVE,"tx.state = ACTIVE after begin");
    ASSERT(tx.snapshot_head == g_bridge.rewind.head, "snapshot_head captured");

    /* do 3 writes via bridge tx */
    for (int i = 0; i < 3; i++) {
        uint64_t addr = (uint64_t)(0x1000 + i * 0x100);
        const uint8_t face[6] = {0};
        l38_bridge_write_tx(&g_bridge, addr, (uint64_t)i, face, 0, &tx);
    }
    ASSERT(tx.op_count == 3, "op_count = 3 after 3 writes");

    /* commit */
    r = tx_commit(&tx);
    ASSERT(r == 0,             "tx_commit returns 0");
    ASSERT(tx.state == TX_IDLE,"tx.state = IDLE after commit");

    /* begin again + abort */
    uint32_t head_before = g_bridge.rewind.head;
    tx_begin(&tx, &g_bridge.rewind, &g_bridge.dna, RWSLOT_HEAD_NONE);
    const uint8_t face[6] = {0};
    l38_bridge_write_tx(&g_bridge, 0x9000, 0xDEAD, face, 0, &tx);
    l38_bridge_write_tx(&g_bridge, 0x9100, 0xBEEF, face, 0, &tx);
    ASSERT(g_bridge.rewind.head == head_before + 2, "2 slots pushed before abort");

    r = tx_abort(&tx, &g_bridge.rewind);
    ASSERT(r == 0, "tx_abort returns 0");
    ASSERT(tx.state == TX_ABORTED, "tx.state = ABORTED");
    ASSERT(g_bridge.rewind.head == head_before, "rewind.head rolled back to before abort");

    /* double-begin blocked */
    tx_begin(&tx, &g_bridge.rewind, &g_bridge.dna, RWSLOT_HEAD_NONE);
    int r2 = tx_begin(&tx, &g_bridge.rewind, &g_bridge.dna, RWSLOT_HEAD_NONE);
    ASSERT(r2 == -1, "double tx_begin returns -1 (blocked)");
    tx_commit(&tx);
}

/* ── H3: GPU adaptive throttle ───────────────────────────────────── */
static void test_h3_throttle(void) {
    printf("\nH3: GPU adaptive throttle\n");
    GPUThrottle t;
    gpu_throttle_init(&t);
    ASSERT(t.rate == 1.0f, "initial rate = 1.0");

    RewindBuffer rb;
    rewind_init(&rb, NULL, NULL, NULL);
    DiamondBlock b = make_block(1);

    /* fill to < 50% → rate stays 1.0 */
    uint32_t target_50 = REWIND_MAX * 49u / 100u;
    for (uint32_t i = 0; i < target_50; i++)
        rewind_push(&rb, &b, i, 0);
    float r50 = gpu_throttle_update(&t, &rb);
    ASSERT(r50 == 1.0f, "fill < 50%: rate = 1.0");

    /* fill to 60% → rate = 0.75 */
    uint32_t target_60 = REWIND_MAX * 60u / 100u;
    for (uint32_t i = target_50; i < target_60; i++)
        rewind_push(&rb, &b, i, 0);
    float r60 = gpu_throttle_update(&t, &rb);
    ASSERT(r60 == 0.75f, "fill 50-70%: rate = 0.75");
    ASSERT(t.throttle_events >= 1, "throttle_events >= 1");

    /* fill to 80% → rate = 0.5 */
    uint32_t target_80 = REWIND_MAX * 80u / 100u;
    for (uint32_t i = target_60; i < target_80; i++)
        rewind_push(&rb, &b, i, 0);
    float r80 = gpu_throttle_update(&t, &rb);
    ASSERT(r80 == 0.50f, "fill 70-90%: rate = 0.5");

    /* fill to 95% → rate = 0.25 */
    uint32_t target_95 = REWIND_MAX * 95u / 100u;
    for (uint32_t i = target_80; i < target_95; i++)
        rewind_push(&rb, &b, i, 0);
    float r95 = gpu_throttle_update(&t, &rb);
    ASSERT(r95 == 0.25f, "fill > 90%: rate = 0.25 (emergency brake)");

    /* batch scaling */
    uint32_t full_batch = 1024;
    uint32_t scaled = gpu_throttle_batch(&t, full_batch);
    ASSERT(scaled == 256, "batch(1024) at rate 0.25 = 256");
    ASSERT(scaled >= 1,   "batch always >= 1 (never zero)");
}

/* ── H4: Snapshot versioner ───────────────────────────────────────── */
static void test_h4_snap_versioner(void) {
    printf("\nH4: Snapshot version tag\n");
    SnapVersioner sv;
    snap_init(&sv);
    ASSERT(sv.magic == SNAP_MAGIC, "snap magic correct");
    ASSERT(sv.snap_id == 0,        "snap_id = 0 initially");
    ASSERT(sv.global_id == 0,      "global_id = 0 initially");

    /* write 31 times — snap_id should NOT advance yet */
    for (int i = 0; i < 31; i++)
        snap_record(&sv, 0);
    ASSERT(sv.snap_id == 0,       "snap_id = 0 after 31 writes (< 32)");
    ASSERT(sv.total_writes == 31, "total_writes = 31");

    /* write 1 more → snap_id advances */
    snap_record(&sv, 0);
    ASSERT(sv.snap_id == 1,       "snap_id = 1 after 32 writes");
    ASSERT(sv.total_writes == 32, "total_writes = 32");

    /* write 32 more → snap_id = 2 */
    for (int i = 0; i < 32; i++)
        snap_record(&sv, 0);
    ASSERT(sv.snap_id == 2, "snap_id = 2 after 64 writes");

    /* global_id = epoch << 20 | snap_id */
    snap_record(&sv, 5);  /* epoch = 5 */
    uint64_t expected = ((uint64_t)5 << 20) | sv.snap_id;
    ASSERT(sv.global_id == expected, "global_id = epoch<<20 | snap_id");

    /* snap_target helper */
    uint64_t t = snap_target(3, 7);
    ASSERT(t == (((uint64_t)3 << 20) | 7u), "snap_target(3,7) correct");

    /* snap_before ordering */
    ASSERT(snap_before(snap_target(1,0), snap_target(2,0)), "epoch 1 before epoch 2");
    ASSERT(!snap_before(snap_target(2,0), snap_target(1,0)), "epoch 2 NOT before epoch 1");
    ASSERT(snap_before(snap_target(1,5), snap_target(1,9)),  "same epoch: snap 5 before 9");
}

/* ── H5: HardenCtx combined ───────────────────────────────────────── */
static void test_h5_combined(void) {
    printf("\nH5: HardenCtx combined (H1+H2+H3+H4)\n");
    L38EngineBridge b2;
    l38_bridge_init(&b2, NULL, NULL, NULL, NULL, NULL);
    SplitWorldCtx sw2;
    split_world_init(&sw2, &b2);
    HardenCtx h;
    harden_init(&h);

    ASSERT(harden_validate(&h) == HARDEN_OK, "harden_validate = HARDEN_OK");
    ASSERT(h.throttle.rate == 1.0f, "initial throttle rate = 1.0");
    ASSERT(h.versioner.snap_id == 0, "initial snap_id = 0");

    /* split + write through harden */
    l38_split(&sw2, 0x2002);   /* 0x2002 % 17 = 0 → mod17=1 for addrs */
    const uint8_t face[6] = {1,2,3,4,5,6};

    for (int i = 0; i < 17; i++) {
        SplitWriteResult r = harden_split_write(&h, &sw2, (uint64_t)i, face);
        (void)r;
    }

    ASSERT(h.versioner.total_writes == 17, "versioner total_writes = 17");
    ASSERT(b2.total_writes >= 17, "bridge total_writes >= 17");

    /* abort test */
    uint32_t head_snap = b2.rewind.head;
    harden_split_write(&h, &sw2, 0xDEAD, face);
    int r = harden_abort(&h, &b2);
    ASSERT(r == 0, "harden_abort returns 0");
    ASSERT(h.abort_count == 1, "abort_count = 1");
    ASSERT(b2.rewind.head <= head_snap + 2, "rewind head at or near abort snapshot");

    l38_rejoin(&sw2);
    ASSERT(sw2.is_split == 0, "clean split after rejoin");
}

int main(void) {
    printf("=== Harden Layer Tests (H1-H4) ===\n");
    printf("Rewind binding + Atomic TX + Adaptive throttle + Snap versioner\n\n");
    test_h1_head_binding();
    test_h2_atomic_tx();
    test_h3_throttle();
    test_h4_snap_versioner();
    test_h5_combined();
    printf("\n═══════════════════════════════════\n");
    printf("RESULT: %d PASS  /  %d FAIL  /  %d TOTAL\n",
           _pass, _fail, _pass + _fail);
    printf("═══════════════════════════════════\n");
    return _fail > 0 ? 1 : 0;
}
