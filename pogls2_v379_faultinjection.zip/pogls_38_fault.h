/*
 * pogls_38_fault.h — POGLS38 Fault Injection Harness
 * ══════════════════════════════════════════════════════════════════════
 *
 * Chaos test layer สำหรับ verify "ถึกจริง" ก่อน Phase E
 *
 * 4 fault modes:
 *   F1: drop_random     — ทิ้ง write แบบสุ่ม (1-5% default)
 *   F2: reorder         — สลับลำดับ write ใน batch
 *   F3: delay           — inject latency แบบสุ่ม (จำลอง GPU stall)
 *   F4: kill_mid_tx     — abort tx กลางอากาศ
 *
 * เปรียบเทียบ:
 *   happy path test = ขับรถบนถนนเรียบ แดดออก
 *   fault injection = ขับรถบนถนนขรุขระ ฝนตก ยางแตก ไฟดับ
 *   ถ้ารอด = ระบบคุณ "ถึกจริง"
 *
 * Invariants ที่ต้องรักษาตลอด chaos:
 *   1. determinism   — input เดิม + seed เดิม → output เดิมเสมอ
 *   2. no half-state — ทุก write either committed หรือ rolled back
 *   3. head isolation — HEAD_A rewind ไม่กระทบ HEAD_B และ vice versa
 *   4. snap_id monotonic — global_id ไม่ถอยหลัง
 *
 * Usage:
 *   FaultCtx f;
 *   fault_init(&f, seed, FAULT_DROP | FAULT_KILL_TX, 3);
 *   FaultResult r = fault_write(&f, &h, &sw, value, face);
 *   // check r.invariants_ok == 1 after every write
 *
 * ══════════════════════════════════════════════════════════════════════
 */

#ifndef POGLS_38_FAULT_H
#define POGLS_38_FAULT_H

#include <stdint.h>
#include <string.h>
#include "pogls_38_harden.h"

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 1 — CONSTANTS
 * ══════════════════════════════════════════════════════════════════════ */

#define FAULT_NONE      0x00u
#define FAULT_DROP      0x01u   /* F1: drop write randomly               */
#define FAULT_REORDER   0x02u   /* F2: buffer + reorder writes           */
#define FAULT_DELAY     0x04u   /* F3: inject fake latency counter       */
#define FAULT_KILL_TX   0x08u   /* F4: abort tx mid-flight               */
#define FAULT_ALL       0x0Fu   /* all faults enabled                    */

#define FAULT_MAGIC     0x46554C54u  /* "FULT" */
#define FAULT_REORDER_BUF 16u        /* reorder buffer size               */
#define FAULT_DROP_PCT_DEFAULT 3u    /* default drop rate = 3%            */
#define FAULT_KILL_TX_EVERY   7u     /* kill tx every N writes (prime)    */

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 2 — PRNG (xorshift32 — deterministic, seedable)
 *
 * ใช้ xorshift32 แทน rand() เพราะ:
 *   - deterministic: seed เดิม → sequence เดิม
 *   - ไม่มี global state (ไม่กระทบ test อื่น)
 *   - fast: 3 XOR shifts = O(1)
 * ══════════════════════════════════════════════════════════════════════ */

static inline uint32_t _xor32(uint32_t *state)
{
    uint32_t x = *state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *state = x;
    return x;
}

/* percent chance: returns 1 with probability pct/100 */
static inline int _pct(uint32_t *rng, uint32_t pct)
{
    return (_xor32(rng) % 100u) < pct;
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 3 — REORDER BUFFER (F2)
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint64_t values[FAULT_REORDER_BUF];
    uint8_t  faces[FAULT_REORDER_BUF][6];
    uint8_t  count;
    uint8_t  _pad[3];
} ReorderBuf;

static inline void reorder_init(ReorderBuf *rb) {
    memset(rb, 0, sizeof(*rb));
}

static inline int reorder_push(ReorderBuf *rb, uint64_t val, const uint8_t face[6])
{
    if (rb->count >= FAULT_REORDER_BUF) return -1;  /* buf full */
    rb->values[rb->count] = val;
    if (face) memcpy(rb->faces[rb->count], face, 6);
    rb->count++;
    return 0;
}

/* Fisher-Yates shuffle of buffer */
static inline void reorder_shuffle(ReorderBuf *rb, uint32_t *rng)
{
    for (uint8_t i = rb->count - 1; i > 0; i--) {
        uint8_t j = (uint8_t)(_xor32(rng) % (i + 1));
        uint64_t tv = rb->values[i]; rb->values[i] = rb->values[j]; rb->values[j] = tv;
        uint8_t tf[6];
        memcpy(tf, rb->faces[i], 6);
        memcpy(rb->faces[i], rb->faces[j], 6);
        memcpy(rb->faces[j], tf, 6);
    }
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 4 — FAULT STATS
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint64_t writes_attempted;  /* total writes sent to fault layer      */
    uint64_t writes_dropped;    /* F1: writes dropped                    */
    uint64_t writes_reordered;  /* F2: writes that went through reorder  */
    uint64_t delays_injected;   /* F3: latency injections                */
    uint64_t tx_kills;          /* F4: tx_abort() forced mid-flight      */
    uint64_t invariant_violations; /* times any invariant was broken     */
    uint64_t writes_completed;  /* writes that survived all faults       */
} FaultStats;

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 5 — INVARIANT CHECKER
 *
 * After every write (faulted or not), verify:
 *   I1: determinism  — snap_id never decreases
 *   I2: head isolation — HEAD_A write_count independent of HEAD_B
 *   I3: rewind depth in bounds [0, REWIND_MAX]
 *   I4: bridge magic intact
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint32_t last_snap_id;      /* for I1 monotonic check               */
    uint32_t _pad;
} InvariantState;

static inline void inv_init(InvariantState *iv) {
    memset(iv, 0, sizeof(*iv));
}

typedef struct {
    uint8_t i1_snap_monotonic;  /* snap_id didn't go backwards          */
    uint8_t i2_head_isolated;   /* split head counts independent        */
    uint8_t i3_rewind_bounds;   /* rewind depth in [0, REWIND_MAX]      */
    uint8_t i4_magic_intact;    /* bridge magic still valid             */
    uint8_t all_ok;             /* 1 = all invariants hold              */
    uint8_t _pad[3];
} InvariantResult;

static inline InvariantResult inv_check(InvariantState        *iv,
                                         const HardenCtx       *h,
                                         const L38EngineBridge *b,
                                         const SplitWorldCtx   *sw)
{
    InvariantResult r = {0};

    /* I1: snap_id monotonic */
    r.i1_snap_monotonic = (h->versioner.snap_id >= iv->last_snap_id) ? 1u : 0u;
    iv->last_snap_id = h->versioner.snap_id;

    /* I2: head isolation — if split, each head tracks independently */
    r.i2_head_isolated = 1u;
    if (sw->is_split) {
        /* counts are independent: A≠B or both 0 is fine */
        /* violation: both heads have EXACT same internal ptr (shared state) */
        /* we check that head structs are at different memory addresses */
        r.i2_head_isolated = (&sw->heads[0] != &sw->heads[1]) ? 1u : 0u;
    }

    /* I3: rewind depth in bounds */
    uint32_t depth = rewind_depth(&b->rewind);
    r.i3_rewind_bounds = (depth <= REWIND_MAX) ? 1u : 0u;

    /* I4: bridge magic intact */
    r.i4_magic_intact = (b->magic == BRIDGE_MAGIC) ? 1u : 0u;

    r.all_ok = r.i1_snap_monotonic & r.i2_head_isolated &
               r.i3_rewind_bounds  & r.i4_magic_intact;
    return r;
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 6 — FAULT CONTEXT
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint32_t       magic;
    uint8_t        enabled;       /* FAULT_* bitmask                      */
    uint8_t        drop_pct;      /* F1: drop probability %               */
    uint8_t        kill_every;    /* F4: kill tx every N writes           */
    uint8_t        _pad;
    uint32_t       rng;           /* xorshift32 state (seed)              */
    uint32_t       write_counter; /* total writes seen                    */
    ReorderBuf     rbuf;          /* F2 buffer                            */
    FaultStats     stats;
    InvariantState inv;
} FaultCtx;

static inline void fault_init(FaultCtx *f, uint32_t seed,
                                uint8_t enabled, uint8_t drop_pct)
{
    if (!f) return;
    memset(f, 0, sizeof(*f));
    f->magic      = FAULT_MAGIC;
    f->enabled    = enabled;
    f->drop_pct   = drop_pct ? drop_pct : FAULT_DROP_PCT_DEFAULT;
    f->kill_every = FAULT_KILL_TX_EVERY;
    f->rng        = seed ? seed : 0xDEADBEEFu;
    reorder_init(&f->rbuf);
    inv_init(&f->inv);
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 7 — FAULT WRITE RESULT
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    SplitWriteResult  write;         /* underlying write result (if not dropped) */
    uint8_t           dropped;       /* F1: write was dropped                    */
    uint8_t           reordered;     /* F2: write went through reorder buffer    */
    uint32_t          delay_cycles;  /* F3: simulated latency cycles             */
    uint8_t           tx_killed;     /* F4: tx was aborted this write            */
    uint8_t           _pad[3];
    InvariantResult   invariants;    /* all 4 invariants checked                 */
} FaultResult;

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 8 — FAULT WRITE (main entry point)
 *
 * Applies enabled faults then calls harden_split_write().
 * Always checks invariants after.
 * ══════════════════════════════════════════════════════════════════════ */

static inline FaultResult fault_write(FaultCtx       *f,
                                       HardenCtx      *h,
                                       SplitWorldCtx  *sw,
                                       uint64_t        value,
                                       const uint8_t   face[6])
{
    FaultResult res = {0};
    if (!f || !h || !sw) return res;

    f->stats.writes_attempted++;
    f->write_counter++;
    L38EngineBridge *b = sw->bridge;

    /* ── F1: DROP ──────────────────────────────────────────────────── */
    if ((f->enabled & FAULT_DROP) && _pct(&f->rng, f->drop_pct)) {
        res.dropped = 1;
        f->stats.writes_dropped++;
        /* check invariants even on drop */
        res.invariants = inv_check(&f->inv, h, b, sw);
        if (!res.invariants.all_ok) f->stats.invariant_violations++;
        return res;
    }

    /* ── F2: REORDER ───────────────────────────────────────────────── */
    if (f->enabled & FAULT_REORDER) {
        if (reorder_push(&f->rbuf, value, face) == 0) {
            f->stats.writes_reordered++;
            res.reordered = 1;
            /* flush buffer when full, after shuffle */
            if (f->rbuf.count >= FAULT_REORDER_BUF) {
                reorder_shuffle(&f->rbuf, &f->rng);
                for (uint8_t i = 0; i < f->rbuf.count; i++)
                    harden_split_write(h, sw, f->rbuf.values[i], f->rbuf.faces[i]);
                f->rbuf.count = 0;
            }
            res.invariants = inv_check(&f->inv, h, b, sw);
            if (!res.invariants.all_ok) f->stats.invariant_violations++;
            return res;
        }
        /* buf full fallthrough → write directly */
    }

    /* ── F3: DELAY ─────────────────────────────────────────────────── */
    if (f->enabled & FAULT_DELAY) {
        res.delay_cycles = _xor32(&f->rng) % 51u;  /* 0-50 simulated cycles */
        if (res.delay_cycles > 0) f->stats.delays_injected++;
        /* delay is simulated (no actual sleep in header-only code) */
    }

    /* ── F4: KILL_MID_TX ───────────────────────────────────────────── */
    if ((f->enabled & FAULT_KILL_TX) &&
        (f->write_counter % f->kill_every == 0)) {
        harden_abort(h, b);
        res.tx_killed = 1;
        f->stats.tx_kills++;
        /* re-check invariants after abort */
        res.invariants = inv_check(&f->inv, h, b, sw);
        if (!res.invariants.all_ok) f->stats.invariant_violations++;
        /* re-start split if it got confused */
        if (!sw->is_split) {
            /* note: we don't re-split here — caller handles split state */
        }
        f->stats.writes_completed++;
        return res;
    }

    /* ── NORMAL WRITE (after surviving faults) ─────────────────────── */
    res.write = harden_split_write(h, sw, value, face);
    f->stats.writes_completed++;

    /* ── INVARIANT CHECK ───────────────────────────────────────────── */
    res.invariants = inv_check(&f->inv, h, b, sw);
    if (!res.invariants.all_ok) f->stats.invariant_violations++;

    return res;
}

/* Flush remaining reorder buffer (end of test run) */
static inline void fault_flush_reorder(FaultCtx      *f,
                                        HardenCtx     *h,
                                        SplitWorldCtx *sw)
{
    if (!f || !h || !sw || f->rbuf.count == 0) return;
    reorder_shuffle(&f->rbuf, &f->rng);
    for (uint8_t i = 0; i < f->rbuf.count; i++)
        harden_split_write(h, sw, f->rbuf.values[i], f->rbuf.faces[i]);
    f->rbuf.count = 0;
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 9 — CHAOS TEST RUNNER
 *
 * Run N writes with all faults enabled.
 * Returns: 0 = no invariant violations, -1 = violations detected.
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint64_t writes_in;          /* writes attempted                     */
    uint64_t writes_out;         /* writes that completed                */
    uint64_t drops;              /* dropped writes                       */
    uint64_t reorders;           /* reordered writes                     */
    uint64_t tx_kills;           /* mid-tx aborts                        */
    uint64_t violations;         /* invariant violations                 */
    uint8_t  survived;           /* 1 = 0 violations, system is "thick"  */
    uint8_t  _pad[7];
} ChaosResult;

static inline ChaosResult chaos_run(uint32_t       seed,
                                     uint32_t       n_writes,
                                     uint8_t        drop_pct,
                                     L38EngineBridge *bridge)
{
    ChaosResult cr = {0};

    /* setup: split world + harden + fault ctx */
    SplitWorldCtx sw;
    split_world_init(&sw, bridge);
    l38_split(&sw, 0x2002);  /* 0x2002 % 17 = 0 → addr mod17=1 */

    HardenCtx h;
    harden_init(&h);

    FaultCtx f;
    fault_init(&f, seed, FAULT_ALL, drop_pct);

    const uint8_t face[6] = {1,2,3,4,5,6};

    for (uint32_t i = 0; i < n_writes; i++) {
        uint64_t val = (uint64_t)(i * 0x1117u + seed);

        /* re-split if rejoin happened due to gate_17 exhaustion */
        if (!sw.is_split) {
            l38_rejoin(&sw);   /* clean up if gate fired */
            l38_split(&sw, 0x2002 + (uint64_t)i * SPLIT_STRIDE);
        }

        fault_write(&f, &h, &sw, val, face);
    }

    /* flush reorder buffer */
    fault_flush_reorder(&f, &h, &sw);

    /* final rejoin */
    if (sw.is_split) l38_rejoin(&sw);

    cr.writes_in   = f.stats.writes_attempted;
    cr.writes_out  = f.stats.writes_completed;
    cr.drops       = f.stats.writes_dropped;
    cr.reorders    = f.stats.writes_reordered;
    cr.tx_kills    = f.stats.tx_kills;
    cr.violations  = f.stats.invariant_violations;
    cr.survived    = (cr.violations == 0) ? 1u : 0u;
    return cr;
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 10 — STATS PRINT
 * ══════════════════════════════════════════════════════════════════════ */

#include <stdio.h>

static inline void fault_stats_print(const FaultCtx *f)
{
    if (!f) return;
    const FaultStats *s = &f->stats;
    printf("\n╔══════════════════════════════════════════╗\n");
    printf("║  Fault Injection Stats                   ║\n");
    printf("╠══════════════════════════════════════════╣\n");
    printf("║ Writes attempted: %10llu              ║\n",
           (unsigned long long)s->writes_attempted);
    printf("║ Writes completed: %10llu              ║\n",
           (unsigned long long)s->writes_completed);
    printf("║ F1 Dropped:       %10llu              ║\n",
           (unsigned long long)s->writes_dropped);
    printf("║ F2 Reordered:     %10llu              ║\n",
           (unsigned long long)s->writes_reordered);
    printf("║ F3 Delays:        %10llu              ║\n",
           (unsigned long long)s->delays_injected);
    printf("║ F4 TX kills:      %10llu              ║\n",
           (unsigned long long)s->tx_kills);
    printf("║ Violations:       %10llu  %s          ║\n",
           (unsigned long long)s->invariant_violations,
           s->invariant_violations == 0 ? "✓ NONE" : "✗ FAIL");
    printf("╚══════════════════════════════════════════╝\n\n");
}

static inline void chaos_result_print(const ChaosResult *cr)
{
    if (!cr) return;
    printf("\n╔══════════════════════════════════════════╗\n");
    printf("║  Chaos Test Result                       ║\n");
    printf("╠══════════════════════════════════════════╣\n");
    printf("║ Writes in/out: %5llu / %5llu              ║\n",
           (unsigned long long)cr->writes_in,
           (unsigned long long)cr->writes_out);
    printf("║ Drops:         %10llu              ║\n",
           (unsigned long long)cr->drops);
    printf("║ TX kills:      %10llu              ║\n",
           (unsigned long long)cr->tx_kills);
    printf("║ Violations:    %10llu              ║\n",
           (unsigned long long)cr->violations);
    printf("║ SURVIVED:      %s                        ║\n",
           cr->survived ? "✅ YES — system is bulletproof"
                        : "❌ NO  — invariant broken");
    printf("╚══════════════════════════════════════════╝\n\n");
}

#endif /* POGLS_38_FAULT_H */
