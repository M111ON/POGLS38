/*
 * test_fault.c — Fault Injection + Chaos Tests
 *
 * T01: PRNG determinism — seed เดิม → sequence เดิม
 * T02: F1 drop — write ถูกทิ้งตาม probability
 * T03: F2 reorder — buffer shuffle ก่อน flush
 * T04: F3 delay — delay counter accumulates
 * T05: F4 kill_mid_tx — abort fires every kill_every writes
 * T06: invariant I1 — snap_id monotonic ตลอด chaos
 * T07: invariant I3 — rewind depth never exceeds REWIND_MAX
 * T08: invariant I4 — bridge magic never corrupted
 * T09: chaos_run small — 100 writes, all faults, 0 violations
 * T10: chaos_run medium — 500 writes, FAULT_DROP|FAULT_KILL_TX
 * T11: chaos_run seed variation — different seeds, all survive
 * T12: chaos_run drop 5% — high drop rate, system still consistent
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "pogls_fold.h"
#include "pogls_38_fault.h"

static int _pass = 0, _fail = 0;
#define ASSERT(cond, msg) do { \
    if (cond) { printf("  [PASS] %s\n", msg); _pass++; } \
    else       { printf("  [FAIL] %s  (line %d)\n", msg, __LINE__); _fail++; } \
} while(0)

static L38EngineBridge g_b;
static int g_ready = 0;
static void ensure_bridge(void) {
    if (!g_ready) {
        l38_bridge_init(&g_b, NULL, NULL, NULL, NULL, NULL);
        g_ready = 1;
    }
}

/* ── T01: PRNG determinism ────────────────────────────────────────── */
static void test_01_prng(void) {
    printf("\nT01: PRNG determinism\n");
    uint32_t s1 = 0xABCD, s2 = 0xABCD;
    uint32_t seq1[8], seq2[8];
    for (int i = 0; i < 8; i++) { seq1[i] = _xor32(&s1); seq2[i] = _xor32(&s2); }
    int same = 1;
    for (int i = 0; i < 8; i++) if (seq1[i] != seq2[i]) { same = 0; break; }
    ASSERT(same, "same seed → same sequence (deterministic)");

    uint32_t s3 = 0x1234;
    uint32_t diff = 0;
    for (int i = 0; i < 8; i++) diff |= (_xor32(&s1) != _xor32(&s3));
    ASSERT(diff, "different seed → different sequence");
}

/* ── T02: F1 drop ─────────────────────────────────────────────────── */
static void test_02_drop(void) {
    printf("\nT02: F1 drop probability\n");
    ensure_bridge();
    SplitWorldCtx sw; split_world_init(&sw, &g_b);
    l38_split(&sw, 0x2002);
    HardenCtx h; harden_init(&h);
    FaultCtx f;
    fault_init(&f, 0x1111, FAULT_DROP, 50);  /* 50% drop for clear signal */

    const uint8_t face[6] = {0};
    int dropped = 0, total = 200;
    for (int i = 0; i < total; i++) {
        FaultResult r = fault_write(&f, &h, &sw, (uint64_t)i, face);
        if (r.dropped) dropped++;
        if (!sw.is_split) { l38_rejoin(&sw); l38_split(&sw, 0x2002); }
    }
    l38_rejoin(&sw);

    /* at 50% drop, expect roughly 80-120 drops out of 200 */
    ASSERT(dropped > 50 && dropped < 150,
           "50% drop rate: ~50-150 drops in 200 writes (probabilistic)");
    ASSERT(f.stats.invariant_violations == 0,
           "no invariant violations after drops");
    printf("  [INFO] drops = %d / %d\n", dropped, total);
    _pass++;
}

/* ── T03: F2 reorder ──────────────────────────────────────────────── */
static void test_03_reorder(void) {
    printf("\nT03: F2 reorder\n");
    ReorderBuf rb; reorder_init(&rb);
    uint32_t rng = 0xBEEF;
    const uint8_t face[6] = {1,2,3,4,5,0};

    for (int i = 0; i < 8; i++)
        reorder_push(&rb, (uint64_t)i, face);
    ASSERT(rb.count == 8, "8 items in reorder buf");

    /* save original order */
    uint64_t orig[8];
    for (int i = 0; i < 8; i++) orig[i] = rb.values[i];

    reorder_shuffle(&rb, &rng);

    /* after shuffle, same elements but different order (with high prob) */
    uint64_t sum_orig = 0, sum_shuf = 0;
    int order_changed = 0;
    for (int i = 0; i < 8; i++) {
        sum_orig += orig[i];
        sum_shuf += rb.values[i];
        if (rb.values[i] != orig[i]) order_changed = 1;
    }
    ASSERT(sum_orig == sum_shuf, "shuffle preserves all values (no loss)");
    ASSERT(order_changed,        "shuffle changed order (not identity)");
}

/* ── T04: F3 delay ────────────────────────────────────────────────── */
static void test_04_delay(void) {
    printf("\nT04: F3 delay counter\n");
    ensure_bridge();
    SplitWorldCtx sw; split_world_init(&sw, &g_b);
    l38_split(&sw, 0x2002);
    HardenCtx h; harden_init(&h);
    FaultCtx f;
    fault_init(&f, 0x2222, FAULT_DELAY, 0);

    const uint8_t face[6] = {0};
    uint64_t total_delay = 0;
    int writes = 50;
    for (int i = 0; i < writes; i++) {
        FaultResult r = fault_write(&f, &h, &sw, (uint64_t)i, face);
        total_delay += r.delay_cycles;
        if (!sw.is_split) { l38_rejoin(&sw); l38_split(&sw, 0x2002); }
    }
    l38_rejoin(&sw);
    ASSERT(f.stats.delays_injected > 0,   "delays injected (some > 0 cycles)");
    ASSERT(total_delay <= (uint64_t)writes * 50u, "total delay <= max (50 cycles/write)");
    ASSERT(f.stats.invariant_violations == 0, "no violations after delays");
    printf("  [INFO] delays injected: %llu, total cycles: %llu\n",
           (unsigned long long)f.stats.delays_injected,
           (unsigned long long)total_delay);
    _pass++;
}

/* ── T05: F4 kill_mid_tx ──────────────────────────────────────────── */
static void test_05_kill_tx(void) {
    printf("\nT05: F4 kill_mid_tx\n");
    ensure_bridge();
    uint32_t head_before = g_b.rewind.head;
    SplitWorldCtx sw; split_world_init(&sw, &g_b);
    l38_split(&sw, 0x2002);
    HardenCtx h; harden_init(&h);
    FaultCtx f;
    fault_init(&f, 0x3333, FAULT_KILL_TX, 0);
    f.kill_every = 3;  /* kill every 3 writes */

    const uint8_t face[6] = {0};
    int kills = 0;
    for (int i = 0; i < 30; i++) {
        FaultResult r = fault_write(&f, &h, &sw, (uint64_t)i, face);
        if (r.tx_killed) kills++;
        if (!sw.is_split) { l38_rejoin(&sw); l38_split(&sw, 0x2002); }
    }
    l38_rejoin(&sw);

    ASSERT(kills >= 5,  "at least 5 tx kills in 30 writes (every 3)");
    ASSERT(f.stats.tx_kills == (uint64_t)kills, "tx_kills stats match");
    ASSERT(f.stats.invariant_violations == 0,   "no violations after tx kills");

    /* rewind head must not exceed writes (kills should constrain it) */
    ASSERT(g_b.rewind.head <= head_before + 30 + kills,
           "rewind head bounded despite kills");
    printf("  [INFO] kills = %d / 30 writes\n", kills);
    _pass++;
}

/* ── T06: invariant I1 — snap_id monotonic ───────────────────────── */
static void test_06_inv_snap_monotonic(void) {
    printf("\nT06: I1 snap_id monotonic through all faults\n");
    ensure_bridge();
    SplitWorldCtx sw; split_world_init(&sw, &g_b);
    l38_split(&sw, 0x2002);
    HardenCtx h; harden_init(&h);
    FaultCtx f;
    fault_init(&f, 0x4444, FAULT_ALL, 2);

    const uint8_t face[6] = {0};
    uint32_t last_id = 0;
    int backwards = 0;
    for (int i = 0; i < 100; i++) {
        fault_write(&f, &h, &sw, (uint64_t)i, face);
        if (h.versioner.snap_id < last_id) backwards = 1;
        last_id = h.versioner.snap_id;
        if (!sw.is_split) { l38_rejoin(&sw); l38_split(&sw, 0x2002); }
    }
    l38_rejoin(&sw);

    ASSERT(!backwards, "snap_id never goes backwards (monotonic)");
    ASSERT(f.stats.invariant_violations == 0, "I1 violations = 0");
}

/* ── T07: invariant I3 — rewind depth bounded ───────────────────── */
static void test_07_inv_rewind_bounds(void) {
    printf("\nT07: I3 rewind depth always <= REWIND_MAX\n");
    ensure_bridge();
    SplitWorldCtx sw; split_world_init(&sw, &g_b);
    l38_split(&sw, 0x2002);
    HardenCtx h; harden_init(&h);
    FaultCtx f;
    fault_init(&f, 0x5555, FAULT_DROP | FAULT_KILL_TX, 0);

    const uint8_t face[6] = {0};
    int overflow = 0;
    for (int i = 0; i < 200; i++) {
        fault_write(&f, &h, &sw, (uint64_t)i, face);
        if (rewind_depth(&g_b.rewind) > REWIND_MAX) overflow = 1;
        if (!sw.is_split) { l38_rejoin(&sw); l38_split(&sw, 0x2002); }
    }
    l38_rejoin(&sw);
    ASSERT(!overflow, "rewind depth never exceeds REWIND_MAX");
}

/* ── T08: invariant I4 — bridge magic intact ─────────────────────── */
static void test_08_inv_magic(void) {
    printf("\nT08: I4 bridge magic never corrupted\n");
    ensure_bridge();
    SplitWorldCtx sw; split_world_init(&sw, &g_b);
    l38_split(&sw, 0x2002);
    HardenCtx h; harden_init(&h);
    FaultCtx f;
    fault_init(&f, 0x6666, FAULT_ALL, 5);

    const uint8_t face[6] = {0};
    int corrupted = 0;
    for (int i = 0; i < 100; i++) {
        fault_write(&f, &h, &sw, (uint64_t)i, face);
        if (g_b.magic != BRIDGE_MAGIC) corrupted = 1;
        if (!sw.is_split) { l38_rejoin(&sw); l38_split(&sw, 0x2002); }
    }
    l38_rejoin(&sw);
    ASSERT(!corrupted, "BRIDGE_MAGIC intact through all faults");
    ASSERT(f.stats.invariant_violations == 0, "I4 violations = 0");
}

/* ── T09: chaos_run 100 writes, all faults ───────────────────────── */
static void test_09_chaos_small(void) {
    printf("\nT09: chaos_run 100 writes, FAULT_ALL, 3%% drop\n");
    L38EngineBridge b; l38_bridge_init(&b, NULL, NULL, NULL, NULL, NULL);
    ChaosResult cr = chaos_run(0xCAFE, 100, 3, &b);
    chaos_result_print(&cr);
    ASSERT(cr.survived, "chaos_run 100 survived (0 violations)");
    ASSERT(cr.writes_in == 100, "100 writes attempted");
}

/* ── T10: chaos_run 500 writes, drop + kill ──────────────────────── */
static void test_10_chaos_medium(void) {
    printf("\nT10: chaos_run 500 writes, DROP+KILL_TX\n");
    L38EngineBridge b; l38_bridge_init(&b, NULL, NULL, NULL, NULL, NULL);

    /* manual chaos with specific fault set */
    SplitWorldCtx sw; split_world_init(&sw, &b);
    l38_split(&sw, 0x2002);
    HardenCtx h; harden_init(&h);
    FaultCtx f;
    fault_init(&f, 0xF00D, FAULT_DROP | FAULT_KILL_TX, 3);

    const uint8_t face[6] = {2,3,4,5,6,7};
    for (int i = 0; i < 500; i++) {
        fault_write(&f, &h, &sw, (uint64_t)(i * 0x337 + 1), face);
        if (!sw.is_split) { l38_rejoin(&sw); l38_split(&sw, 0x2002); }
    }
    l38_rejoin(&sw);

    ASSERT(f.stats.invariant_violations == 0,
           "500 writes DROP+KILL_TX: 0 invariant violations");
    printf("  [INFO] drops=%llu kills=%llu completed=%llu\n",
           (unsigned long long)f.stats.writes_dropped,
           (unsigned long long)f.stats.tx_kills,
           (unsigned long long)f.stats.writes_completed);
    _pass++;
}

/* ── T11: chaos_run different seeds ─────────────────────────────── */
static void test_11_chaos_seeds(void) {
    printf("\nT11: chaos_run 3 different seeds, all survive\n");
    uint32_t seeds[3] = {0x1234, 0xDEAD, 0xBEEF};
    int all_survived = 1;
    for (int s = 0; s < 3; s++) {
        L38EngineBridge b; l38_bridge_init(&b, NULL, NULL, NULL, NULL, NULL);
        ChaosResult cr = chaos_run(seeds[s], 200, 3, &b);
        if (!cr.survived) { all_survived = 0; }
        printf("  [INFO] seed=0x%04X drops=%llu kills=%llu violations=%llu %s\n",
               seeds[s],
               (unsigned long long)cr.drops,
               (unsigned long long)cr.tx_kills,
               (unsigned long long)cr.violations,
               cr.survived ? "✓" : "✗");
    }
    ASSERT(all_survived, "all 3 seeds: 0 violations (deterministic across seeds)");
}

/* ── T12: chaos 5% drop rate ────────────────────────────────────── */
static void test_12_chaos_high_drop(void) {
    printf("\nT12: chaos_run 300 writes, 5%% drop rate\n");
    L38EngineBridge b; l38_bridge_init(&b, NULL, NULL, NULL, NULL, NULL);
    ChaosResult cr = chaos_run(0xA5A5, 300, 5, &b);
    chaos_result_print(&cr);
    ASSERT(cr.survived, "5%% drop: system survived (0 violations)");
    ASSERT(cr.drops > 0 && cr.drops < 300,
           "some drops occurred (not 0, not all)");
}

int main(void) {
    printf("=== Fault Injection + Chaos Tests ===\n");
    printf("F1:drop F2:reorder F3:delay F4:kill_tx + invariant checks\n\n");
    test_01_prng();
    test_02_drop();
    test_03_reorder();
    test_04_delay();
    test_05_kill_tx();
    test_06_inv_snap_monotonic();
    test_07_inv_rewind_bounds();
    test_08_inv_magic();
    test_09_chaos_small();
    test_10_chaos_medium();
    test_11_chaos_seeds();
    test_12_chaos_high_drop();
    printf("\n═══════════════════════════════════\n");
    printf("RESULT: %d PASS  /  %d FAIL  /  %d TOTAL\n",
           _pass, _fail, _pass + _fail);
    printf("═══════════════════════════════════\n");
    return _fail > 0 ? 1 : 0;
}
