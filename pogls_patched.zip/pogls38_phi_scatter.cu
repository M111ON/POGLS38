/*
 * pogls38_phi_scatter.cu
 *
 * Priority 4 — CUDA stub: PHI scatter → Voronoi classify → angular_addr
 *
 * Each CUDA thread handles ONE hil value:
 *   thread i → phi_scatter(hil[i]) → voronoi_classify → predict_next → addr_out[i]
 *
 * Compile (Colab / nvcc):
 *   nvcc -O2 -arch=sm_75 pogls38_phi_scatter.cu -o pogls38_phi_scatter
 *   ./pogls38_phi_scatter
 *
 * Geometry: 1 thread = 1 lane.
 * Grid = ceil(N/256) blocks × 256 threads.
 * No shared memory needed — each thread is fully independent.
 */

#include <stdio.h>
#include <stdint.h>
#include <assert.h>

/* ── PHI constants (frozen, matches pogls_platform.h) ─────────────── */
#define PHI_SCALE    (1u  << 20)     /* 2^20 */
#define PHI_UP       1696631u
#define PHI_DOWN      648055u
#define PHI_MASK     (PHI_SCALE - 1u)

/* ── Voronoi seeds (9 clusters, matches pogls_mesh.h) ─────────────── */
#define MESH_N_SEEDS  9

__constant__ uint32_t d_seed_a[MESH_N_SEEDS] = {
    103984u, 520963u, 568421u,  80861u, 244791u,
    729951u, 407093u, 312985u, 941846u
};
__constant__ uint32_t d_seed_b[MESH_N_SEEDS] = {
     39718u, 198989u, 617637u, 431406u, 494021u,
    278816u, 556015u, 119549u, 359752u
};

/* ── GiantShadow offset table (per cluster, signed delta) ─────────── */
/* Host fills d_gs_offset before kernel launch */
__constant__ int64_t d_gs_offset[MESH_N_SEEDS];

/* ── Device: squared distance in PHI space (integer, no float) ─────── */
__device__ static inline uint64_t phi_dist2(uint32_t a1, uint32_t b1,
                                              uint32_t a2, uint32_t b2)
{
    int64_t da = (int64_t)a1 - (int64_t)a2;
    int64_t db = (int64_t)b1 - (int64_t)b2;
    return (uint64_t)(da*da + db*db);
}

/* ── Device: voronoi classify — same logic as CPU scalar ────────────── */
__device__ static inline uint8_t dev_voronoi_classify(uint32_t a, uint32_t b)
{
    uint8_t  best   = 0;
    uint64_t best_d = UINT64_MAX;
    for (uint8_t i = 0; i < MESH_N_SEEDS; i++) {
        uint64_t d = phi_dist2(a, b, d_seed_a[i], d_seed_b[i]);
        if (d < best_d) { best_d = d; best = i; }
    }
    return best;
}

/* ════════════════════════════════════════════════════════════════════
 * Kernel: phi_scatter_kernel
 *
 * Inputs:
 *   hil_in[N]   — base addresses (uint64)
 *   has_gs      — 1 = use gs_offset, 0 = passthrough
 * Output:
 *   addr_out[N] — angular_addr after N+1 prediction
 * ════════════════════════════════════════════════════════════════════ */
__global__ void phi_scatter_kernel(const uint64_t *__restrict__ hil_in,
                                    uint64_t       *__restrict__ addr_out,
                                    int             N,
                                    int             has_gs)
{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= N) return;

    uint64_t hil   = hil_in[idx];
    uint32_t h20   = (uint32_t)(hil & PHI_MASK);

    /* PHI scatter */
    uint32_t a38   = (uint32_t)(((uint64_t)h20 * PHI_UP)   >> 20) & PHI_MASK;
    uint32_t b38   = (uint32_t)(((uint64_t)h20 * PHI_DOWN) >> 20) & PHI_MASK;

    /* Voronoi classify */
    uint8_t  cid   = dev_voronoi_classify(a38, b38);

    /* N+1 predict: apply signed cluster offset */
    uint64_t out;
    if (has_gs)
        out = (uint64_t)((int64_t)hil + d_gs_offset[cid]);
    else
        out = hil;

    addr_out[idx] = out;
}

/* ════════════════════════════════════════════════════════════════════
 * Host: correctness validate (GPU vs CPU scalar)
 * ════════════════════════════════════════════════════════════════════ */

/* CPU scalar reference (mirrors kernel exactly) */
static uint64_t cpu_predict(uint64_t hil, const int64_t *gs_offset, int has_gs)
{
    uint32_t h20  = (uint32_t)(hil & PHI_MASK);
    uint32_t a38  = (uint32_t)(((uint64_t)h20 * PHI_UP)   >> 20) & PHI_MASK;
    uint32_t b38  = (uint32_t)(((uint64_t)h20 * PHI_DOWN) >> 20) & PHI_MASK;

    static const uint32_t sa[MESH_N_SEEDS] = {
        103984u, 520963u, 568421u,  80861u, 244791u,
        729951u, 407093u, 312985u, 941846u };
    static const uint32_t sb[MESH_N_SEEDS] = {
         39718u, 198989u, 617637u, 431406u, 494021u,
        278816u, 556015u, 119549u, 359752u };

    uint8_t  best   = 0;
    uint64_t best_d = UINT64_MAX;
    for (uint8_t i = 0; i < MESH_N_SEEDS; i++) {
        int64_t da = (int64_t)a38 - (int64_t)sa[i];
        int64_t db = (int64_t)b38 - (int64_t)sb[i];
        uint64_t d = (uint64_t)(da*da + db*db);
        if (d < best_d) { best_d = d; best = i; }
    }
    if (has_gs) return (uint64_t)((int64_t)hil + gs_offset[best]);
    return hil;
}

#define CHECK_CUDA(call) do { \
    cudaError_t e = (call); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error %s at line %d: %s\n", \
                #call, __LINE__, cudaGetErrorString(e)); \
        return 1; \
    } \
} while(0)

int main(void)
{
    printf("pogls38_phi_scatter — CUDA validate\n");

    /* ── build test input ────────────────────────────────────────── */
    const int N = 1 << 16;   /* 65536 lanes */
    uint64_t *h_hil = (uint64_t*)malloc(N * sizeof(uint64_t));
    uint64_t *h_out_gpu = (uint64_t*)malloc(N * sizeof(uint64_t));
    uint64_t *h_out_cpu = (uint64_t*)malloc(N * sizeof(uint64_t));
    assert(h_hil && h_out_gpu && h_out_cpu);

    for (int i = 0; i < N; i++)
        h_hil[i] = (uint64_t)(i * 4099ULL + 13ULL);

    /* fixed gs offsets (same for all clusters → easy to verify) */
    int64_t gs_offsets[MESH_N_SEEDS];
    for (int c = 0; c < MESH_N_SEEDS; c++)
        gs_offsets[c] = (int64_t)(c * 7 - 28);   /* range -28..+28 */

    /* ── CPU reference ───────────────────────────────────────────── */
    for (int i = 0; i < N; i++)
        h_out_cpu[i] = cpu_predict(h_hil[i], gs_offsets, 1);

    /* ── GPU setup ───────────────────────────────────────────────── */
    uint64_t *d_hil, *d_out;
    CHECK_CUDA(cudaMalloc(&d_hil, N * sizeof(uint64_t)));
    CHECK_CUDA(cudaMalloc(&d_out, N * sizeof(uint64_t)));
    CHECK_CUDA(cudaMemcpy(d_hil, h_hil, N * sizeof(uint64_t), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemcpyToSymbol(d_gs_offset, gs_offsets, MESH_N_SEEDS * sizeof(int64_t)));

    int threads = 256;
    int blocks  = (N + threads - 1) / threads;

    /* ── A: Correctness ──────────────────────────────────────────── */
    phi_scatter_kernel<<<blocks, threads>>>(d_hil, d_out, N, 1);
    CHECK_CUDA(cudaDeviceSynchronize());
    CHECK_CUDA(cudaMemcpy(h_out_gpu, d_out, N * sizeof(uint64_t), cudaMemcpyDeviceToHost));

    int mismatch = 0;
    for (int i = 0; i < N; i++) {
        if (h_out_cpu[i] != h_out_gpu[i]) {
            if (mismatch < 5)
                printf("  mismatch i=%d hil=%llu cpu=%llu gpu=%llu\n",
                       i, (unsigned long long)h_hil[i],
                       (unsigned long long)h_out_cpu[i],
                       (unsigned long long)h_out_gpu[i]);
            mismatch++;
        }
    }
    printf("[A] Correctness (%d lanes, has_gs=1): %s  (%d mismatches)\n",
           N, mismatch == 0 ? "PASS ✓" : "FAIL ✗", mismatch);

    /* gs=NULL path */
    phi_scatter_kernel<<<blocks, threads>>>(d_hil, d_out, N, 0);
    CHECK_CUDA(cudaDeviceSynchronize());
    CHECK_CUDA(cudaMemcpy(h_out_gpu, d_out, N * sizeof(uint64_t), cudaMemcpyDeviceToHost));
    mismatch = 0;
    for (int i = 0; i < N; i++)
        if (h_hil[i] != h_out_gpu[i]) mismatch++;
    printf("[A] Correctness (has_gs=0, passthrough): %s\n",
           mismatch == 0 ? "PASS ✓" : "FAIL ✗");

    /* ── B: Throughput ───────────────────────────────────────────── */
    /* warmup */
    for (int r = 0; r < 3; r++)
        phi_scatter_kernel<<<blocks, threads>>>(d_hil, d_out, N, 1);
    CHECK_CUDA(cudaDeviceSynchronize());

    cudaEvent_t ev0, ev1;
    CHECK_CUDA(cudaEventCreate(&ev0));
    CHECK_CUDA(cudaEventCreate(&ev1));

    int REPEAT = 50;
    CHECK_CUDA(cudaEventRecord(ev0));
    for (int r = 0; r < REPEAT; r++)
        phi_scatter_kernel<<<blocks, threads>>>(d_hil, d_out, N, 1);
    CHECK_CUDA(cudaEventRecord(ev1));
    CHECK_CUDA(cudaEventSynchronize(ev1));

    float ms = 0.f;
    CHECK_CUDA(cudaEventElapsedTime(&ms, ev0, ev1));
    double total_lanes = (double)N * REPEAT;
    double ms_per_run  = ms / REPEAT;
    double Mlanes_sec  = (total_lanes / (ms * 1e-3)) / 1e6;

    printf("[B] Throughput: %.3f ms/run  (N=%d)  → %.1f M-lanes/sec\n",
           ms_per_run, N, Mlanes_sec);

    /* ── device info ─────────────────────────────────────────────── */
    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, 0);
    printf("    GPU: %s  sm_%d%d  %.0f GB VRAM\n",
           prop.name, prop.major, prop.minor,
           prop.totalGlobalMem / 1e9);

    /* cleanup */
    cudaFree(d_hil); cudaFree(d_out);
    free(h_hil); free(h_out_gpu); free(h_out_cpu);
    cudaEventDestroy(ev0); cudaEventDestroy(ev1);
    return mismatch ? 1 : 0;
}
