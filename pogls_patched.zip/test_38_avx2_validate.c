/*
 * test_38_avx2_validate.c
 *
 * Priority 4 — AVX2 validate
 * A: scalar vs AVX2 PHI scatter → cluster → angular_addr  (bit-exact)
 * B: throughput benchmark (cycles/lane via rdtsc)
 *
 * Compile (WSL2):
 *   gcc -O2 -mavx2 -march=native -I../../pogls_core -I.. \
 *       test_38_avx2_validate.c -o test_38_avx2_validate
 *
 * AVX2 strategy:
 *   - PHI multiply: vectorize x8 hil lanes per __m256i op
 *   - voronoi_classify: scalar per-lane (branch-heavy → not worth vectorizing)
 *   - gs38_predict_next: scalar per-lane (table lookup + add)
 *   Result: ~8x throughput on PHI scatter, scalar overhead amortized.
 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <time.h>

/* PHI constants must come first */
#include "./pogls_core/pogls_platform.h"

#ifndef POGLS_MESH_H
#  ifndef POGLS_DETACH_LANE_H
#    include "./pogls_core/pogls_detach_lane.h"
#  endif
#  include "./pogls_core/pogls_mesh_entry.h"
#  include "./pogls_core/pogls_mesh.h"
#endif

#include "./POGLS38/pogls38_giant_shadow.h"

/* ── AVX2 guard ───────────────────────────────────────────────────── */
#if defined(__AVX2__)
#  include <immintrin.h>
#  define HAS_AVX2 1
#else
#  define HAS_AVX2 0
#  warning "AVX2 not available — correctness test runs scalar-only, benchmark skipped"
#endif

/* ── rdtsc helper ─────────────────────────────────────────────────── */
static inline uint64_t rdtsc(void)
{
#if defined(__x86_64__) || defined(__i386__)
    uint32_t lo, hi;
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
#endif
}

/* ─────────────────────────────────────────────────────────────────────
 * Scalar path  (exact copy of what batch_feed_gs does per hil)
 * ─────────────────────────────────────────────────────────────────── */
static inline uint64_t scalar_predict(uint64_t hil, const GiantShadow38 *gs)
{
    uint32_t mask38 = POGLS_PHI_SCALE - 1u;
    uint32_t a38    = (uint32_t)(((uint64_t)(hil & mask38) * POGLS_PHI_UP)   >> 20) & mask38;
    uint32_t b38    = (uint32_t)(((uint64_t)(hil & mask38) * POGLS_PHI_DOWN) >> 20) & mask38;
    uint8_t  cid    = voronoi_classify(a38, b38);
    return gs ? gs38_predict_next(gs, hil, cid) : hil;
}

/* ─────────────────────────────────────────────────────────────────────
 * AVX2 path  — PHI scatter x8 lanes, then scalar classify + predict
 *
 * Layout:
 *   hil[8] → __m256i → PHI_UP mul → a38[8]
 *                     → PHI_DOWN mul → b38[8]
 *   then loop 8: voronoi_classify(a38[i], b38[i]) + predict_next
 *
 * _mm256_mullo_epi32: 32b×32b → low 32b  (no overflow for PHI×20-bit input)
 * ─────────────────────────────────────────────────────────────────── */
#define BATCH8 8

#if HAS_AVX2

static void avx2_predict_batch(const uint64_t *hil_in,
                                uint64_t       *addr_out,
                                int             N,
                                const GiantShadow38 *gs)
{
    const uint32_t mask38  = POGLS_PHI_SCALE - 1u;
    const __m256i  vmask   = _mm256_set1_epi32((int32_t)mask38);
    const __m256i  vphi_up = _mm256_set1_epi32((int32_t)POGLS_PHI_UP);
    const __m256i  vphi_dn = _mm256_set1_epi32((int32_t)POGLS_PHI_DOWN);

    int i = 0;
    for (; i + BATCH8 <= N; i += BATCH8) {
        /* load 8 hil values, keep low 20 bits (mask38 = 2^20-1) */
        uint32_t hil32[BATCH8];
        for (int k = 0; k < BATCH8; k++)
            hil32[k] = (uint32_t)(hil_in[i+k] & mask38);

        __m256i vh = _mm256_loadu_si256((const __m256i*)hil32);
        vh = _mm256_and_si256(vh, vmask);

        /* PHI scatter: a = (hil * PHI_UP) >> 20, b = (hil * PHI_DOWN) >> 20 */
        __m256i va = _mm256_mullo_epi32(vh, vphi_up);
        __m256i vb = _mm256_mullo_epi32(vh, vphi_dn);
        va = _mm256_srli_epi32(va, 20);
        vb = _mm256_srli_epi32(vb, 20);
        va = _mm256_and_si256(va, vmask);
        vb = _mm256_and_si256(vb, vmask);

        uint32_t a38[BATCH8], b38[BATCH8];
        _mm256_storeu_si256((__m256i*)a38, va);
        _mm256_storeu_si256((__m256i*)b38, vb);

        /* scalar classify + predict (branch-heavy, not worth vectorizing) */
        for (int k = 0; k < BATCH8; k++) {
            uint8_t cid = voronoi_classify(a38[k], b38[k]);
            addr_out[i+k] = gs ? gs38_predict_next(gs, hil_in[i+k], cid)
                               : hil_in[i+k];
        }
    }
    /* tail: scalar for remainder */
    for (; i < N; i++)
        addr_out[i] = scalar_predict(hil_in[i], gs);
}

#endif /* HAS_AVX2 */

/* ── test helpers ─────────────────────────────────────────────────── */
static int pass = 0, fail = 0;
#define CHECK(cond, msg) do { \
    if (cond) { pass++; } \
    else { fail++; printf("  FAIL [%s] line %d\n", msg, __LINE__); } \
} while(0)

/* ── build a minimal GiantShadow38 with known offsets ────────────── */
static GiantShadow38 make_gs(int64_t fixed_offset)
{
    GiantShadow38 gs;
    gs38_init(&gs);
    for (int c = 0; c < MESH_MAX_CLUSTERS; c++) {
        gs.gs_offset[c]          = fixed_offset;
        gs.gs_offset_has_prev   |= (uint16_t)(1u << c);
    }
    return gs;
}

/* ════════════════════════════════════════════════════════════════════
 * A: Correctness — scalar vs AVX2 bit-exact
 * ════════════════════════════════════════════════════════════════════ */
static void test_correctness(void)
{
    printf("── A: Correctness (scalar vs AVX2) ─────────────────────\n");

#if !HAS_AVX2
    printf("  SKIP: no AVX2\n");
    return;
#else
    /* test with gs=NULL (passthrough) and fixed offset */
    GiantShadow38 gs = make_gs(777LL);

    /* 256 hil values spanning PHI space */
    static uint64_t hil[256], scalar_out[256], avx2_out[256];
    for (int i = 0; i < 256; i++)
        hil[i] = (uint64_t)(i * 4099ULL + 13ULL);   /* spread, not sequential */

    /* scalar reference */
    for (int i = 0; i < 256; i++)
        scalar_out[i] = scalar_predict(hil[i], &gs);

    /* AVX2 */
    avx2_predict_batch(hil, avx2_out, 256, &gs);

    int mismatch = 0;
    for (int i = 0; i < 256; i++) {
        if (scalar_out[i] != avx2_out[i]) {
            printf("  mismatch i=%d hil=%llu scalar=%llu avx2=%llu\n",
                   i, (unsigned long long)hil[i],
                   (unsigned long long)scalar_out[i],
                   (unsigned long long)avx2_out[i]);
            mismatch++;
        }
    }
    CHECK(mismatch == 0, "avx2 bit-exact vs scalar (256 hil, offset=777)");

    /* gs=NULL path */
    for (int i = 0; i < 256; i++)
        scalar_out[i] = scalar_predict(hil[i], NULL);
    avx2_predict_batch(hil, avx2_out, 256, NULL);
    mismatch = 0;
    for (int i = 0; i < 256; i++)
        if (scalar_out[i] != avx2_out[i]) mismatch++;
    CHECK(mismatch == 0, "avx2 bit-exact vs scalar (gs=NULL)");

    /* tail remainder test: N=11 (not multiple of 8) */
    avx2_predict_batch(hil, avx2_out, 11, &gs);
    mismatch = 0;
    for (int i = 0; i < 11; i++) {
        uint64_t ref = scalar_predict(hil[i], &gs);
        if (ref != avx2_out[i]) mismatch++;
    }
    CHECK(mismatch == 0, "avx2 tail (N=11, not multiple of 8)");

    /* boundary: hil=0, hil=UINT64_MAX (wraps to mask38) */
    uint64_t edge[8] = {0, UINT64_MAX, 1048575ULL, 1, 524288ULL, 999999ULL, 42ULL, 1000000ULL};
    uint64_t e_scalar[8], e_avx2[8];
    for (int i = 0; i < 8; i++) e_scalar[i] = scalar_predict(edge[i], &gs);
    avx2_predict_batch(edge, e_avx2, 8, &gs);
    mismatch = 0;
    for (int i = 0; i < 8; i++) if (e_scalar[i] != e_avx2[i]) mismatch++;
    CHECK(mismatch == 0, "avx2 boundary hil values");

    printf("  correctness: %d checks done\n", pass + fail);
#endif
}

/* ════════════════════════════════════════════════════════════════════
 * B: Throughput benchmark (cycles/lane)
 * ════════════════════════════════════════════════════════════════════ */
#define BENCH_N  (1 << 16)   /* 65536 lanes */
#define BENCH_REPEAT 8

static uint64_t bench_hil[BENCH_N];
static uint64_t bench_out[BENCH_N];

static void test_benchmark(void)
{
    printf("── B: Throughput benchmark ──────────────────────────────\n");

    GiantShadow38 gs = make_gs(123LL);
    for (int i = 0; i < BENCH_N; i++)
        bench_hil[i] = (uint64_t)(i * 6700417ULL + 1ULL);

    /* warmup */
    for (int i = 0; i < BENCH_N; i++)
        bench_out[i] = scalar_predict(bench_hil[i], &gs);

    /* scalar benchmark */
    uint64_t t0 = rdtsc();
    for (int r = 0; r < BENCH_REPEAT; r++)
        for (int i = 0; i < BENCH_N; i++)
            bench_out[i] = scalar_predict(bench_hil[i], &gs);
    uint64_t scalar_cycles = rdtsc() - t0;
    double scalar_cpl = (double)scalar_cycles / (BENCH_N * BENCH_REPEAT);

#if HAS_AVX2
    /* avx2 warmup */
    avx2_predict_batch(bench_hil, bench_out, BENCH_N, &gs);

    uint64_t t1 = rdtsc();
    for (int r = 0; r < BENCH_REPEAT; r++)
        avx2_predict_batch(bench_hil, bench_out, BENCH_N, &gs);
    uint64_t avx2_cycles = rdtsc() - t1;
    double avx2_cpl = (double)avx2_cycles / (BENCH_N * BENCH_REPEAT);

    printf("  scalar: %.2f cycles/lane\n", scalar_cpl);
    printf("  AVX2:   %.2f cycles/lane\n", avx2_cpl);
    printf("  speedup: %.2fx  (PHI scatter x8, classify scalar)\n",
           scalar_cpl / avx2_cpl);

    /* sanity: AVX2 should be faster */
    CHECK(avx2_cpl < scalar_cpl, "avx2 faster than scalar");
#else
    printf("  scalar: %.2f cycles/lane\n", scalar_cpl);
    printf("  AVX2:   SKIP (no AVX2)\n");
#endif
}

/* ════════════════════════════════════════════════════════════════════ */
int main(void)
{
    printf("test_38_avx2_validate\n");
    test_correctness();
    test_benchmark();
    printf("────────────────────────────────────────────────────────\n");
    printf("Result: %d/%d passed\n", pass, pass + fail);
    return fail ? 1 : 0;
}
