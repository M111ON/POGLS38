/*
 * test_38_lut_wire.c — Priority 4: LUT wired into batch_feed_gs
 *
 * T01  lut_build: all 1024 buckets filled, built flag set
 * T02  lut edge_mask: edge buckets exist but < 30% of total (sanity)
 * T03  lut_classify vs exact: mismatch < 1% over full PHI range
 * T04  batch_feed_gs lut_ctx=NULL: signature compat, no crash
 * T05  batch_feed_gs lut_ctx=&ctx: runs, output count matches
 * T06  angular_addr agreement: lut vs exact differ in < 1% of lanes
 * T07  lut_classify idempotent: build twice → same lut table
 * T08  edge bucket fallback: a known edge bucket returns exact cid
 * T09  lut_ctx=NULL falls back to exact voronoi in hot path
 * T10  batch N=0 with lut_ctx: no crash, returns immediately
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdatomic.h>

/* ── stubs identical to test_38_batch_feed ───────────────────────── */
#define POGLS_DETACH_LANE_H

#ifndef DETACH_REASON_GEO_INVALID
#  define DETACH_REASON_GEO_INVALID  0x01u
#  define DETACH_REASON_GHOST_DRIFT  0x02u
#  define DETACH_REASON_UNIT_CIRCLE  0x04u
#  define DETACH_REASON_OVERFLOW     0x80u
#endif

typedef struct {
    uint64_t  value; uint64_t  angular_addr; uint64_t  timestamp_ns;
    uint8_t   reason; uint8_t  route_was; uint8_t shell_n; uint8_t phase18;
    uint16_t  phase288; uint16_t phase306;
} DetachEntry;
typedef char _sz[(sizeof(DetachEntry)==32u)?1:-1];
static inline int detach_is_twin_window(const DetachEntry *e)
    { return e && (e->phase288<18u||e->phase306<18u); }

#ifndef POGLS_PHI_CONSTANTS
#define POGLS_PHI_CONSTANTS
#  define POGLS_PHI_SCALE   (1u << 20)
#  define POGLS_PHI_UP      1696631u
#  define POGLS_PHI_DOWN     648055u
#  define POGLS_PHI_COMP     400521u
#endif

#include "pogls_engine_slice.h"
#include "pogls_mesh_entry.h"
#include "pogls_mesh.h"
#include "pogls38_giant_shadow.h"

/* ── federation stub ─────────────────────────────────────────────── */
#define POGLS_FEDERATION_H
typedef struct {
    uint64_t  op_count;
    uint64_t  last_angular;   /* last angular_addr seen via fed_write  */
    uint64_t  lut_addr;       /* angular_addr from lut path            */
    uint64_t  exact_addr;     /* angular_addr from exact path          */
    int       write_count;
    int       capture_next;
} FederationCtx;

static uint64_t g_last_angular = 0;
static int      g_write_count  = 0;

static inline void fed_write(FederationCtx *f, uint32_t packed,
                              uint64_t angular_addr, uint64_t hil)
{
    (void)packed; (void)hil;
    if (f) { f->last_angular = angular_addr; f->op_count++; f->write_count++; }
    g_last_angular = angular_addr;
    g_write_count++;
}

/* use lut header (has new signature) */
#include "pogls38_hydra_thin_lut.h"

/* ── helpers ─────────────────────────────────────────────────────── */
static int pass_count = 0, fail_count = 0;
#define CHECK(cond, name) do { \
    if (cond) { printf("  ✅ %s\n", name); pass_count++; } \
    else      { printf("  ❌ %s  (line %d)\n", name, __LINE__); fail_count++; } \
} while(0)

static GiantShadow38 *make_gs_with_offset(int64_t offset)
{
    GiantShadow38 *gs = calloc(1, sizeof(GiantShadow38));
    if (!gs) return NULL;
    gs38_init(gs);
    for (int c = 0; c < MESH_MAX_CLUSTERS; c++) {
        gs->gs_offset[c]        = offset;
        gs->gs_offset_has_prev |= (uint16_t)(1u << c);
    }
    return gs;
}

static L38HydraThin *make_hydra(void)
{
    L38HydraThin *h = calloc(1, sizeof(L38HydraThin));
    if (!h) return NULL;
    l38_hydra_thin_init(h, 256u);
    return h;
}

/* ════════════════════════════════════════════════════════════════════ */
int main(void)
{
    printf("=== test_38_lut_wire ===\n\n");

    const uint32_t mask38 = POGLS_PHI_SCALE - 1u;

    /* T01 — lut_build: all buckets filled, built flag */
    {
        Gs38LutCtx ctx = {0};
        gs38_lut_build(&ctx);
        int all_valid = 1;
        for (uint32_t b = 0; b < GS38_LUT_SZ; b++)
            if (ctx.lut[b] >= MESH_MAX_CLUSTERS) { all_valid = 0; break; }
        CHECK(ctx.built == 1,  "T01a lut built flag set");
        CHECK(all_valid,        "T01b all 1024 buckets have valid cid (0..8)");
    }

    /* T02 — edge_mask: some edge buckets exist but < 30% */
    {
        Gs38LutCtx ctx = {0};
        gs38_lut_build(&ctx);
        int edge_count = 0;
        for (uint32_t b = 0; b < GS38_LUT_SZ; b++)
            if ((ctx.edge_mask[b>>3] >> (b&7u)) & 1u) edge_count++;
        CHECK(edge_count > 0,                       "T02a edge buckets exist");
        CHECK(edge_count < (int)(GS38_LUT_SZ * 30 / 100), "T02b edge < 30% of buckets");
        printf("      edge buckets: %d / %u (%.1f%%)\n",
               edge_count, GS38_LUT_SZ, 100.0*edge_count/GS38_LUT_SZ);
    }

    /* T03 — lut_classify vs exact: mismatch < 1% over full PHI range */
    {
        Gs38LutCtx ctx = {0};
        gs38_lut_build(&ctx);
        int mismatch = 0;
        /* stride over 2^20 space: 4096 samples */
        for (uint32_t h20 = 0; h20 < mask38; h20 += 256u) {
            uint32_t a38 = (uint32_t)(((uint64_t)h20 * POGLS_PHI_UP)   >> 20) & mask38;
            uint32_t b38 = (uint32_t)(((uint64_t)h20 * POGLS_PHI_DOWN) >> 20) & mask38;
            uint8_t  exact = voronoi_classify(a38, b38);
            uint8_t  lut   = gs38_lut_classify(&ctx, h20);
            if (exact != lut) mismatch++;
        }
        int total = mask38 / 256;
        double pct = 100.0 * mismatch / total;
        CHECK(pct < 1.0, "T03 lut classify mismatch < 1%");
        printf("      mismatch: %d/%d (%.2f%%)\n", mismatch, total, pct);
    }

    /* T04 — batch_feed_gs lut_ctx=NULL: no crash, compiles with new sig */
    {
        L38HydraThin *h  = make_hydra();
        GiantShadow38 *gs = make_gs_with_offset(0LL);
        FederationCtx fed = {0};
        uint32_t hil[4]  = {100, 200, 300, 400};
        uint8_t  lane[4] = {0, 1, 2, 3};
        uint8_t  audit[4]= {0, 0, 0, 0};
        g_write_count = 0;
        l38_hydra_batch_feed_gs(h, &fed, hil, lane, audit, 4, 1000ULL, gs, NULL);
        CHECK(g_write_count == 4, "T04 lut_ctx=NULL: 4 writes, no crash");
        free(h); free(gs);
    }

    /* T05 — batch_feed_gs lut_ctx=&ctx: runs, write count matches */
    {
        Gs38LutCtx ctx = {0};
        gs38_lut_build(&ctx);
        L38HydraThin  *h  = make_hydra();
        GiantShadow38 *gs = make_gs_with_offset(50LL);
        FederationCtx  fed = {0};
        uint32_t hil[8]  = {1000,2000,3000,4000,5000,6000,7000,8000};
        uint8_t  lane[8] = {0,1,2,3,4,5,6,7};
        uint8_t  audit[8]= {0,0,0,0,0,0,0,0};
        g_write_count = 0;
        l38_hydra_batch_feed_gs(h, &fed, hil, lane, audit, 8, 2000ULL, gs, &ctx);
        CHECK(g_write_count == 8, "T05 lut_ctx=&ctx: 8 writes, no crash");
        free(h); free(gs);
    }

    /* T06 — angular_addr agreement: lut vs exact < 1% differ */
    {
        Gs38LutCtx ctx = {0};
        gs38_lut_build(&ctx);
        L38HydraThin  *h_lut   = make_hydra();
        L38HydraThin  *h_exact = make_hydra();
        GiantShadow38 *gs = make_gs_with_offset(777LL);
        FederationCtx  fed_lut = {0}, fed_exact = {0};

        /* 512 lanes, varied hil */
        const int N = 512;
        uint32_t *hil   = malloc(N * sizeof(uint32_t));
        uint8_t  *lane  = malloc(N * sizeof(uint8_t));
        uint8_t  *audit = calloc(N, sizeof(uint8_t));
        uint64_t *addr_lut   = malloc(N * sizeof(uint64_t));
        uint64_t *addr_exact = malloc(N * sizeof(uint64_t));

        for (int i = 0; i < N; i++) {
            hil[i]  = (uint32_t)((i * 4099u + 13u) & mask38);
            lane[i] = (uint8_t)(i % 54u);
        }

        /* capture per-lane angular_addr by wrapping fed_write */
        /* simplest: run one lane at a time */
        int mismatch = 0;
        for (int i = 0; i < N; i++) {
            FederationCtx fl = {0}, fe = {0};
            L38HydraThin *hl = make_hydra(), *he = make_hydra();
            uint8_t a = 0, ln = lane[i];
            g_write_count = 0;
            l38_hydra_batch_feed_gs(hl, &fl, &hil[i], &ln, &a, 1, 0ULL, gs, &ctx);
            addr_lut[i] = fl.last_angular;
            l38_hydra_batch_feed_gs(he, &fe, &hil[i], &ln, &a, 1, 0ULL, gs, NULL);
            addr_exact[i] = fe.last_angular;
            if (addr_lut[i] != addr_exact[i]) mismatch++;
            free(hl); free(he);
        }
        double pct = 100.0 * mismatch / N;
        CHECK(pct < 1.0, "T06 angular_addr lut vs exact agree < 1% mismatch");
        printf("      angular_addr mismatch: %d/%d (%.2f%%)\n", mismatch, N, pct);

        free(h_lut); free(h_exact); free(gs);
        free(hil); free(lane); free(audit); free(addr_lut); free(addr_exact);
    }

    /* T07 — lut idempotent: build twice → same table */
    {
        Gs38LutCtx ctx1 = {0}, ctx2 = {0};
        gs38_lut_build(&ctx1);
        gs38_lut_build(&ctx2);
        gs38_lut_build(&ctx2);  /* second build on same ctx = no-op */
        CHECK(memcmp(ctx1.lut, ctx2.lut, GS38_LUT_SZ) == 0,       "T07a lut idempotent");
        CHECK(memcmp(ctx1.edge_mask, ctx2.edge_mask,
                     GS38_LUT_SZ/8) == 0, "T07b edge_mask idempotent");
    }

    /* T08 — edge bucket fallback returns exact cid */
    {
        Gs38LutCtx ctx = {0};
        gs38_lut_build(&ctx);
        /* find first edge bucket */
        int edge_b = -1;
        for (int b = 0; b < (int)GS38_LUT_SZ; b++)
            if ((ctx.edge_mask[b>>3] >> (b&7u)) & 1u) { edge_b = b; break; }
        if (edge_b >= 0) {
            /* use centroid of that bucket */
            uint32_t h20_mid = ((uint32_t)edge_b << GS38_LUT_K) + (1u << (GS38_LUT_K-1u));
            uint8_t  lut_cid   = gs38_lut_classify(&ctx, h20_mid);
            uint32_t a38 = (uint32_t)(((uint64_t)h20_mid * POGLS_PHI_UP)   >> 20) & mask38;
            uint32_t b38 = (uint32_t)(((uint64_t)h20_mid * POGLS_PHI_DOWN) >> 20) & mask38;
            uint8_t  exact_cid = voronoi_classify(a38, b38);
            CHECK(lut_cid == exact_cid, "T08 edge bucket centroid: lut == exact");
        } else {
            printf("  ⚠️  T08 SKIP: no edge buckets found (all seeds well-separated)\n");
            pass_count++;
        }
    }

    /* T09 — lut_ctx=NULL uses exact voronoi (angular_addr = gs_predict_next exact) */
    {
        GiantShadow38 *gs = make_gs_with_offset(999LL);
        L38HydraThin  *h1 = make_hydra(), *h2 = make_hydra();
        FederationCtx  f1 = {0}, f2 = {0};
        uint32_t hil  = 524288u;  /* mid PHI space */
        uint8_t  lane = 10u, audit = 0u;

        l38_hydra_batch_feed_gs(h1, &f1, &hil, &lane, &audit, 1, 0ULL, gs, NULL);
        /* reference: manually compute exact */
        uint32_t a38 = (uint32_t)(((uint64_t)(hil & mask38) * POGLS_PHI_UP)   >> 20) & mask38;
        uint32_t b38 = (uint32_t)(((uint64_t)(hil & mask38) * POGLS_PHI_DOWN) >> 20) & mask38;
        uint8_t  cid = voronoi_classify(a38, b38);
        uint64_t expected = gs38_predict_next(gs, (uint64_t)hil, cid);
        CHECK(f1.last_angular == expected, "T09 lut_ctx=NULL → exact angular_addr");
        free(h1); free(h2); free(gs);
    }

    /* T10 — N=0 with lut_ctx: no crash */
    {
        Gs38LutCtx ctx = {0};
        gs38_lut_build(&ctx);
        L38HydraThin  *h  = make_hydra();
        FederationCtx  fed = {0};
        g_write_count = 0;
        l38_hydra_batch_feed_gs(h, &fed, NULL, NULL, NULL, 0, 0ULL, NULL, &ctx);
        CHECK(g_write_count == 0, "T10 N=0 with lut_ctx: no crash, 0 writes");
        free(h);
    }

    printf("\n=== Result: %d/%d passed ===\n",
           pass_count, pass_count + fail_count);
    return fail_count ? 1 : 0;
}
