"""
pogls_chat_bridge/channels/all_channels.py
══════════════════════════════════════════════════════════════════════
3 input channels — all produce ConversationPair, no POST/GET:

  Channel A  WebSocket    ws://localhost:7475  ← Browser Extension
  Channel B  Clipboard    poll 0.5s            ← Copy any chat
  Channel C  File Drop    ./chat_drop/         ← Export & drop
"""

import os, time, json, threading, asyncio, logging
from pathlib import Path
from typing import Callable, Optional, List

from ..core_types import ConversationPair
from ..parsers.chat_parser import parse_any, parse_plain_text

log = logging.getLogger("Channels")

DROP_DIR   = Path(__file__).parent.parent.parent / "chat_drop"
WS_PORT    = int(os.environ.get("POGLS_WS_PORT", 7475))
CLIP_MIN   = 40     # min chars to bother parsing clipboard
CLIP_POLL  = 0.5    # seconds


OnPairs = Callable[[List[ConversationPair], str], None]   # (pairs, channel_name)


# ═══════════════════════════════════════════════════════════════════════
# Channel A — WebSocket
# ═══════════════════════════════════════════════════════════════════════
class WSChannel:
    """
    Persistent pipe from Browser Extension.
    Extension sends JSON per message:
      { platform, role, content, url, session, ts }
    OR a full conversation dump:
      { type:"conversation", platform, messages:[{role,content,ts}...], ... }

    Server accumulates per-session and emits pairs when both turns arrive.
    """
    name = "websocket"

    def __init__(self, on_pairs: OnPairs, port: int = WS_PORT):
        self._cb   = on_pairs
        self._port = port
        self._buf: dict  = {}   # session_id → list of {role, content, ts}
        self._lock = threading.Lock()

    def start(self):
        t = threading.Thread(target=self._run, daemon=True, name="WSChannel")
        t.start()

    def _flush_session(self, session_id: str, platform: str, url: str):
        """Try to form pairs from buffered messages for this session."""
        with self._lock:
            msgs = self._buf.get(session_id, [])
        pairs = []
        i = 0
        while i < len(msgs) - 1:
            u = msgs[i]
            a = msgs[i+1]
            if u["role"] in ("user", "human") and a["role"] == "assistant":
                from ..core_types import ChatMessage
                pairs.append(ConversationPair(
                    platform=platform,
                    question=ChatMessage(role="user",      content=u["content"], ts=float(u.get("ts", time.time()))),
                    answer  =ChatMessage(role="assistant", content=a["content"], ts=float(a.get("ts", time.time()))),
                    session_id=session_id,
                    url=url,
                    source=self.name,
                ))
                i += 2
            else:
                i += 1
        if pairs:
            self._cb(pairs, self.name)

    def _run(self):
        try:
            import websockets
        except ImportError:
            log.warning("pip install websockets  →  Channel A disabled")
            return

        async def handler(ws):
            log.info(f"[WS] client {ws.remote_address}")
            try:
                async for raw in ws:
                    try:
                        data = json.loads(raw)

                        # popup requests stored entries
                        if data.get("type") == "FETCH_ENTRIES":
                            limit   = int(data.get("limit", 200))
                            entries = self._fetch_entries(limit)
                            await ws.send(json.dumps({
                                "type": "ENTRIES",
                                "entries": entries,
                                "total": len(entries),
                            }))
                            continue

                        pairs = self._handle_packet(data)
                        ack = {"ok": True, "pairs": len(pairs)}
                        await ws.send(json.dumps(ack))
                    except Exception as ex:
                        await ws.send(json.dumps({"ok": False, "err": str(ex)}))
            except Exception:
                pass

        async def serve():
            async with websockets.serve(handler, "localhost", self._port):
                log.info(f"[WS] listening on ws://localhost:{self._port}")
                await asyncio.Future()

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(serve())


    def _fetch_entries(self, limit: int = 200) -> list:
        """Read .pogls_fabric/memory.delta and return entry dicts for popup."""
        import struct as _struct
        from pathlib import Path as _Path
        MAGIC   = b"POGM"
        HDR_SZ  = 12
        delta   = _Path(".pogls_fabric") / "memory.delta"
        entries = []
        try:
            with open(delta, "rb") as f:
                while True:
                    hdr = f.read(HDR_SZ)
                    if len(hdr) < HDR_SZ: break
                    magic, klen, plen, ts = _struct.unpack(">4sHHI", hdr)
                    if magic != MAGIC: break
                    payload = f.read(plen)
                    if len(payload) < plen: break
                    try:
                        d = json.loads(payload.decode("utf-8", errors="replace"))
                        entries.append(d)
                    except Exception:
                        pass
        except Exception:
            pass
        # newest first
        entries.sort(key=lambda x: x.get("ts", 0), reverse=True)
        return entries[:limit]

    def _handle_packet(self, data: dict) -> List[ConversationPair]:
        """Route packet to correct handler."""
        msg_type = data.get("type", "message")

        # Full conversation dump from extension
        if msg_type == "conversation":
            raw_json = json.dumps(data)
            pairs = parse_any(raw_json, url=data.get("url", ""), source=self.name)
            if pairs:
                self._cb(pairs, self.name)
            return pairs

        # Single message — buffer by session
        session  = data.get("session", "default")
        platform = data.get("platform", "unknown")
        url      = data.get("url", "")
        role     = data.get("role", "assistant")
        content  = data.get("content", "").strip()

        if not content:
            return []

        with self._lock:
            if session not in self._buf:
                self._buf[session] = []
            self._buf[session].append({
                "role": role, "content": content,
                "ts": data.get("ts", time.time()),
                "platform": platform,
            })

        self._flush_session(session, platform, url)
        return []


# ═══════════════════════════════════════════════════════════════════════
# Channel B — Clipboard Watcher
# ═══════════════════════════════════════════════════════════════════════
class ClipboardChannel:
    """
    Poll clipboard every 0.5s.
    Detects role markers to form Q+A pairs.
    Works on Windows / macOS / Linux (with xclip/xsel).
    """
    name = "clipboard"

    def __init__(self, on_pairs: OnPairs):
        self._cb   = on_pairs
        self._last = ""

    def start(self):
        t = threading.Thread(target=self._run, daemon=True, name="ClipboardChannel")
        t.start()

    def _run(self):
        try:
            import pyperclip
        except ImportError:
            log.warning("pip install pyperclip  →  Channel B disabled")
            return

        log.info("[CB] Clipboard watcher active — copy any AI chat to store")
        while True:
            try:
                text = pyperclip.paste()
                if text and text != self._last and len(text) >= CLIP_MIN:
                    self._last = text
                    if self._is_noise(text):
                        continue
                    pairs = parse_plain_text(text, source=self.name)
                    if pairs:
                        self._cb(pairs, self.name)
                        log.info(f"[CB] Clipboard → {len(pairs)} pair(s) captured")
            except Exception:
                pass
            time.sleep(CLIP_POLL)

    @staticmethod
    def _is_noise(text: str) -> bool:
        """
        กรอง clipboard ที่ไม่ใช่ chat:
        - code / console commands
        - paths / URLs เดี่ยวๆ
        - ข้อความสั้นที่ไม่มี sentence structure
        """
        t = text.strip()

        # code signatures
        CODE_SIGNS = [
            "document.querySelector", "console.log", "let ", "const ",
            "function ", "=>", "querySelectorAll", "innerText",
            "import ", "def ", "class ", "#!/",
            "C:\\", "python ", "pip ", "gcc ",
            "```", "#!/usr/bin/env",
            "VM", ":4 Q0:", "pairs in THIS tab",  # console output
            "undefined",                            # console result
        ]
        if any(s in t for s in CODE_SIGNS):
            return True

        # single line that looks like a path/URL/command
        lines = [l for l in t.splitlines() if l.strip()]
        if len(lines) <= 2:
            if t.startswith(("http", "C:\\", "/", "python", "pip", "cd ")):
                return True
            # no Thai or common chat words → probably not a conversation
            has_chat = any(w in t for w in [
                "คุณ", "ผม", "ฉัน", "คือ", "ได้", "จะ", "มี",
                "You:", "AI:", "Claude:", "ChatGPT:", "User:",
            ])
            if not has_chat and len(t) < 200:
                return True

        return False


# ═══════════════════════════════════════════════════════════════════════
# Channel C — File Drop Watcher
# ═══════════════════════════════════════════════════════════════════════
class FileDropChannel:
    """
    Watch ./chat_drop/ for new .txt / .json / .md files.
    Any AI export dropped here → auto-parse → store → archive.
    
    Accepted formats:
      claude_export.json, conversations.json (ChatGPT),
      Gemini Takeout JSON, DeepSeek JSON, plain text
    """
    name = "file_drop"

    def __init__(self, on_pairs: OnPairs,
                 drop_dir: Path = DROP_DIR):
        self._cb      = on_pairs
        self.drop_dir = drop_dir
        self.arch_dir = drop_dir / ".archive"
        self._seen: set = set()
        os.makedirs(drop_dir, exist_ok=True)
        os.makedirs(self.arch_dir, exist_ok=True)

    def start(self):
        t = threading.Thread(target=self._run, daemon=True, name="FileDropChannel")
        t.start()

    def _run(self):
        log.info(f"[FD] Watching {self.drop_dir}")
        while True:
            try:
                for f in self.drop_dir.glob("*"):
                    if f.is_file() and f.suffix in (".txt", ".json", ".md", ".jsonl"):
                        if f not in self._seen:
                            self._seen.add(f)
                            self._process(f)
            except Exception as ex:
                log.error(f"[FD] scan error: {ex}")
            time.sleep(1.0)

    def _process(self, path: Path):
        log.info(f"[FD] Processing {path.name}")
        try:
            text  = path.read_text(encoding="utf-8", errors="replace")
            pairs = parse_any(text, url=str(path), source=self.name)
            if pairs:
                self._cb(pairs, self.name)
                log.info(f"[FD] {path.name} → {len(pairs)} pair(s)")
            else:
                log.warning(f"[FD] {path.name} → 0 pairs (unrecognized format)")
            # archive
            dest = self.arch_dir / f"{path.stem}_{int(time.time())}{path.suffix}"
            path.rename(dest)
        except Exception as ex:
            log.error(f"[FD] Error processing {path.name}: {ex}")
