"""
pogls_chat_bridge/parsers/chat_parser.py
══════════════════════════════════════════════════════════════════════
Parse chat exports from all AI platforms → List[ConversationPair]

Supports:
  • Claude   — claude_export.json  (chat_messages[].content[].text)
  • ChatGPT  — conversations.json  (mapping{}.message.content.parts)
  • DeepSeek — JSON export         (messages[].role/content)
  • Gemini   — Takeout JSON        (conversations[].parts)
  • Copilot  — plain text / JSON
  • Generic  — plain text with role markers "You: / AI:"
  • Clipboard plain text (any platform)
"""

import re, json, hashlib, time
from pathlib import Path
from typing import List, Optional

from ..core_types import ChatMessage, ConversationPair, detect_platform


# ── Helpers ───────────────────────────────────────────────────────────

def _pair_up(msgs: list[dict], platform: str,
             session_id: str = "", conv_title: str = "",
             url: str = "", source: str = "file_drop") -> List[ConversationPair]:
    """
    Turn a flat list of {role, content, ts} dicts into Q+A pairs.
    Strategy: user msg immediately followed by assistant msg = one pair.
    If consecutive user msgs → merge into one question.
    If consecutive assistant msgs → merge into one answer.
    """
    pairs: List[ConversationPair] = []
    i = 0
    msgs = [m for m in msgs if m.get("content", "").strip()]

    while i < len(msgs):
        # collect user turn (merge consecutive user messages)
        user_parts = []
        while i < len(msgs) and msgs[i].get("role", "") in ("user", "human", "Human", "you"):
            user_parts.append(msgs[i]["content"].strip())
            user_ts = float(msgs[i].get("ts") or time.time())
            i += 1

        if not user_parts:
            i += 1
            continue

        # collect assistant turn (merge consecutive)
        asst_parts = []
        while i < len(msgs) and msgs[i].get("role", "") in (
                "assistant", "model", "bot", "ai", "AI", "Assistant",
                "chatgpt", "claude", "gemini", "deepseek", "copilot"):
            asst_parts.append(msgs[i]["content"].strip())
            asst_ts = float(msgs[i].get("ts") or time.time())
            i += 1

        if not asst_parts:
            continue

        q_text = "\n".join(user_parts)
        a_text = "\n".join(asst_parts)

        if len(q_text) < 3 or len(a_text) < 3:
            continue

        pairs.append(ConversationPair(
            platform=platform,
            question=ChatMessage(role="user",      content=q_text, ts=user_ts),
            answer  =ChatMessage(role="assistant", content=a_text, ts=asst_ts),
            session_id=session_id,
            conv_title=conv_title,
            url=url,
            source=source,
        ))

    return pairs


# ── Platform parsers ──────────────────────────────────────────────────

def parse_claude(raw: dict, source: str = "file_drop", url: str = "") -> List[ConversationPair]:
    """claude_export.json → pairs"""
    all_pairs = []
    convs = raw if isinstance(raw, list) else raw.get("conversations", [raw])
    for conv in convs:
        msgs = []
        for msg in conv.get("chat_messages", []):
            parts = msg.get("content", [])
            if isinstance(parts, str):
                text = parts
            else:
                text = " ".join(
                    p.get("text", "") for p in parts
                    if isinstance(p, dict) and p.get("type") == "text"
                ).strip()
            if text:
                msgs.append({
                    "role": msg.get("sender", "assistant"),
                    "content": text,
                    "ts": msg.get("created_at", ""),
                })
        all_pairs += _pair_up(msgs, "claude",
                              session_id=str(conv.get("uuid", ""))[:32],
                              conv_title=conv.get("name", ""),
                              url=url, source=source)
    return all_pairs


def parse_chatgpt(raw: dict, source: str = "file_drop", url: str = "") -> List[ConversationPair]:
    """conversations.json (ChatGPT export) → pairs"""
    all_pairs = []
    convs = raw if isinstance(raw, list) else [raw]
    for conv in convs:
        msgs = []
        # mapping is a tree; do topological sort by parent chain
        mapping = conv.get("mapping", {})
        # simple: collect all nodes that have messages
        for node in mapping.values():
            msg = node.get("message")
            if not msg:
                continue
            parts = msg.get("content", {}).get("parts", [])
            text = " ".join(str(p) for p in parts if isinstance(p, str)).strip()
            if not text:
                continue
            msgs.append({
                "role": msg.get("author", {}).get("role", "assistant"),
                "content": text,
                "ts": str(msg.get("create_time", "")),
            })
        # sort by create_time
        def _ts(m):
            try: return float(m["ts"])
            except: return 0.0
        msgs.sort(key=_ts)
        all_pairs += _pair_up(msgs, "chatgpt",
                              session_id=str(conv.get("id", ""))[:32],
                              conv_title=conv.get("title", ""),
                              url=url, source=source)
    return all_pairs


def parse_deepseek(raw, source: str = "file_drop", url: str = "") -> List[ConversationPair]:
    """DeepSeek JSON export → pairs (messages[].role/content)"""
    all_pairs = []
    convs = raw if isinstance(raw, list) else [raw]
    for conv in convs:
        msgs = conv.get("messages", conv if isinstance(conv, list) else [])
        flat = []
        for m in msgs:
            if isinstance(m, dict) and m.get("content"):
                flat.append({
                    "role": m.get("role", "assistant"),
                    "content": str(m["content"]).strip(),
                    "ts": m.get("created_at", m.get("ts", "")),
                })
        all_pairs += _pair_up(flat, "deepseek",
                              session_id=str(conv.get("id", ""))[:32] if isinstance(conv, dict) else "",
                              url=url, source=source)
    return all_pairs


def parse_gemini(raw, source: str = "file_drop", url: str = "") -> List[ConversationPair]:
    """Google Takeout Gemini JSON → pairs"""
    all_pairs = []
    convs = raw if isinstance(raw, list) else raw.get("conversations", [raw])
    for conv in convs:
        msgs = []
        for turn in conv.get("turns", conv.get("messages", [])):
            role = turn.get("role", turn.get("author", "assistant"))
            # Gemini content can be parts[]
            parts = turn.get("parts", turn.get("content", ""))
            if isinstance(parts, list):
                text = " ".join(
                    p.get("text", "") if isinstance(p, dict) else str(p)
                    for p in parts
                ).strip()
            else:
                text = str(parts).strip()
            if text:
                msgs.append({"role": role, "content": text, "ts": turn.get("ts", "")})
        all_pairs += _pair_up(msgs, "gemini", url=url, source=source)
    return all_pairs


def parse_plain_text(text: str, platform: str = "",
                     url: str = "", source: str = "clipboard") -> List[ConversationPair]:
    """
    Parse plain copied text.
    Detects role markers like:
      "You:", "Human:", "User:" → question
      "ChatGPT:", "Claude:", "Gemini:", "AI:", "Assistant:" → answer
    Falls back to alternating turns if no markers found.
    """
    platform = platform or detect_platform(text, url)
    text = text.strip()
    if len(text) < 20:
        return []

    USER_LABELS = r"You|Human|User"
    BOT_LABELS  = r"ChatGPT|Claude|Gemini|DeepSeek|Copilot|AI|Assistant|Bot"
    PATTERN = re.compile(
        rf"^({USER_LABELS}|{BOT_LABELS})\s*[:\-]\s*(.+?)(?=\n(?:{USER_LABELS}|{BOT_LABELS})\s*[:\-]|\Z)",
        re.MULTILINE | re.DOTALL | re.IGNORECASE
    )

    msgs = []
    for m in PATTERN.finditer(text):
        label   = m.group(1).strip().lower()
        content = m.group(2).strip()
        if not content:
            continue
        role = "user" if label in ("you", "human", "user") else "assistant"
        msgs.append({"role": role, "content": content, "ts": time.time()})

    if not msgs:
        # No markers: treat as single assistant block
        if len(text) > 30:
            return [ConversationPair(
                platform=platform,
                question=ChatMessage(role="user",      content="[context]",   ts=time.time()),
                answer  =ChatMessage(role="assistant", content=text,           ts=time.time()),
                source=source, url=url,
            )]
        return []

    return _pair_up(msgs, platform, url=url, source=source)


# ── Universal dispatcher ──────────────────────────────────────────────

def parse_any(raw_text: str, url: str = "",
              source: str = "file_drop") -> List[ConversationPair]:
    """
    Try all parsers in order, return first non-empty result.
    Handles JSON files + plain text clipboard.
    """
    # try JSON parse
    try:
        data = json.loads(raw_text)
        platform = detect_platform(raw_text, url)

        # try each platform parser
        for parser, plat in [
            (parse_claude,   "claude"),
            (parse_chatgpt,  "chatgpt"),
            (parse_deepseek, "deepseek"),
            (parse_gemini,   "gemini"),
        ]:
            try:
                pairs = parser(data, source=source, url=url)
                if pairs:
                    return pairs
            except Exception:
                continue

        # generic JSON: try to find messages[] key
        if isinstance(data, dict):
            msgs_raw = data.get("messages") or data.get("conversation") or []
            if msgs_raw:
                flat = []
                for m in msgs_raw:
                    if isinstance(m, dict):
                        flat.append({
                            "role": m.get("role", m.get("author", {}).get("role", "assistant")),
                            "content": str(m.get("content", m.get("text", ""))).strip(),
                            "ts": m.get("ts", m.get("created_at", "")),
                        })
                if flat:
                    return _pair_up(flat, platform or "unknown", url=url, source=source)

    except json.JSONDecodeError:
        pass

    # plain text fallback
    return parse_plain_text(raw_text, url=url, source=source)
