"""
pogls_chat_bridge/run.py  —  CLI launcher
══════════════════════════════════════════════════════════════════════
Usage:
    python -m pogls_chat_bridge.run            # start all 3 channels
    python -m pogls_chat_bridge.run --recall "transformer"
    python -m pogls_chat_bridge.run --stats
    python -m pogls_chat_bridge.run --platform chatgpt --limit 10
    python -m pogls_chat_bridge.run --recent 20
"""

import sys, time, json, argparse, logging
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(message)s",
    datefmt="%H:%M:%S"
)

def main():
    parser = argparse.ArgumentParser(
        prog="pogls_chat_bridge",
        description="POGLS Chat Bridge — Multi-Platform AI Chat Collector"
    )
    parser.add_argument("--ws-port",  type=int, default=7475)
    parser.add_argument("--recall",   type=str, default="",
                        help="Full-text search then exit")
    parser.add_argument("--stats",    action="store_true",
                        help="Show storage stats then exit")
    parser.add_argument("--recent",   type=int, default=0,
                        help="Show N most recent pairs then exit")
    parser.add_argument("--platform", type=str, default="",
                        help="Filter by platform name")
    parser.add_argument("--limit",    type=int, default=10)
    parser.add_argument("--no-clip",  action="store_true",
                        help="Disable clipboard channel")
    parser.add_argument("--no-drop",  action="store_true",
                        help="Disable file-drop channel")
    args = parser.parse_args()

    from pogls_chat_bridge import ChatBridge

    bridge = ChatBridge(
        ws_port=args.ws_port,
        enable_clipboard=not args.no_clip,
        enable_file_drop=not args.no_drop,
    )

    # ── One-shot commands ─────────────────────────────────────────────
    if args.stats:
        import pprint
        pprint.pprint(bridge.stats())
        return

    if args.recall:
        results = bridge.search(args.recall, limit=args.limit)
        _print_results(results, f'search: "{args.recall}"')
        return

    if args.recent:
        results = bridge.recent(args.recent)
        _print_results(results, f"recent {args.recent}")
        return

    if args.platform:
        results = bridge.by_platform(args.platform, limit=args.limit)
        _print_results(results, f"platform: {args.platform}")
        return

    # ── Daemon mode ───────────────────────────────────────────────────
    bridge.start()
    try:
        while True:
            time.sleep(10)
            s = bridge.stats()
            if s.get("session_saved", 0) > 0:
                print(
                    f"  📊 session={s['session_saved']} saved | "
                    f"total={s['total_pairs']} | "
                    f"platforms={s['by_platform']}"
                )
    except KeyboardInterrupt:
        print("\n\n👋 ChatBridge stopped")
        s = bridge.stats()
        print(f"   Session saved : {s.get('session_saved', 0)}")
        print(f"   Total pairs   : {s.get('total_pairs', 0)}")
        print(f"   By platform   : {s.get('by_platform', {})}")
        print(f"   World A / B   : {s.get('world_A', 0)} / {s.get('world_B', 0)}")


def _print_results(results: list, label: str):
    print(f"\n── {label} ({len(results)} results) ──")
    for r in results:
        ts  = r.get("ts", r.get("added", ""))
        plat = next((t[9:] for t in r.get("tags", []) if t.startswith("platform:")), r.get("agent", "?"))
        addr = r.get("addr", 0)
        world= r.get("world", "?")
        content = r.get("content", r.get("name", ""))[:120].replace("\n", " ")
        print(f"  [{plat:8}] θ-addr={addr:07d} W{world}  {content}")
    print()


if __name__ == "__main__":
    main()
